import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, shareReplay, catchError, delay, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';

export type DataColumnType = 'text' | 'number' | 'boolean' | 'date';

export type DataRecordValue = string | number | boolean | null;
export type DataRecord = Record<string, DataRecordValue>;

export interface DataColumnDefinition {
	key: string;
	label: string;
	type: DataColumnType;
	readOnly?: boolean;
	required?: boolean;
	maxLength?: number;
	dbType?: string;
	defaultValue?: DataRecordValue;
}

export interface DataTableDefinition {
	key: string;
	name: string;
	description: string;
	columns: DataColumnDefinition[];
}

@Injectable({ providedIn: 'root' })
export class DataAdministratorService {
	private readonly tablesUrl = '/api/metadata/tables';
	private readonly dataUrl = '/api/metadata/data';
	private readonly tables$: Observable<DataTableDefinition[]>;

	// Mock data for fallback when API is not available
	private readonly mockRecordsByTableKey: Record<string, DataRecord[]> = {
		feed_definitions: [
			{ "id": 100001, "name": "Out Feed Feed 1", "environment": "Portico", "enabled": true },
  { "id": 100002, "name": "Ingestion Feed 2", "environment": "Pods", "enabled": false },
  { "id": 100003, "name": "Sync Feed 3", "environment": "Facets", "enabled": true },
  { "id": 100004, "name": "Export Feed 4", "environment": "Bridge", "enabled": true },
  { "id": 100005, "name": "Import Feed 5", "environment": "Gateway", "enabled": true },
  { "id": 100006, "name": "Bridge Feed 6", "environment": "Portico", "enabled": true },
  { "id": 100007, "name": "Processor Feed 7", "environment": "Pods", "enabled": false },
  { "id": 100008, "name": "Aggregator Feed 8", "environment": "Facets", "enabled": true },
  { "id": 100009, "name": "Out Feed Feed 9", "environment": "Bridge", "enabled": true },
  { "id": 100010, "name": "Ingestion Feed 10", "environment": "Gateway", "enabled": true },
  { "id": 100011, "name": "Sync Feed 11", "environment": "Portico", "enabled": true },
  { "id": 100012, "name": "Export Feed 12", "environment": "Pods", "enabled": false },
  { "id": 100013, "name": "Import Feed 13", "environment": "Facets", "enabled": true },
  { "id": 100014, "name": "Bridge Feed 14", "environment": "Bridge", "enabled": true },
  { "id": 100015, "name": "Processor Feed 15", "environment": "Gateway", "enabled": true },
  { "id": 100016, "name": "Aggregator Feed 16", "environment": "Portico", "enabled": true },
  { "id": 100017, "name": "Out Feed Feed 17", "environment": "Pods", "enabled": false },
  { "id": 100018, "name": "Ingestion Feed 18", "environment": "Facets", "enabled": true },
  { "id": 100019, "name": "Sync Feed 19", "environment": "Bridge", "enabled": true },
  { "id": 100020, "name": "Export Feed 20", "environment": "Gateway", "enabled": true },
		],
		designations: [
			{
				id: 1,
				designation_type: 'DESIGNATION',
				designation_code: 'D001',
				maintaining_dept: 'OPS',
				owner: 'SYSTEM',
				start_date: '1800-01-01',
				end_date: '4000-01-01',
				self_service: true,
				ss_ext_ds: null,
				designation_grouping: 'General',
				designation_tier: 'T1',
				uplift_pct: null,
				exl_dtry_ind: false,
				designation_tier_override: null,
			},
			{
				id: 2,
				designation_type: 'DESIGNATION',
				designation_code: 'D002',
				maintaining_dept: 'FIN',
				owner: 'SYSTEM',
				start_date: '1800-01-01',
				end_date: '4000-01-01',
				self_service: false,
				ss_ext_ds: 'EXT-DS-01',
				designation_grouping: null,
				designation_tier: 'T2',
				uplift_pct: '5',
				exl_dtry_ind: null,
				designation_tier_override: 'T3',
			},
		],
		business_rules: [
			{ id: 1, ruleName: 'Validate Feed Name', priority: 10, active: true },
			{ id: 2, ruleName: 'Enforce Environment Mapping', priority: 20, active: true },
			{ id: 3, ruleName: 'Archive Disabled Feeds', priority: 30, active: false },
		],
		security_roles: [
			{ id: 1, roleName: 'Admin', description: 'Full access to administration features' },
			{ id: 2, roleName: 'Operator', description: 'View feeds and metrics' },
			{ id: 3, roleName: 'ReadOnly', description: 'Read-only access to dashboards' },
		],
	};

	constructor(private readonly http: HttpClient) {
		this.tables$ = this.http.get<unknown>(this.tablesUrl).pipe(
			map((raw) => this.normalizeTables(raw)),
			catchError(() => of(this.getMockTables())),
			shareReplay({ bufferSize: 1, refCount: true }),
		);
	}

	getTables(): Observable<DataTableDefinition[]> {
		return this.tables$;
	}

	private normalizeTables(raw: unknown): DataTableDefinition[] {
		const arr = Array.isArray(raw)
			? raw
			: raw && typeof raw === 'object' && Array.isArray((raw as { tables?: unknown }).tables)
				? ((raw as { tables: unknown[] }).tables as unknown[])
				: [];

		return arr
			.filter((t): t is Record<string, unknown> => !!t && typeof t === 'object')
			.map((t) => {
				const keyRaw =
					(t['key'] as unknown) ??
					(t['tableKey'] as unknown) ??
					(t['table_key'] as unknown) ??
					(t['tableName'] as unknown) ??
					(t['table_name'] as unknown) ??
					(t['name'] as unknown);

				const key = keyRaw ? this.normalizeKey(String(keyRaw)) : '';
				const nameRaw = (t['name'] as unknown) ?? (t['displayName'] as unknown) ?? keyRaw;
				const name = nameRaw ? String(nameRaw).trim() : key;
				const description = t['description'] ? String(t['description']).trim() : '';

				const columnsRaw =
					(t['columns'] as unknown) ?? (t['cols'] as unknown) ?? (t['fields'] as unknown) ?? [];
				const columns = this.normalizeColumns(columnsRaw);

				return {
					key,
					name: name && name !== key ? name : this.humanize(name || key),
					description,
					columns,
				} satisfies DataTableDefinition;
			})
			.filter((t) => !!t.key && !!t.name && Array.isArray(t.columns));
	}

	private normalizeColumns(raw: unknown): DataColumnDefinition[] {
		const arr = Array.isArray(raw) ? raw : [];
		return arr
			.filter((c): c is Record<string, unknown> => !!c && typeof c === 'object')
			.map((c) => {
				const keyRaw =
					(c['key'] as unknown) ??
					(c['columnKey'] as unknown) ??
					(c['column_key'] as unknown) ??
					(c['name'] as unknown) ??
					(c['columnName'] as unknown) ??
					(c['column_name'] as unknown);
				const key = keyRaw ? this.normalizeKey(String(keyRaw)) : '';

				const labelRaw = (c['label'] as unknown) ?? (c['displayName'] as unknown) ?? keyRaw;
				const label = labelRaw ? String(labelRaw).trim() : key;

				const dbType = c['dbType'] ? String(c['dbType']).trim() : c['dataType'] ? String(c['dataType']).trim() : undefined;

				const readOnly =
					(c['readOnly'] as boolean | undefined) ??
					(c['readonly'] as boolean | undefined) ??
					(c['pk'] as boolean | undefined) ??
					(c['primaryKey'] as boolean | undefined) ??
					false;

				const required =
					(c['required'] as boolean | undefined) ??
					this.requiredFromNullable(c['nullable'] ?? c['isNullable'] ?? c['null']);

				const maxLengthCandidate = c['maxLength'] ?? c['length'] ?? c['max_len'];
				const maxLengthNum = typeof maxLengthCandidate === 'number' ? maxLengthCandidate : Number(maxLengthCandidate);
				const maxLength = Number.isFinite(maxLengthNum) && maxLengthNum > 0 ? maxLengthNum : undefined;

				const defaultValue = c['defaultValue'] as DataRecordValue | undefined;

				const type = this.resolveColumnType(c['type'], dbType);

				return {
					key,
					label: label && label !== key ? label : this.humanize(label || key),
					type,
					readOnly,
					required,
					maxLength,
					dbType,
					defaultValue,
				} satisfies DataColumnDefinition;
			})
			.filter((c) => !!c.key && !!c.label);
	}

	private resolveColumnType(typeRaw: unknown, dbType?: string): DataColumnType {
		const t = typeof typeRaw === 'string' ? typeRaw.trim().toLowerCase() : '';
		if (t === 'text' || t === 'number' || t === 'boolean' || t === 'date') {
			return t;
		}
		const db = (dbType ?? '').toUpperCase();
		if (db.includes('DATE') || db.includes('TIMESTAMP')) {
			return 'date';
		}
		if (db.includes('NUMBER') || db.includes('DECIMAL') || db.includes('INT')) {
			return 'number';
		}
		if (db.includes('CHAR(1)') || db.includes('VARCHAR2(1)') || t === 'varchar2(1)' || t === 'char(1)') {
			return 'boolean';
		}
		return 'text';
	}

	private normalizeKey(value: string): string {
		const trimmed = value.trim();
		return /^[A-Z0-9_]+$/.test(trimmed) ? trimmed.toLowerCase() : trimmed;
	}

	private requiredFromNullable(nullable: unknown): boolean | undefined {
		if (nullable === undefined || nullable === null) {
			return undefined;
		}
		if (typeof nullable === 'boolean') {
			return !nullable;
		}
		const s = String(nullable).trim().toLowerCase();
		if (s === 'y' || s === 'yes' || s === 'true') {
			return false;
		}
		if (s === 'n' || s === 'no' || s === 'false') {
			return true;
		}
		return undefined;
	}

	private humanize(value: string): string {
		const cleaned = value.replace(/_/g, ' ').trim();
		if (!cleaned) {
			return '';
		}
		return cleaned
			.toLowerCase()
			.replace(/\b\w/g, (m) => m.toUpperCase())
			.replace(/\bSs\b/g, 'SS')
			.replace(/\bId\b/g, 'ID');
	}

	getRecords(tableKey: string): Observable<DataRecord[]> {
		const startTime = Date.now();
		
		return this.http.get<DataRecord[]>(`${this.dataUrl}/${tableKey}`).pipe(
			map(records => Array.isArray(records) ? records : []),
			// Ensure minimum loading time for better UX
			switchMap(records => {
				const elapsedTime = Date.now() - startTime;
				const minimumLoadTime = 600; // 600ms minimum
				const remainingTime = Math.max(0, minimumLoadTime - elapsedTime);
				return of(records).pipe(delay(remainingTime));
			}),
			catchError(() => {
				// Fallback to mock data if API is not available
				const mockRecords = this.mockRecordsByTableKey[tableKey] ?? [];
				return of(mockRecords.map((r) => ({ ...r })));
			})
		);
	}

	createRecord(tableKey: string, record: DataRecord): Observable<DataRecord> {
		return this.http.post<DataRecord>(`${this.dataUrl}/${tableKey}`, record).pipe(
			catchError(() => {
				// Fallback to mock data if API is not available
				const records = this.mockRecordsByTableKey[tableKey] ?? (this.mockRecordsByTableKey[tableKey] = []);
				const nextId = this.getNextId(records);
				const created: DataRecord = { ...record, id: nextId };
				records.unshift(created);
				return of({ ...created });
			})
		);
	}

	updateRecord(tableKey: string, record: DataRecord): Observable<DataRecord> {
		const id = Number(record['id']);
		return this.http.put<DataRecord>(`${this.dataUrl}/${tableKey}/${id}`, record).pipe(
			catchError(() => {
				// Fallback to mock data if API is not available
				const records = this.mockRecordsByTableKey[tableKey] ?? (this.mockRecordsByTableKey[tableKey] = []);
				const idx = records.findIndex((r) => Number(r['id']) === id);
				if (idx === -1) {
					throw new Error('Record not found');
				}
				records[idx] = { ...records[idx], ...record, id };
				return of({ ...records[idx] });
			})
		);
	}

	deleteRecord(tableKey: string, id: number): Observable<void> {
		return this.http.delete<void>(`${this.dataUrl}/${tableKey}/${id}`).pipe(
			catchError(() => {
				// Fallback to mock data if API is not available
				const records = this.mockRecordsByTableKey[tableKey] ?? (this.mockRecordsByTableKey[tableKey] = []);
				const idx = records.findIndex((r) => Number(r['id']) === id);
				if (idx !== -1) {
					records.splice(idx, 1);
				}
				return of(undefined as void);
			})
		);
	}

	private getNextId(records: DataRecord[]): number {
		const ids = records
			.map((r) => Number(r['id']))
			.filter((n) => Number.isFinite(n));
		const max = ids.length ? Math.max(...ids) : 0;
		return max + 1;
	}

	private getMockTables(): DataTableDefinition[] {
		// Return mock table definitions when API is not available
		return [
			{
				key: 'feed_definitions',
				name: 'Feed Definitions', 
				description: 'Configuration for data feeds',
				columns: [
					{ key: 'id', label: 'ID', type: 'number', readOnly: true },
					{ key: 'name', label: 'Name', type: 'text', required: true },
					{ key: 'environment', label: 'Environment', type: 'text', required: true },
					{ key: 'enabled', label: 'Enabled', type: 'boolean' }
				]
			},
			{
				key: 'designations',
				name: 'Designations',
				description: 'System designations and types',
				columns: [
					{ key: 'id', label: 'ID', type: 'number', readOnly: true },
					{ key: 'designation_type', label: 'Type', type: 'text', required: true },
					{ key: 'designation_code', label: 'Code', type: 'text', required: true },
					{ key: 'maintaining_dept', label: 'Department', type: 'text' },
					{ key: 'owner', label: 'Owner', type: 'text' },
					{ key: 'self_service', label: 'Self Service', type: 'boolean' }
				]
			},
			{
				key: 'business_rules',
				name: 'Business Rules',
				description: 'System business rules configuration',
				columns: [
					{ key: 'id', label: 'ID', type: 'number', readOnly: true },
					{ key: 'ruleName', label: 'Rule Name', type: 'text', required: true },
					{ key: 'priority', label: 'Priority', type: 'number' },
					{ key: 'active', label: 'Active', type: 'boolean' }
				]
			},
			{
				key: 'security_roles',
				name: 'Security Roles',
				description: 'System security roles and permissions',
				columns: [
					{ key: 'id', label: 'ID', type: 'number', readOnly: true },
					{ key: 'roleName', label: 'Role Name', type: 'text', required: true },
					{ key: 'description', label: 'Description', type: 'text' }
				]
			}
		];
	}
}
