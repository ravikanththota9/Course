import { Component, signal, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface SearchCriteria {
  firstName: string;
  lastName: string;
  stateLicense: string;
  type1NPI: string;
  taxId: string;
  pin: string;
  porticoId: string;
}

interface PractitionerRecord {
  id: number;
  practitionerName: string;
  pcp: string;
  stateLicense: string;
  type1NPI: string;
  taxId: string;
  status: string;
  porticoId: string;
  pin: string;
  credStatus: string;
}

type DetailTab = 'overview' | 'demographics' | 'designations' | 'tasks' | 'credentialing' | 'comments';

@Component({
  selector: 'app-practitioner-inquiry',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="inquiry-page">
      <header class="inquiry-header">
        <div class="inquiry-header-title">
          <h1>Practitioner Inquiry</h1>
          <p>Wizards → Practitioner Inquiry</p>
        </div>
      </header>

      <!-- Main Content Layout -->
      <div class="main-layout">
        <!-- Search Panel -->
        <div class="search-panel">
          <div class="panel-header">
            <h2>Search Criteria</h2>
            <p>Enter any criteria to search</p>
          </div>
          
          <form class="search-form" (ngSubmit)="onSearch()">
            <div class="form-fields">
              <div class="field-group">
                <label for="firstName">First Name</label>
                <input
                  type="text"
                  id="firstName"
                  [(ngModel)]="searchCriteria.firstName"
                  name="firstName"
                  class="form-input"
                  placeholder="Enter first name"
                />
              </div>
              
              <div class="field-group">
                <label for="lastName">Last Name</label>
                <input
                  type="text"
                  id="lastName"
                  [(ngModel)]="searchCriteria.lastName"
                  name="lastName"
                  class="form-input"
                  placeholder="Enter last name"
                />
              </div>
              
              <div class="field-group">
                <label for="stateLicense">State License</label>
                <input
                  type="text"
                  id="stateLicense"
                  [(ngModel)]="searchCriteria.stateLicense"
                  name="stateLicense"
                  class="form-input"
                  placeholder="Enter state license"
                />
              </div>
              
              <div class="field-group">
                <label for="type1NPI">Type1 NPI</label>
                <input
                  type="text"
                  id="type1NPI"
                  [(ngModel)]="searchCriteria.type1NPI"
                  name="type1NPI"
                  class="form-input"
                  placeholder="Enter Type1 NPI"
                />
              </div>
              
              <div class="field-group">
                <label for="taxId">Tax ID</label>
                <input
                  type="text"
                  id="taxId"
                  [(ngModel)]="searchCriteria.taxId"
                  name="taxId"
                  class="form-input"
                  placeholder="Enter Tax ID"
                />
              </div>
              
              <div class="field-group">
                <label for="pin">PIN</label>
                <input
                  type="text"
                  id="pin"
                  [(ngModel)]="searchCriteria.pin"
                  name="pin"
                  class="form-input"
                  placeholder="Enter PIN"
                />
              </div>
              
              <div class="field-group">
                <label for="porticoId">Portico ID</label>
                <input
                  type="text"
                  id="porticoId"
                  [(ngModel)]="searchCriteria.porticoId"
                  name="porticoId"
                  class="form-input"
                  placeholder="Enter Portico ID"
                />
              </div>
            </div>
            
            <div class="form-actions">
              <button type="button" class="btn btn-secondary" (click)="onClear()">
                Clear
              </button>
              <button type="submit" class="btn btn-primary">
                Search
              </button>
            </div>
          </form>
        </div>

        <!-- Results Panel -->
        <div class="results-panel">
          <div class="panel-header">
            <h2>Search Results</h2>
            <span class="results-count" *ngIf="hasSearched()">
              <ng-container *ngIf="searchResults().length; else noResults">
                {{ searchResults().length }} records found
              </ng-container>
              <ng-template #noResults>No practitioners found</ng-template>
            </span>
            <span class="results-placeholder" *ngIf="!hasSearched()">
              Enter search criteria and click Search to view results
            </span>
          </div>

          <div class="results-content" *ngIf="hasSearched()">
            <div class="results-table-container" *ngIf="searchResults().length">
              <table class="results-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>PCP</th>
                    <th>License</th>
                    <th>NPI</th>
                    <th>Tax ID</th>
                    <th>Status</th>
                    <th>Portico ID</th>
                    <th>PIN</th>
                    <th>Cred Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr 
                    *ngFor="let practitioner of searchResults()" 
                    class="table-row"
                    (click)="onRowClick(practitioner)"
                    tabindex="0"
                    (keydown.enter)="onRowClick(practitioner)"
                    (keydown.space)="onRowClick(practitioner)"
                  >
                    <td class="practitioner-name">{{ practitioner.practitionerName }}</td>
                    <td>{{ practitioner.pcp }}</td>
                    <td>{{ practitioner.stateLicense }}</td>
                    <td>{{ practitioner.type1NPI }}</td>
                    <td>{{ practitioner.taxId }}</td>
                    <td>
                      <span class="status-badge" [class]="'status-' + practitioner.status.toLowerCase()">
                        {{ practitioner.status }}
                      </span>
                    </td>
                    <td>{{ practitioner.porticoId }}</td>
                    <td>{{ practitioner.pin }}</td>
                    <td>
                      <span class="cred-badge" [class]="'cred-' + practitioner.credStatus.toLowerCase().replace(' ', '-')">
                        {{ practitioner.credStatus }}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="no-results" *ngIf="!searchResults().length">
              <div class="no-results-icon">🔍</div>
              <h3>No Practitioners Found</h3>
              <p>Try adjusting your search criteria</p>
            </div>
          </div>

          <div class="empty-state" *ngIf="!hasSearched()">
            <div class="empty-state-icon">👨‍⚕️</div>
            <h3>Ready to Search</h3>
            <p>Enter criteria in the search panel and click Search to find practitioners</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Detail Modal -->
    <div class="detail-modal" *ngIf="selectedPractitioner()" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <header class="modal-header">
          <h2 class="modal-title">{{ selectedPractitioner()?.practitionerName }}</h2>
          <button class="close-btn" (click)="closeModal()">×</button>
        </header>

        <nav class="detail-tabs">
          <button
            *ngFor="let tab of detailTabs"
            class="tab-btn"
            [class.active]="activeTab() === tab.key"
            (click)="setActiveTab(tab.key)"
          >
            <span>{{ tab.icon }}</span>
            <span>{{ tab.label }}</span>
          </button>
        </nav>

        <div class="detail-content" #detailContent>
          <!-- Overview Tab -->
          <div *ngIf="activeTab() === 'overview'" class="content-grid">
            <div class="info-card">
              <h3>Basic Information</h3>
              <div class="info-field">
                <span class="field-label">Name:</span>
                <span class="field-value">{{ selectedPractitioner()?.practitionerName }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">PCP:</span>
                <span class="field-value">{{ selectedPractitioner()?.pcp }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Status:</span>
                <span class="field-value">
                  <span class="status-badge" [class]="selectedPractitioner()?.status ? 'status-' + selectedPractitioner()!.status.toLowerCase() : ''">
                    {{ selectedPractitioner()?.status }}
                  </span>
                </span>
              </div>
            </div>

            <div class="info-card">
              <h3>Identifiers</h3>
              <div class="info-field">
                <span class="field-label">State License:</span>
                <span class="field-value">{{ selectedPractitioner()?.stateLicense }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Type1 NPI:</span>
                <span class="field-value">{{ selectedPractitioner()?.type1NPI }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Tax ID:</span>
                <span class="field-value">{{ selectedPractitioner()?.taxId }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">PIN:</span>
                <span class="field-value">{{ selectedPractitioner()?.pin }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Portico ID:</span>
                <span class="field-value">{{ selectedPractitioner()?.porticoId }}</span>
              </div>
            </div>
          </div>

          <!-- Demographics Tab -->
          <div *ngIf="activeTab() === 'demographics'" class="content-grid">
            <div class="info-card">
              <h3>Personal Details</h3>
              <div class="info-field">
                <span class="field-label">Date of Birth:</span>
                <span class="field-value">March 15, 1985</span>
              </div>
              <div class="info-field">
                <span class="field-label">Gender:</span>
                <span class="field-value">Female</span>
              </div>
              <div class="info-field">
                <span class="field-label">Phone:</span>
                <span class="field-value">(555) 123-4567</span>
              </div>
              <div class="info-field">
                <span class="field-label">Email:</span>
                <span class="field-value">sarah.johnson@email.com</span>
              </div>
            </div>

            <div class="info-card">
              <h3>Address Information</h3>
              <div class="info-field">
                <span class="field-label">Primary Address:</span>
                <span class="field-value">123 Medical Plaza, Suite 456<br>Healthcare City, HC 12345</span>
              </div>
              <div class="info-field">
                <span class="field-label">Mailing Address:</span>
                <span class="field-value">Same as primary</span>
              </div>
            </div>
          </div>

          <!-- Designations Tab -->
          <div *ngIf="activeTab() === 'designations'" class="designation-list">
            <div class="designation-item">
              <div class="designation-primary">Primary Care Physician</div>
              <div class="designation-details">Board Certified Internal Medicine<br>Effective: 2010-01-01</div>
            </div>
            <div class="designation-item">
              <div class="designation-primary">Specialist</div>
              <div class="designation-details">Cardiology Specialist<br>Effective: 2015-06-15</div>
            </div>
          </div>

          <!-- Tasks/Attachments Tab -->
          <div *ngIf="activeTab() === 'tasks'">
            <div class="task-list">
              <div class="task-item">
                <div class="task-header">
                  <span class="task-title">License Renewal</span>
                  <span class="task-status priority-high">High Priority</span>
                </div>
                <div class="task-content">State medical license renewal due in 30 days</div>
                <div class="task-meta">
                  <span>Due: April 15, 2026</span>
                  <span>Assigned to: Admin Team</span>
                </div>
                <div class="attachment-list">
                  <a href="#" class="attachment-item">📄 License Application.pdf</a>
                  <a href="#" class="attachment-item">📋 Renewal Form.docx</a>
                </div>
              </div>
              <div class="task-item">
                <div class="task-header">
                  <span class="task-title">Credentialing Review</span>
                  <span class="task-status priority-medium">Medium Priority</span>
                </div>
                <div class="task-content">Annual credentialing review and documentation update</div>
                <div class="task-meta">
                  <span>Due: May 1, 2026</span>
                  <span>Assigned to: Credentialing Dept</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Credentialing Tab -->
          <div *ngIf="activeTab() === 'credentialing'" class="credential-list">
            <div class="credential-item">
              <div class="credential-header">
                <span class="credential-name">Medical License</span>
                <span class="credential-status cred-approved">Active</span>
              </div>
              <div class="credential-details">
                State: California<br>
                License #: CA123456<br>
                Issued: 2010-01-15<br>
                Expires: 2026-12-31
              </div>
            </div>
            <div class="credential-item">
              <div class="credential-header">
                <span class="credential-name">Board Certification</span>
                <span class="credential-status cred-approved">Current</span>
              </div>
              <div class="credential-details">
                Specialty: Internal Medicine<br>
                Board: American Board of Internal Medicine<br>
                Certified: 2012-03-20<br>
                Next Renewal: 2027-03-20
              </div>
            </div>
          </div>

          <!-- Comments Tab -->
          <div *ngIf="activeTab() === 'comments'" class="comments-list">
            <div class="comment-item">
              <div class="comment-header">
                <span class="comment-author">John Admin</span>
                <span class="comment-date">March 10, 2026 - 2:30 PM</span>
              </div>
              <div class="comment-content">
                License renewal documentation has been submitted to the state board. Waiting for approval.
              </div>
            </div>
            <div class="comment-item">
              <div class="comment-header">
                <span class="comment-author">Sarah Wilson</span>
                <span class="comment-date">March 8, 2026 - 10:15 AM</span>
              </div>
              <div class="comment-content">
                Updated contact information and verified current mailing address.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .inquiry-page {
      height: 100vh;
      display: flex;
      flex-direction: column;
      background: linear-gradient(135deg, #1e293b 0%, #334155 50%, #475569 100%);
      color: white;
      font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
      overflow: hidden;
      position: relative;
    }

    .inquiry-page::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: radial-gradient(circle at 20% 80%, rgba(14, 165, 233, 0.1) 0%, transparent 50%), 
                  radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.08) 0%, transparent 50%);
      pointer-events: none;
    }

    .inquiry-header {
      background: rgba(15, 23, 42, 0.8);
      padding: 1.25rem 2rem;
      border-bottom: 1px solid rgba(148, 163, 184, 0.2);
      backdrop-filter: blur(10px);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
      flex-shrink: 0;
      position: relative;
      z-index: 10;
    }

    .inquiry-header-title h1 {
      margin: 0;
      font-size: 1.75rem;
      font-weight: 700;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      letter-spacing: -0.025em;
    }

    .inquiry-header-title p {
      margin: 0.5rem 0 0 0;
      opacity: 0.7;
      font-size: 0.875rem;
      color: #cbd5e1;
      font-weight: 500;
    }

    .main-layout {
      display: flex;
      flex: 1;
      gap: 1.5rem;
      padding: 1.5rem;
      min-height: 0;
      position: relative;
      z-index: 5;
    }

    /* Search Panel */
    .search-panel {
      width: 380px;
      background: linear-gradient(145deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.9));
      border-radius: 16px;
      padding: 1.5rem;
      color: #334155;
      display: flex;
      flex-direction: column;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 
                  0 2px 8px rgba(0, 0, 0, 0.08),
                  inset 0 1px 0 rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
      flex-shrink: 0;
      backdrop-filter: blur(20px);
    }

    .panel-header {
      margin-bottom: 1.5rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid #e2e8f0;
    }

    .panel-header h2 {
      margin: 0 0 0.5rem 0;
      font-size: 1.375rem;
      font-weight: 700;
      color: #1e293b;
      letter-spacing: -0.025em;
    }

    .panel-header p {
      margin: 0;
      font-size: 0.875rem;
      color: #64748b;
      font-weight: 500;
    }

    .search-form {
      display: flex;
      flex-direction: column;
      flex: 1;
    }

    .form-fields {
      display: grid;
      grid-template-columns: 1fr;
      gap: 1rem;
      flex: 1;
    }

    .field-group {
      display: flex;
      flex-direction: column;
      position: relative;
    }

    .field-group label {
      font-size: 0.8rem;
      font-weight: 700;
      color: #475569;
      margin-bottom: 0.5rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .form-input {
      padding: 0.875rem 1rem;
      border: 2px solid #e2e8f0;
      border-radius: 10px;
      font-size: 0.9rem;
      font-weight: 500;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      background: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .form-input:focus {
      outline: none;
      border-color: #0ea5e9;
      box-shadow: 0 0 0 4px rgba(14, 165, 233, 0.1), 
                  0 4px 12px rgba(0, 0, 0, 0.1);
      transform: translateY(-1px);
    }

    .form-input::placeholder {
      color: #94a3b8;
      font-weight: 400;
    }

    .form-actions {
      display: flex;
      gap: 0.75rem;
      margin-top: 1.5rem;
      padding-top: 1.5rem;
      border-top: 2px solid #e2e8f0;
    }

    .btn {
      padding: 0.875rem 1.5rem;
      border: none;
      border-radius: 10px;
      font-size: 0.9rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      flex: 1;
      text-transform: uppercase;
      letter-spacing: 0.025em;
      position: relative;
      overflow: hidden;
    }

    .btn-primary {
      background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
      color: white;
      box-shadow: 0 4px 12px rgba(14, 165, 233, 0.4);
    }

    .btn-primary:hover {
      background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(14, 165, 233, 0.5);
    }

    .btn-primary:active {
      transform: translateY(0);
    }

    .btn-secondary {
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      color: #475569;
      border: 2px solid #e2e8f0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    .btn-secondary:hover {
      background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%);
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
    }

    /* Results Panel */
    .results-panel {
      flex: 1;
      background: linear-gradient(145deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.9));
      border-radius: 16px;
      padding: 1.5rem;
      color: #334155;
      display: flex;
      flex-direction: column;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 
                  0 2px 8px rgba(0, 0, 0, 0.08),
                  inset 0 1px 0 rgba(255, 255, 255, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
      min-height: 0;
      backdrop-filter: blur(20px);
    }

    .results-count {
      font-size: 0.875rem;
      color: #0ea5e9;
      font-weight: 700;
      background: linear-gradient(135deg, rgba(14, 165, 233, 0.1), rgba(2, 132, 199, 0.05));
      padding: 0.5rem 1rem;
      border-radius: 8px;
      border: 1px solid rgba(14, 165, 233, 0.2);
    }

    .results-placeholder {
      font-size: 0.875rem;
      color: #64748b;
      font-style: italic;
      font-weight: 500;
    }

    .results-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
    }

    .results-table-container {
      flex: 1;
      overflow-y: auto;
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      margin-top: 1rem;
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .results-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.85rem;
    }

    .results-table thead {
      background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
      position: sticky;
      top: 0;
    }

    .results-table th {
      padding: 1rem 0.75rem;
      text-align: left;
      font-weight: 700;
      color: #374151;
      border-bottom: 2px solid #cbd5e1;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .results-table td {
      padding: 0.875rem 0.75rem;
      border-bottom: 1px solid #e2e8f0;
      font-weight: 500;
    }

    .table-row {
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .table-row:hover {
      background: linear-gradient(135deg, rgba(14, 165, 233, 0.04), rgba(2, 132, 199, 0.02));
      transform: scale(1.001);
    }

    .table-row:focus {
      outline: 2px solid #0ea5e9;
      outline-offset: -2px;
      background: rgba(14, 165, 233, 0.05);
    }

    .practitioner-name {
      font-weight: 700;
      color: #1e293b;
    }

    .status-badge, .cred-badge {
      padding: 0.375rem 0.75rem;
      border-radius: 8px;
      font-size: 0.7rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .status-active {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
    }

    .status-inactive {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      color: white;
    }

    .cred-approved {
      background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
      color: white;
    }

    .cred-pending {
      background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
      color: white;
    }

    .cred-in-progress {
      background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
      color: white;
    }

    /* Empty States */
    .no-results, .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #64748b;
    }

    .no-results-icon, .empty-state-icon {
      font-size: 4rem;
      margin-bottom: 1.5rem;
      opacity: 0.6;
      filter: grayscale(1);
    }

    .no-results h3, .empty-state h3 {
      margin: 0 0 0.75rem 0;
      font-size: 1.5rem;
      color: #374151;
      font-weight: 700;
    }

    .no-results p, .empty-state p {
      margin: 0;
      font-size: 1rem;
      font-weight: 500;
    }

    /* Modal Styles */
    .detail-modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(15, 23, 42, 0.8);
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(8px);
    }

    .modal-content {
      width: 90%;
      height: 90%;
      max-width: 1200px;
      background: white;
      border-radius: 20px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-shadow: 0 25px 50px rgba(0, 0, 0, 0.4);
    }

    .modal-header {
      background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
      color: white;
      padding: 1.5rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-shrink: 0;
    }

    .modal-title {
      font-size: 1.5rem;
      font-weight: 700;
      margin: 0;
    }

    .close-btn {
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
      padding: 0.75rem;
      border-radius: 8px;
      transition: background-color 0.2s ease;
    }

    .close-btn:hover {
      background: rgba(255, 255, 255, 0.1);
    }

    .detail-tabs {
      display: flex;
      background: #f8fafc;
      border-bottom: 1px solid #e2e8f0;
      overflow-x: auto;
      flex-shrink: 0;
    }

    .tab-btn {
      flex: 1;
      padding: 1.25rem;
      border: none;
      background: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      font-size: 0.9rem;
      font-weight: 600;
      color: #64748b;
      transition: all 0.3s ease;
      border-bottom: 3px solid transparent;
      white-space: nowrap;
    }

    .tab-btn.active {
      color: #0ea5e9;
      background: white;
      border-bottom-color: #0ea5e9;
    }

    .tab-btn:hover:not(.active) {
      background: rgba(14, 165, 233, 0.05);
      color: #475569;
    }

    .detail-content {
      flex: 1;
      overflow-y: auto;
      padding: 2rem;
      background: white;
    }

    .content-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .info-card {
      background: #f8fafc;
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .info-card h3 {
      margin: 0 0 1rem 0;
      font-size: 1.125rem;
      font-weight: 700;
      color: #1e293b;
    }

    .info-field {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem 0;
      border-bottom: 1px solid #e2e8f0;
    }

    .info-field:last-child {
      border-bottom: none;
    }

    .field-label {
      font-weight: 600;
      color: #475569;
    }

    .field-value {
      color: #1e293b;
      font-weight: 500;
    }

    .task-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .task-item {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 1rem;
    }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
    }

    .task-title {
      font-weight: 600;
      color: #1f2937;
    }

    .task-status {
      padding: 0.25rem 0.5rem;
      border-radius: 8px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .task-content {
      color: #6b7280;
      margin-bottom: 0.5rem;
      font-size: 0.9rem;
    }

    .task-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 0.8rem;
      color: #9ca3af;
    }

    .attachment-list {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 0.5rem;
    }

    .attachment-item {
      display: flex;
      align-items: center;
      gap: 0.25rem;
      padding: 0.25rem 0.5rem;
      background: #e5e7eb;
      border-radius: 8px;
      font-size: 0.75rem;
      color: #374151;
      text-decoration: none;
    }

    .attachment-item:hover {
      background: #d1d5db;
    }

    .designation-list {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
    }

    .designation-item {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 1rem;
    }

    .designation-primary {
      font-weight: 600;
      color: #1f2937;
      margin-bottom: 0.25rem;
    }

    .designation-details {
      font-size: 0.875rem;
      color: #6b7280;
    }

    .credential-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .credential-item {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 1rem;
    }

    .credential-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
    }

    .credential-name {
      font-weight: 600;
      color: #1f2937;
    }

    .credential-status {
      padding: 0.25rem 0.5rem;
      border-radius: 8px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .credential-details {
      color: #6b7280;
      font-size: 0.875rem;
      line-height: 1.4;
    }

    .comments-list {
      padding: 1.5rem;
    }

    .comment-item {
      padding: 1rem;
      border-left: 3px solid #e5e7eb;
      margin-bottom: 1rem;
      background: #f9fafb;
      border-radius: 0 12px 12px 0;
    }

    .comment-item:last-child {
      margin-bottom: 0;
    }

    .comment-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
    }

    .comment-author {
      font-weight: 600;
      color: #1f2937;
    }

    .comment-date {
      font-size: 0.8rem;
      color: #9ca3af;
    }

    .comment-content {
      color: #374151;
      line-height: 1.5;
    }

    .priority-badge {
      padding: 0.375rem 0.75rem;
      border-radius: 8px;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .priority-high {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      color: white;
    }

    .priority-medium {
      background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
      color: white;
    }

    .priority-low {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .main-layout {
        flex-direction: column;
        padding: 1rem;
      }

      .search-panel {
        width: 100%;
      }

      .form-fields {
        grid-template-columns: repeat(2, 1fr);
        gap: 0.75rem;
      }

      .results-table {
        font-size: 0.75rem;
      }

      .results-table th,
      .results-table td {
        padding: 0.5rem;
      }

      .modal-content {
        width: 95%;
        height: 95%;
      }

      .content-grid {
        grid-template-columns: 1fr;
      }

      .detail-tabs {
        overflow-x: scroll;
      }

      .tab-btn {
        padding: 1rem;
        font-size: 0.8rem;
      }
    }

    @media (max-width: 480px) {
      .form-fields {
        grid-template-columns: 1fr;
      }

      .inquiry-header {
        padding: 1rem;
      }

      .main-layout {
        padding: 0.75rem;
      }
    }
  `]
})
export class PractitionerInquiryComponent {
  @ViewChild('resultsSection') resultsSection!: ElementRef;
  @ViewChild('detailContent') detailContent!: ElementRef;
  
  searchCriteria: SearchCriteria = {
    firstName: '',
    lastName: '',
    stateLicense: '',
    type1NPI: '',
    taxId: '',
    pin: '',
    porticoId: ''
  };

  searchResults = signal<PractitionerRecord[]>([]);
  hasSearched = signal<boolean>(false);
  selectedPractitioner = signal<PractitionerRecord | null>(null);
  activeTab = signal<DetailTab>('overview');

  detailTabs = [
    { key: 'overview' as DetailTab, label: 'Overview', icon: '📋' },
    { key: 'demographics' as DetailTab, label: 'Demographics', icon: '👤' },
    { key: 'designations' as DetailTab, label: 'Designations', icon: '🎓' },
    { key: 'tasks' as DetailTab, label: 'Tasks/Attachments', icon: '📋' },
    { key: 'credentialing' as DetailTab, label: 'Credentialing', icon: '🏆' },
    { key: 'comments' as DetailTab, label: 'Comments', icon: '💬' }
  ];

  // Mock data for demonstration
  private mockData: PractitionerRecord[] = [
    {
      id: 1,
      practitionerName: 'Dr. Sarah Johnson',
      pcp: 'Yes',
      stateLicense: 'CA123456',
      type1NPI: '1234567890',
      taxId: '12-3456789',
      status: 'Active',
      porticoId: 'P001234',
      pin: '5678',
      credStatus: 'Approved'
    },
    {
      id: 2,
      practitionerName: 'Dr. Michael Chen',
      pcp: 'No',
      stateLicense: 'NY987654',
      type1NPI: '0987654321',
      taxId: '98-7654321',
      status: 'Active',
      porticoId: 'P005678',
      pin: '1234',
      credStatus: 'Pending'
    },
    {
      id: 3,
      practitionerName: 'Dr. Emily Rodriguez',
      pcp: 'Yes',
      stateLicense: 'TX456789',
      type1NPI: '4567890123',
      taxId: '45-6789012',
      status: 'Inactive',
      porticoId: 'P009012',
      pin: '9876',
      credStatus: 'In Progress'
    }
  ];

  onSearch(): void {
    console.log('Search criteria:', this.searchCriteria);
    
    // Simulate API call with mock data
    let results = this.mockData;

    // Apply filters based on search criteria
    if (this.searchCriteria.firstName) {
      results = results.filter(p => 
        p.practitionerName.toLowerCase().includes(this.searchCriteria.firstName.toLowerCase())
      );
    }
    if (this.searchCriteria.lastName) {
      results = results.filter(p => 
        p.practitionerName.toLowerCase().includes(this.searchCriteria.lastName.toLowerCase())
      );
    }
    if (this.searchCriteria.stateLicense) {
      results = results.filter(p => 
        p.stateLicense.toLowerCase().includes(this.searchCriteria.stateLicense.toLowerCase())
      );
    }
    if (this.searchCriteria.type1NPI) {
      results = results.filter(p => 
        p.type1NPI.includes(this.searchCriteria.type1NPI)
      );
    }
    if (this.searchCriteria.taxId) {
      results = results.filter(p => 
        p.taxId.includes(this.searchCriteria.taxId)
      );
    }
    if (this.searchCriteria.pin) {
      results = results.filter(p => 
        p.pin.includes(this.searchCriteria.pin)
      );
    }
    if (this.searchCriteria.porticoId) {
      results = results.filter(p => 
        p.porticoId.toLowerCase().includes(this.searchCriteria.porticoId.toLowerCase())
      );
    }

    this.searchResults.set(results);
    this.hasSearched.set(true);

    // Auto-scroll to results if found
    setTimeout(() => {
      if (this.resultsSection && results.length > 0) {
        this.resultsSection.nativeElement.scrollIntoView({ 
          behavior: 'smooth',
          block: 'start'
        });
      }
    }, 100);
  }

  onClear(): void {
    this.searchCriteria = {
      firstName: '',
      lastName: '',
      stateLicense: '',
      type1NPI: '',
      taxId: '',
      pin: '',
      porticoId: ''
    };
    this.searchResults.set([]);
    this.hasSearched.set(false);
  }

  onRowClick(practitioner: PractitionerRecord): void {
    this.selectedPractitioner.set(practitioner);
    this.activeTab.set('overview');
  }

  closeModal(): void {
    this.selectedPractitioner.set(null);
  }

  setActiveTab(tab: DetailTab): void {
    this.activeTab.set(tab);
    // Scroll to top of content when switching tabs
    setTimeout(() => {
      if (this.detailContent) {
        this.detailContent.nativeElement.scrollTop = 0;
      }
    }, 0);
  }
}