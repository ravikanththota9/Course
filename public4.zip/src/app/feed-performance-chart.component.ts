import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import type Highcharts from 'highcharts';
import { FeedPerformancePoint } from './information-feeds.service';
import { CommonModule } from '@angular/common';
import { HighchartsChartComponent } from 'highcharts-angular';

@Component({
  selector: 'app-feed-performance-chart',
  standalone: true,
  imports: [CommonModule, HighchartsChartComponent],
  template: `
    <highcharts-chart
      *ngIf="chartOptions && data.length"
      [options]="chartOptions"
      style="width: 100%; height: 260px; display: block;"
    ></highcharts-chart>
    <p *ngIf="data.length === 0" class="chart-empty">No performance data available for this range.</p>
  `,
  styles: [
    `
      .chart-empty {
        margin: 0.25rem 0 0;
        font-size: 0.8rem;
        color: #9ca3af;
      }
    `,
  ],
})
export class FeedPerformanceChartComponent implements OnChanges {
  @Input() data: FeedPerformancePoint[] = [];
  @Input() feedName = '';
  @Input() rangeDays: number | string = 10;
  chartOptions: Highcharts.Options | undefined;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['data'] || changes['feedName'] || changes['rangeDays']) {
      this.buildOptions();
    }
  }

  private buildOptions(): void {
    if (!this.data || this.data.length === 0) {
      this.chartOptions = undefined;
      return;
    }

    const categories = this.data.map((p) => p.date);
    const durations = this.data.map((p) => p.duration);

    this.chartOptions = {
      title: {
        text: `${this.feedName || 'Feed'} - Last ${this.rangeDays} Days Performance`,
        style: {
          fontSize: '12px',
        },
      },
      credits: { enabled: false },
      legend: { enabled: false },
      chart: {
        type: 'line',
        height: 260,
        backgroundColor: 'transparent',
      },
      xAxis: {
        categories,
        title: { text: 'Date' },
        labels: {
          rotation: -35,
        },
      },
      yAxis: {
        title: { text: 'Duration (minutes)' },
        min: 0,
      },
      tooltip: {
        shared: true,
        valueSuffix: ' min',
      },
      series: [
        {
          type: 'line',
          name: 'Duration',
          data: durations,
          color: '#2563eb',
          marker: {
            enabled: true,
            radius: 3,
          },
        },
      ],
    };
  }
}
