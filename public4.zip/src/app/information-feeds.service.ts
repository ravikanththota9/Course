import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

export interface FeedDefinition {
  id: number;
  name: string;
  description: string;
}

export interface FeedPerformancePoint {
  date: string; // ISO date, e.g. 2026-02-15
  duration: number; // duration in minutes
}

export type EnvironmentKey = 'Portico' | 'Pods';

@Injectable({ providedIn: 'root' })
export class InformationFeedsService {
  private readonly porticoFeedsUrl = '/api/metadata/pi-feeds';
  private readonly podsFeedsUrl = '/api/metadata/feeds';
  private readonly porticoFeedRunsUrl = '/api/metadata/pi-feedruns';
  private readonly podsFeedRunsUrl = '/api/metadata/feedruns';

  // Mock data for fallback when API is not available
  private readonly mockFeedsByEnvironment: Record<EnvironmentKey, FeedDefinition[]> = {
    Portico: [
      {
        id: 100001,
        name: 'FacetsOutFeedEngine',
        description: 'Facets Out Feed Engine',
      },
      {
        id: 100408,
        name: 'CAQHDirExtratFeed',
        description: 'CAQH Dir Extract Feed',
      },
    ],
    Pods: [
      {
        id: 1124,
        name: 'BDC IN FEED',
        description: 'BDC IN FEED',
      },
      {
        id: 1404,
        name: 'Facility Data to BDC',
        description: 'Facility Data to BDC',
      },
    ],
  };

  // Temporary stub: in a real app this would be
  // replaced with an HTTP call to a backend API.
  private readonly basePerformance: FeedPerformancePoint[] = [
    { date: '2026-02-15', duration: 45 },
    { date: '2026-02-16', duration: 52 },
    { date: '2026-02-17', duration: 380 },
    { date: '2026-02-18', duration: 4200 },
    { date: '2026-02-19', duration: 120 },
    { date: '2026-02-20', duration: 240 },
    { date: '2026-02-21', duration: 90 },
    { date: '2026-02-22', duration: 300 },
    { date: '2026-02-23', duration: 60 },
    { date: '2026-02-24', duration: 180 },
    { date: '2026-02-25', duration: 75 },
    { date: '2026-02-26', duration: 210 },
    { date: '2026-02-27', duration: 95 },
    { date: '2026-02-28', duration: 130 },
    { date: '2026-03-01', duration: 260 },
    { date: '2026-03-02', duration: 310 },
    { date: '2026-03-03', duration: 140 },
    { date: '2026-03-04', duration: 480 },
    { date: '2026-03-05', duration: 520 },
    { date: '2026-03-06', duration: 160 },
    { date: '2026-03-07', duration: 190 },
    { date: '2026-03-08', duration: 210 },
    { date: '2026-03-09', duration: 230 },
    { date: '2026-03-10', duration: 260 },
    { date: '2026-03-11', duration: 300 },
    { date: '2026-03-12', duration: 340 },
    { date: '2026-03-13', duration: 280 },
    { date: '2026-03-14', duration: 320 },
    { date: '2026-03-15', duration: 360 },
    { date: '2026-03-16', duration: 400 },
    { date: '2026-03-17', duration: 420 },
    { date: '2026-03-18', duration: 380 },
    { date: '2026-03-19', duration: 390 },
    { date: '2026-03-20', duration: 410 },
    { date: '2026-03-21', duration: 430 },
    { date: '2026-03-22', duration: 450 },
    { date: '2026-03-23', duration: 470 },
    { date: '2026-03-24', duration: 490 },
    { date: '2026-03-25', duration: 510 },
    { date: '2026-03-26', duration: 530 },
    { date: '2026-03-27', duration: 550 },
    { date: '2026-03-28', duration: 570 },
    { date: '2026-03-29', duration: 590 },
    { date: '2026-03-30', duration: 610 },
    { date: '2026-03-31', duration: 630 },
    { date: '2026-04-01', duration: 650 },
    { date: '2026-04-02', duration: 670 },
    { date: '2026-04-03', duration: 690 },
    { date: '2026-04-04', duration: 710 },
    { date: '2026-04-05', duration: 730 },
    { date: '2026-04-06', duration: 750 },
    { date: '2026-04-07', duration: 770 },
    { date: '2026-04-08', duration: 790 },
    { date: '2026-04-09', duration: 810 },
    { date: '2026-04-10', duration: 830 },
  ];

  constructor(private readonly http: HttpClient) {}

  getEnvironments(): EnvironmentKey[] {
    return ['Portico', 'Pods'];
  }

  getFeeds(environment: EnvironmentKey | ''): Observable<FeedDefinition[]> {
    if (!environment) {
      return of([]);
    }

    if (environment === 'Portico') {
      return this.getPorticoFeeds();
    }

    if (environment === 'Pods') {
      return this.getPodsFeeds();
    }

    return of([]);
  }

  private getPorticoFeeds(): Observable<FeedDefinition[]> {
    return this.http.get<unknown>(this.porticoFeedsUrl).pipe(
      map((response) => this.normalizePorticoFeeds(response)),
      catchError(() => {
        // Return empty array if API fails - show no data in dropdown
        return of([]);
      })
    );
  }

  private normalizePorticoFeeds(raw: unknown): FeedDefinition[] {
    const feeds = Array.isArray(raw) ? raw : [];
    
    return feeds
      .filter((feed): feed is Record<string, unknown> => !!feed && typeof feed === 'object')
      .map((feed) => {
        const id = Number(feed['id'] ?? feed['feedId'] ?? feed['feed_id'] ?? 0);
        const name = String(feed['name'] ?? feed['feedName'] ?? feed['feed_name'] ?? '');
        const description = String(feed['description'] ?? feed['desc'] ?? name);
        
        return {
          id,
          name,
          description
        } satisfies FeedDefinition;
      })
      .filter((feed) => feed.id > 0 && feed.name.trim() !== '');
  }

  private getPodsFeeds(): Observable<FeedDefinition[]> {
    return this.http.get<unknown>(this.podsFeedsUrl).pipe(
      map((response) => this.normalizePodsFeeds(response)),
      catchError(() => {
        // Return empty array if API fails - show no data in dropdown
        return of([]);
      })
    );
  }

  private normalizePodsFeeds(raw: unknown): FeedDefinition[] {
    const feeds = Array.isArray(raw) ? raw : [];
    
    return feeds
      .filter((feed): feed is Record<string, unknown> => !!feed && typeof feed === 'object')
      .map((feed) => {
        const id = Number(feed['id'] ?? feed['feedId'] ?? feed['feed_id'] ?? 0);
        const name = String(feed['name'] ?? feed['feedName'] ?? feed['feed_name'] ?? '');
        const description = String(feed['description'] ?? feed['desc'] ?? name);
        
        return {
          id,
          name,
          description
        } satisfies FeedDefinition;
      })
      .filter((feed) => feed.id > 0 && feed.name.trim() !== '');
  }

  getFeedPerformance(feedId: number, runs: 10 | 30 | 50 | 90): Observable<FeedPerformancePoint[]> {
    // Use API for both Portico and Pods feeds
    const isPorticoFeed = this.isPorticoFeed(feedId);
    
    if (isPorticoFeed) {
      return this.getPorticoFeedPerformance(feedId, runs);
    } else {
      return this.getPodsFeedPerformance(feedId, runs);
    }
  }

  private isPorticoFeed(feedId: number): boolean {
    // Check if this feedId belongs to Portico environment
    // Simple check: Portico feeds typically have higher IDs (100000+)
    return feedId >= 100000;
  }

  private getPorticoFeedPerformance(feedId: number, runs: 10 | 30 | 50 | 90): Observable<FeedPerformancePoint[]> {
    const url = `${this.porticoFeedRunsUrl}/${feedId}?limit=${runs}`;
    
    return this.http.get<unknown>(url).pipe(
      map((response) => this.normalizePerformanceData(response)),
      catchError(() => {
        // Return empty array if API fails - show "no data found"
        return of([]);
      })
    );
  }

  private getPodsFeedPerformance(feedId: number, runs: 10 | 30 | 50 | 90): Observable<FeedPerformancePoint[]> {
    const url = `${this.podsFeedRunsUrl}/${feedId}?limit=${runs}`;
    
    return this.http.get<unknown>(url).pipe(
      map((response) => this.normalizePerformanceData(response)),
      catchError(() => {
        // Return empty array if API fails - show "no data found"
        return of([]);
      })
    );
  }

  private normalizePerformanceData(raw: unknown): FeedPerformancePoint[] {
    const data = Array.isArray(raw) ? raw : [];
    
    return data
      .filter((item): item is Record<string, unknown> => !!item && typeof item === 'object')
      .map((item) => {
        const dateRaw = item['date'] ?? item['runDate'] ?? item['run_date'] ?? item['timestamp'];
        const date = typeof dateRaw === 'string' ? dateRaw : new Date().toISOString().split('T')[0];
        
        const durationRaw = item['duration'] ?? item['executionTime'] ?? item['execution_time'] ?? item['runtime'];
        const duration = Number(durationRaw) || 0;
        
        return {
          date,
          duration
        } satisfies FeedPerformancePoint;
      })
      .filter((point) => point.duration >= 0);
  }
}
