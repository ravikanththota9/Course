import { Routes } from '@angular/router';
import { HomePageComponent } from './home-page.component';
import { MetricsPageComponent } from './metrics-page.component';
import { DataAdministratorPageComponent } from './data-administrator-page.component';
import { BusinessAdministratorPageComponent } from './business-administrator-page.component';
import { SecurityAdministratorPageComponent } from './security-administrator-page.component';
import { PractitionerInquiryComponent } from './practitioner-inquiry.component';
import { ProviderInquiryComponent } from './provider-inquiry.component';

export const routes: Routes = [
	{ path: '', component: HomePageComponent },
	{ path: 'feeds/metrics', component: MetricsPageComponent },
	{ path: 'administration/data-administrator', component: DataAdministratorPageComponent },
	{ path: 'administration/business-administrator', component: BusinessAdministratorPageComponent },
	{ path: 'administration/security-administrator', component: SecurityAdministratorPageComponent },
	{ path: 'wizards/practitioner-inquiry', component: PractitionerInquiryComponent },
	{ path: 'wizards/provider-inquiry', component: ProviderInquiryComponent },
	{ path: '**', redirectTo: '' }
];
