import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, signal, computed, inject } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';

import {
	DataAdministratorService,
	DataColumnDefinition,
	DataRecord,
	DataRecordValue,
	DataTableDefinition,
} from './data-administrator.service';

@Component({
	selector: 'app-data-administrator-page',
	imports: [CommonModule, FormsModule],
	changeDetection: ChangeDetectionStrategy.OnPush,
	template: `
		<section class="admin-page">
			<header class="admin-header">
				<div class="admin-header-title">
					<h1>Data Administrator</h1>
					<p>Administration → Data Administrator</p>
				</div>
			</header>

			<div class="admin-layout">
				<aside class="panel">
					<div class="panel-header">
						<div>
							<h2>Tables</h2>
							<p>Select a table to view and manage data.</p>
						</div>
					</div>

					<div class="toolbar">
						<div class="toolbar-search">
							<input
								type="text"
								[ngModel]="tableSearch()"
								(ngModelChange)="tableSearch.set($event)"
								placeholder="Search tables..."
								aria-label="Search tables"
							/>
						</div>
					</div>

					<div class="table-list" role="list">
						<div class="table-loading" *ngIf="isLoadingTables()">
							<div class="table-loading-spinner"></div>
							<div class="table-loading-text">Loading tables...</div>
						</div>
						<button
							*ngFor="let t of filteredTables()"
							class="table-item"
							type="button"
							role="listitem"
							[class.active]="t.key === selectedTableKey()"
							(click)="selectTable(t)"
						>
							<span class="table-item-name">{{ t.name }}</span>
							<span class="table-item-desc">{{ t.description }}</span>
						</button>
						<div class="table-item-desc" *ngIf="!isLoadingTables() && filteredTables().length === 0">
							No tables match your search.
						</div>
					</div>
				</aside>

				<main class="panel">
					<div class="panel-header">
						<div class="panel-header-main">
							<h2>
								{{ selectedTable()?.name || 'Table Data' }}
							</h2>
							<p *ngIf="selectedTable()">{{ selectedTable()!.description }}</p>
							<p *ngIf="!selectedTable()">Select a table to load records.</p>
						</div>
						<div class="panel-header-meta" *ngIf="selectedTable()">
							<span class="meta-pill">{{ filteredRecords().length }} records</span>
						</div>
					</div>

					<div class="toolbar" *ngIf="selectedTable()">
						<div class="toolbar-search">
							<input
								id="recordSearch"
								type="text"
								[ngModel]="recordSearch()"
								(ngModelChange)="recordSearch.set($event)"
								placeholder="Search records..."
								aria-label="Search records"
							/>
						</div>
						<div class="toolbar-actions">
							<button class="btn btn-primary" type="button" (click)="openCreate()">New record</button>
						</div>
					</div>

					<div
						class="banner"
						*ngIf="banner() as b"
						[class.banner--success]="b.type === 'success'"
						[class.banner--error]="b.type === 'error'"
						[attr.role]="b.type === 'error' ? 'alert' : 'status'"
					>
						<div class="banner-text">{{ b.message }}</div>
						<button class="banner-close" type="button" (click)="clearBanner()" aria-label="Dismiss message">
							✕
						</button>
					</div>

					<div class="table-wrap" *ngIf="selectedTable() || isLoadingRecords()">
						<div class="loading-overlay" *ngIf="isLoadingRecords()">
							<div class="loading-spinner"></div>
							<div class="loading-text">Loading table data...</div>
						</div>
						<table class="data-table" aria-label="Table records" *ngIf="selectedTable() && !isLoadingRecords()">
							<thead>
								<tr>
									<th *ngFor="let c of selectedTable()!.columns" scope="col">{{ c.label }}</th>
									<th scope="col" class="col-actions">Actions</th>
								</tr>
							</thead>
							<tbody>
								<tr *ngFor="let r of filteredRecords()">
									<td *ngFor="let c of selectedTable()!.columns">{{ formatValue(r[c.key], c) }}</td>
									<td class="col-actions">
										<div class="row-actions">
											<button class="btn btn-sm" type="button" (click)="openEdit(r)">Edit</button>
											<button class="btn btn-danger btn-sm" type="button" (click)="requestDelete(r)">Delete</button>
										</div>
									</td>
								</tr>
								<tr *ngIf="!isLoadingRecords() && filteredRecords().length === 0">
									<td [attr.colspan]="selectedTable()!.columns.length + 1" class="empty-row">
										No records found.
									</td>
								</tr>
							</tbody>
						</table>
					</div>

					<section #editorSection class="editor" *ngIf="editorOpen()">
						<header class="editor-header">
							<div>
								<h3>{{ editorMode() === 'create' ? 'New record' : 'Edit record' }}</h3>
								<p>{{ selectedTable()!.name }}</p>
							</div>
							<button class="btn" type="button" (click)="closeEditor()">Close</button>
						</header>

						<form #editorForm="ngForm" class="editor-form" (ngSubmit)="save(editorForm)">
							<div class="editor-grid">
								<ng-container *ngFor="let c of selectedTable()!.columns">
									<div class="editor-field" *ngIf="!c.readOnly">
										<label *ngIf="c.type !== 'boolean'" [attr.for]="'field-' + c.key">
											{{ c.label }}<span class="req" *ngIf="isFieldRequired(c)">*</span>
										</label>

										<input
										*ngIf="c.type === 'text'"
										[attr.id]="'field-' + c.key"
										type="text"
										[ngModel]="getDraftValue(c.key)"
										(ngModelChange)="setDraftValue(c.key, $event)"
										[name]="c.key"
										[required]="isFieldRequired(c)"
										[attr.maxlength]="c.maxLength ?? null"
										[disabled]="!!c.readOnly"
									/>

										<input
										*ngIf="c.type === 'number'"
										[attr.id]="'field-' + c.key"
										type="number"
										[ngModel]="getDraftValue(c.key)"
										(ngModelChange)="setDraftValue(c.key, $event)"
										[name]="c.key"
										[required]="isFieldRequired(c)"
										[disabled]="!!c.readOnly"
									/>

										<input
										*ngIf="c.type === 'date'"
										[attr.id]="'field-' + c.key"
										type="date"
										[ngModel]="getDraftValue(c.key)"
										(ngModelChange)="setDraftValue(c.key, $event)"
										[name]="c.key"
										[required]="isFieldRequired(c)"
										[disabled]="!!c.readOnly"
									/>

										<label class="check" *ngIf="c.type === 'boolean'">
											<input
											[attr.id]="'field-' + c.key"
											type="checkbox"
											[ngModel]="getDraftValue(c.key)"
											(ngModelChange)="setDraftValue(c.key, $event)"
											[name]="c.key"
											[disabled]="!!c.readOnly"
										/>
										<span>{{ c.label }}</span>
										</label>
									</div>
								</ng-container>
							</div>

							<div class="editor-actions">
								<button class="btn btn-primary" type="submit" [disabled]="editorForm.invalid">Save</button>
								<button class="btn" type="button" (click)="closeEditor()">Cancel</button>
							</div>
						</form>
					</section>
				</main>
			</div>

			<div class="modal-overlay" *ngIf="deleteConfirmOpen()" (click)="cancelDelete()">
				<div
					class="modal-card"
					role="dialog"
					aria-modal="true"
					aria-labelledby="deleteTitle"
					(click)="$event.stopPropagation()"
				>
					<h3 class="modal-title" id="deleteTitle">Confirm delete</h3>
					<p class="modal-text">
						This will permanently delete {{ pendingDelete()?.label || 'this record' }}. This action cannot be undone.
					</p>
					<div class="modal-actions">
						<button class="btn" type="button" (click)="cancelDelete()">Cancel</button>
						<button class="btn btn-danger" type="button" (click)="confirmDelete()">Delete</button>
					</div>
				</div>
			</div>

			<!-- Access Permission Modal -->
			<div class="modal-overlay" *ngIf="accessDeniedOpen()" (click)="closeAccessDenied()">
				<div
					class="modal-card access-denied-modal"
					role="dialog"
					aria-modal="true"
					aria-labelledby="accessTitle"
					(click)="$event.stopPropagation()"
				>
					<div class="modal-icon">🔒</div>
					<h3 class="modal-title" id="accessTitle">Access Denied</h3>
					<p class="modal-text">
						Sorry, You do not have sufficient access privileges to modify the data in this table. Please contact your administrator.
					</p>
					<div class="modal-actions">
						<button class="btn btn-primary" type="button" (click)="closeAccessDenied()">OK</button>
					</div>
				</div>
			</div>
		</section>
	`,
	styles: [
		`
			* {
				box-sizing: border-box;
			}

			.admin-page {
				max-width: 1400px;
				margin: 0 auto;
				padding-top: 0.5rem;
				display: flex;
				flex-direction: column;
				gap: 1rem;
			}

			.admin-header {
				padding: 0.4rem 0.9rem;
				border-radius: 0.45rem;
				background: linear-gradient(90deg, #eff6ff, #e0f2fe);
				border: 1px solid #dbeafe;
				border-left-width: 3px;
				border-left-color: #2563eb;
			}

			.admin-header h1 {
				margin: 0;
				font-size: 1.05rem;
				color: #111827;
			}

			.admin-header p {
				margin: 0.08rem 0 0;
				color: #6b7280;
				font-size: 0.8rem;
			}

			.admin-layout {
				display: grid;
				grid-template-columns: 280px minmax(0, 1fr);
				gap: 1rem;
				align-items: start;
			}

			.panel {
				padding: 0;
				border-radius: 0.6rem;
				background-color: #ffffff;
				border: 1px solid #e5e7eb;
				min-width: 0;
			}

			.panel-header {
				padding: 0.75rem 0.9rem;
				display: flex;
				align-items: flex-start;
				justify-content: space-between;
				gap: 0.75rem;
				border-bottom: 1px solid #eef2f7;
			}

			.panel-header h2 {
				margin: 0;
				font-size: 0.95rem;
				color: #111827;
			}

			.panel-header p {
				margin: 0.12rem 0 0;
				font-size: 0.8rem;
				color: #6b7280;
			}

			.meta-pill {
				color: #64748b;
				font-size: 0.75rem;
				font-weight: 800;
			}

			.table-list {
				display: flex;
				flex-direction: column;
				padding: 0.5rem;
				gap: 0.5rem;
				max-height: 58vh;
				overflow: auto;
			}

			.table-item {
				text-align: left;
				border: 1px solid #e5e7eb;
				background: #ffffff;
				border-radius: 0.55rem;
				padding: 0.65rem 0.7rem;
				cursor: pointer;
			}

			.table-item:hover {
				border-color: #cbd5e1;
				background: #f8fafc;
			}

			.table-item.active {
				border-color: #93c5fd;
				background: linear-gradient(90deg, #dbeafe, #ffffff);
			}

			.table-item-name {
				display: block;
				font-size: 0.9rem;
				font-weight: 700;
				color: #0f172a;
			}

			.table-item-desc {
				display: block;
				margin-top: 0.15rem;
				font-size: 0.75rem;
				color: #64748b;
				line-height: 1.2;
			}

			.toolbar {
				padding: 0.75rem 0.9rem;
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 0.75rem;
				flex-wrap: wrap;
				row-gap: 0.6rem;
				border-bottom: 1px solid #eef2f7;
			}

			.toolbar-search {
				flex: 1 1 260px;
				min-width: 200px;
			}

			.toolbar-actions {
				flex: 0 0 auto;
				display: flex;
				align-items: center;
			}

			.toolbar input {
				width: 100%;
				padding: 0.5rem 0.65rem;
				border-radius: 0.55rem;
				border: 1px solid #d1d5db;
				background: #ffffff;
				color: #111827;
				font-size: 0.9rem;
				outline: none;
			}

			.toolbar input:focus {
				border-color: #2563eb;
			}

			.banner {
				margin: 0 0.9rem;
				padding: 0.6rem 0.75rem;
				border-radius: 0.55rem;
				border: 1px solid #e5e7eb;
				background: #ffffff;
				color: #0f172a;
				font-size: 0.85rem;
				display: flex;
				align-items: flex-start;
				justify-content: space-between;
				gap: 0.75rem;
			}

			.banner--error {
				border-color: #fecaca;
				background: #fef2f2;
				color: #991b1b;
			}

			.banner--success {
				border-color: #bbf7d0;
				background: #f0fdf4;
				color: #166534;
			}

			.banner-text {
				line-height: 1.35;
			}

			.banner-close {
				border: none;
				background: transparent;
				color: inherit;
				font-weight: 900;
				cursor: pointer;
				padding: 0.15rem 0.35rem;
				border-radius: 0.45rem;
			}

			.banner-close:hover {
				background: rgba(15, 23, 42, 0.06);
			}

			.table-wrap {
				overflow: auto;
				margin: 0 0.9rem 0.9rem;
				padding: 0;
				max-height: 56vh;
				position: relative;
			}

			.loading-overlay {
				position: absolute;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				min-height: 200px;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				background: rgba(255, 255, 255, 0.95);
				z-index: 10;
				border-radius: 0.6rem;
			}

			.loading-spinner {
				width: 3rem;
				height: 3rem;
				border: 3px solid #e5e7eb;
				border-top: 3px solid #2563eb;
				border-radius: 50%;
				animation: spin 1s linear infinite;
				margin-bottom: 1rem;
			}

			@keyframes spin {
				0% { transform: rotate(0deg); }
				100% { transform: rotate(360deg); }
			}

			.loading-text {
				color: #374151;
				font-size: 1rem;
				font-weight: 500;
			}

			.table-loading {
				padding: 3rem 2rem;
				display: flex;
				flex-direction: column;
				align-items: center;
				justify-content: center;
				background: rgba(248, 250, 252, 0.8);
				border-radius: 0.6rem;
				margin: 0.5rem;
			}

			.table-loading-spinner {
				width: 2rem;
				height: 2rem;
				border: 3px solid #e5e7eb;
				border-top: 3px solid #2563eb;
				border-radius: 50%;
				animation: spin 1s linear infinite;
				margin-bottom: 1rem;
			}

			.table-loading-text {
				color: #64748b;
				font-size: 0.9rem;
				font-weight: 600;
			}

			.data-table {
				width: max-content;
				min-width: 100%;
				border-collapse: collapse;
				table-layout: auto;
				font-size: 0.88rem;
			}

			.data-table th,
			.data-table td {
				white-space: nowrap;
				vertical-align: middle;
			}

			.data-table th {
				text-align: left;
				padding: 0.55rem 0.6rem;
				background: #f8fafc;
				border-bottom: 1px solid #e5e7eb;
				color: #334155;
				font-size: 0.78rem;
				font-weight: 800;
				position: sticky;
				top: 0;
				z-index: 3;
			}

			.data-table td {
				padding: 0.55rem 0.6rem;
				border-bottom: 1px solid #eef2f7;
				color: #0f172a;
			}

			.data-table tbody tr:hover td {
				background: #f8fafc;
			}

			.col-actions {
				width: 220px;
				white-space: nowrap;
			}

			.data-table th.col-actions,
			.data-table td.col-actions {
				position: sticky;
				right: 0;
				border-left: 1px solid #e5e7eb;
			}

			.data-table th.col-actions {
				background: #f8fafc;
				text-align: right;
				z-index: 4;
			}

			.data-table td.col-actions {
				background: #ffffff;
				z-index: 2;
			}

			.data-table tbody tr:hover td.col-actions {
				background: #f8fafc;
			}

			.row-actions {
				display: flex;
				width: 100%;
				align-items: center;
				justify-content: flex-end;
				gap: 0.45rem;
			}

			.btn.btn-sm {
				padding: 0.35rem 0.55rem;
				font-size: 0.85rem;
			}

			.empty-row {
				padding: 1rem;
				text-align: center;
				color: #64748b;
			}

			.editor {
				margin: 0 0.9rem 0.9rem;
				border: 1px solid #e5e7eb;
				border-radius: 0.65rem;
				background: #f8fafc;
			}

			.editor-header {
				padding: 0.75rem 0.85rem;
				display: flex;
				align-items: center;
				justify-content: space-between;
				gap: 0.75rem;
				border-bottom: 1px solid #e2e8f0;
			}

			.editor-header h3 {
				margin: 0;
				font-size: 0.95rem;
				color: #0f172a;
			}

			.editor-header p {
				margin: 0.1rem 0 0;
				font-size: 0.78rem;
				color: #64748b;
			}

			.editor-form {
				padding: 0.85rem;
			}

			.editor-grid {
				display: grid;
				grid-template-columns: repeat(2, minmax(0, 1fr));
				gap: 0.8rem;
			}

			.editor-field label {
				display: block;
				font-size: 0.8rem;
				font-weight: 700;
				color: #334155;
				margin-bottom: 0.25rem;
			}

			.editor-field input[type='text'],
			.editor-field input[type='number'],
			.editor-field input[type='date'] {
				width: 100%;
				padding: 0.5rem 0.6rem;
				border-radius: 0.55rem;
				border: 1px solid #d1d5db;
				background: #ffffff;
				color: #0f172a;
				outline: none;
			}

			.editor-field input:focus {
				border-color: #2563eb;
			}

			.editor-field input.ng-invalid.ng-touched:not(:disabled) {
				border-color: #dc2626;
			}

			.req {
				color: #dc2626;
				margin-left: 0.15rem;
			}

			.check {
				display: inline-flex;
				gap: 0.5rem;
				align-items: center;
				margin-top: 1.65rem;
				color: #0f172a;
				font-weight: 700;
			}

			.check input {
				width: 1rem;
				height: 1rem;
			}

			.editor-actions {
				margin-top: 0.9rem;
				display: flex;
				justify-content: flex-end;
				gap: 0.5rem;
			}

			.btn {
				display: inline-flex;
				align-items: center;
				white-space: nowrap;
				padding: 0.45rem 0.65rem;
				border-radius: 0.55rem;
				border: 1px solid #d1d5db;
				background: #ffffff;
				color: #111827;
				font-weight: 700;
				cursor: pointer;
			}

			.btn:disabled {
				opacity: 0.6;
				cursor: not-allowed;
			}

			.btn:hover {
				background: #f8fafc;
				border-color: #cbd5e1;
			}

			.btn-primary {
				background: #2563eb;
				border-color: #2563eb;
				color: #ffffff;
			}

			.btn-primary:hover {
				background: #1d4ed8;
				border-color: #1d4ed8;
			}

			.btn-danger {
				background: #fee2e2;
				border-color: #fecaca;
				color: #991b1b;
			}

			.btn-danger:hover {
				background: #fecaca;
				border-color: #fca5a5;
			}

			.modal-overlay {
				position: fixed;
				inset: 0;
				background: rgba(15, 23, 42, 0.45);
				display: flex;
				align-items: center;
				justify-content: center;
				padding: 1rem;
				z-index: 80;
			}

			.modal-card {
				width: min(520px, 100%);
				background: #ffffff;
				border: 1px solid #e5e7eb;
				border-radius: 0.75rem;
				box-shadow: 0 12px 30px rgba(15, 23, 42, 0.25);
				padding: 1rem;
			}

			.modal-title {
				margin: 0;
				font-size: 1rem;
				color: #0f172a;
			}

			.modal-text {
				margin: 0.5rem 0 0.95rem;
				color: #475569;
				font-size: 0.9rem;
				line-height: 1.4;
			}

			.modal-actions {
				display: flex;
				justify-content: flex-end;
				gap: 0.5rem;
			}

			.access-denied-modal {
				text-align: center;
				border-left-width: 4px;
				border-left-color: #dc2626;
			}

			.modal-icon {
				font-size: 2.5rem;
				margin-bottom: 0.75rem;
				opacity: 0.8;
			}

			.access-denied-modal .modal-title {
				color: #dc2626;
				font-weight: 600;
				margin-bottom: 0.75rem;
			}

			.access-denied-modal .modal-text {
				color: #ef4444;
				font-weight: 500;
			}

			@media (max-width: 900px) {
				.admin-layout {
					grid-template-columns: 1fr;
				}
			}

			@media (max-width: 720px) {
				.editor-grid {
					grid-template-columns: 1fr;
				}
			}

		`,
	],
})
export class DataAdministratorPageComponent {
	@ViewChild('editorSection') private readonly editorSection?: ElementRef<HTMLElement>;

	private readonly dataAdmin = inject(DataAdministratorService);

	// Convert the observable to a signal
	private readonly tablesResource = toSignal(this.dataAdmin.getTables(), { initialValue: undefined });
	
	// Signals for component state
	tableSearch = signal('');
	selectedTableKey = signal<string | null>(null);
	records = signal<DataRecord[]>([]);
	recordSearch = signal('');
	isLoadingRecords = signal(false);

	editorOpen = signal(false);
	editorMode = signal<'create' | 'edit'>('create');
	editingId = signal<number | null>(null);
	draft = signal<Record<string, DataRecordValue>>({});

	banner = signal<{ type: 'success' | 'error'; message: string } | null>(null);
	private bannerTimer: ReturnType<typeof window.setTimeout> | null = null;

	deleteConfirmOpen = signal(false);
	pendingDelete = signal<{ id: number; label: string } | null>(null);
	accessDeniedOpen = signal(false);

	// Computed signals for derived state
	tables = computed(() => {
		const resource = this.tablesResource();
		console.log('Tables resource:', resource);
		return resource || [];
	});
	isLoadingTables = computed(() => this.tablesResource() === undefined);

	filteredTables = computed(() => {
		const needle = this.tableSearch().trim().toLowerCase();
		const allTables = this.tables();
		if (!needle) {
			return allTables;
		}
		return allTables.filter((t) => t.name.toLowerCase().includes(needle));
	});

	selectedTable = computed(() => {
		const key = this.selectedTableKey();
		if (!key) {
			return null;
		}
		return this.tables().find((t) => t.key === key) ?? null;
	});

	filteredRecords = computed(() => {
		const table = this.selectedTable();
		if (!table) {
			return [];
		}
		const needle = this.recordSearch().trim().toLowerCase();
		const allRecords = this.records();
		if (!needle) {
			return allRecords;
		}
		return allRecords.filter((r) =>
			table.columns.some((c) => String(r[c.key] ?? '').toLowerCase().includes(needle)),
		);
	});

	selectTable(table: DataTableDefinition): void {
		this.selectedTableKey.set(table.key);
		this.recordSearch.set('');
		this.clearBanner();
		this.cancelDelete();
		this.closeEditor();
		this.loadRecords();
	}

	openCreate(): void {
		const table = this.selectedTable();
		const key = this.selectedTableKey();
		if (!table || !key) {
			return;
		}
		this.clearBanner();
		this.cancelDelete();
		this.editorMode.set('create');
		this.editingId.set(null);
		this.draft.set(this.buildEmptyDraft(table));
		this.editorOpen.set(true);
		this.scrollEditorIntoView();
	}

	openEdit(record: DataRecord): void {
		const table = this.selectedTable();
		if (!table) {
			return;
		}
		this.clearBanner();
		this.cancelDelete();
		this.editorMode.set('edit');
		this.editingId.set(Number(record['id']));
		this.draft.set({ ...record });
		this.editorOpen.set(true);
		this.scrollEditorIntoView();
	}

	private scrollEditorIntoView(): void {
		setTimeout(() => {
			const el = this.editorSection?.nativeElement;
			if (!el) {
				return;
			}
			el.scrollIntoView({ behavior: 'smooth', block: 'start' });
		}, 0);
	}

	clearBanner(): void {
		this.banner.set(null);
		if (this.bannerTimer) {
			clearTimeout(this.bannerTimer);
			this.bannerTimer = null;
		}
	}

	requestDelete(record: DataRecord): void {
		// Show access denied popup instead of actual delete
		this.accessDeniedOpen.set(true);
	}

	cancelDelete(): void {
		this.deleteConfirmOpen.set(false);
		this.pendingDelete.set(null);
	}

	confirmDelete(): void {
		const tableKey = this.selectedTableKey();
		const pending = this.pendingDelete();
		if (!tableKey || !pending) {
			this.cancelDelete();
			return;
		}

		this.dataAdmin.deleteRecord(tableKey, pending.id).subscribe({
			next: () => {
				this.loadRecords();
				const editMode = this.editorMode();
				const editId = this.editingId();
				if (editMode === 'edit' && editId === pending.id) {
					this.closeEditor();
				}
				this.cancelDelete();
				this.showBanner('success', 'Record deleted successfully.');
			},
			error: (error) => {
				console.error('Delete operation failed:', error);
				this.showBanner('error', error?.message || 'Failed to delete record.');
				this.cancelDelete();
			}
		});
	}

	save(form?: NgForm): void {
		const table = this.selectedTable();
		const tableKey = this.selectedTableKey();
		if (!table || !tableKey) {
			return;
		}
		if (form?.invalid) {
			this.showBanner('error', 'Please fill all required fields.');
			form.control.markAllAsTouched();
			return;
		}

		this.clearBanner();
		const normalized = this.normalizeDraft(table);
		const requiredError = this.getRequiredFieldError(table, normalized);
		if (requiredError) {
			this.showBanner('error', requiredError);
			form?.control.markAllAsTouched();
			return;
		}

		// Show access denied popup instead of actual save
		this.accessDeniedOpen.set(true);
	}

	closeAccessDenied(): void {
		this.accessDeniedOpen.set(false);
	}

	private showBanner(type: 'success' | 'error', message: string): void {
		this.banner.set({ type, message });
		if (this.bannerTimer) {
			clearTimeout(this.bannerTimer);
			this.bannerTimer = null;
		}
		if (type === 'success') {
			this.bannerTimer = window.setTimeout(() => this.clearBanner(), 2800);
		}
	}

	private buildDeleteLabel(record: DataRecord, id: number): string {
		const candidateKeys = ['name', 'designation_code', 'designation_type', 'ruleName', 'roleName'];
		for (const key of candidateKeys) {
			const raw = record[key];
			if (typeof raw === 'string' && raw.trim()) {
				return `record "${raw}" (#${id})`;
			}
		}
		return `record #${id}`;
	}

	closeEditor(): void {
		this.editorOpen.set(false);
		this.editingId.set(null);
		this.draft.set({});
	}

	formatValue(value: DataRecordValue, column: DataColumnDefinition): string {
		if (column.type === 'boolean') {
			return value === true ? 'Yes' : 'No';
		}
		if (value === null || value === undefined || value === '') {
			return '—';
		}
		return String(value);
	}

	private loadRecords(): void {
		const selectedKey = this.selectedTableKey();
		
		if (!selectedKey) {
			this.records.set([]);
			this.isLoadingRecords.set(false);
			return;
		}
		
		this.isLoadingRecords.set(true);
		
		this.dataAdmin.getRecords(selectedKey).subscribe({
			next: (records) => {
				this.records.set(records);
				this.isLoadingRecords.set(false);
			},
			error: (error) => {
				console.error('Failed to load records:', error);
				this.records.set([]);
				this.isLoadingRecords.set(false);
				this.showBanner('error', 'Failed to load records from the server.');
			}
		});
	}

	private buildEmptyDraft(table: DataTableDefinition): Record<string, DataRecordValue> {
		const draft: Record<string, DataRecordValue> = {};
		for (const c of table.columns) {
			if (c.readOnly) {
				draft[c.key] = null;
				continue;
			}
			if (c.defaultValue !== undefined) {
				draft[c.key] = c.defaultValue;
				continue;
			}
			switch (c.type) {
				case 'boolean':
					draft[c.key] = false;
					break;
				case 'number':
					draft[c.key] = null;
					break;
				default:
					draft[c.key] = '';
			}
		}
		return draft;
	}

	isFieldRequired(column: DataColumnDefinition): boolean {
		return !!column.required && !column.readOnly && column.type !== 'boolean';
	}

	// Getter/setter methods for draft values to work with ngModel
	getDraftValue(key: string): DataRecordValue {
		return this.draft()[key];
	}

	setDraftValue(key: string, value: DataRecordValue): void {
		const currentDraft = this.draft();
		this.draft.set({ ...currentDraft, [key]: value });
	}

	private normalizeDraft(table: DataTableDefinition): DataRecord {
		const result: DataRecord = {};
		const draftValues = this.draft();
		for (const c of table.columns) {
			const raw = draftValues[c.key];
			switch (c.type) {
				case 'number': {
					if (raw === null || raw === undefined || raw === '') {
						result[c.key] = null;
						break;
					}
					const n = typeof raw === 'number' ? raw : Number(raw);
					result[c.key] = Number.isFinite(n) ? n : null;
					break;
				}
				case 'boolean':
					result[c.key] = raw === true;
					break;
				case 'date':
				case 'text':
				default:
					if (raw === null || raw === undefined || raw === '') {
						result[c.key] = null;
						break;
					}
					result[c.key] = String(raw);
			}
		}

		const mode = this.editorMode();
		const editId = this.editingId();
		if (mode === 'edit' && editId !== null) {
			result['id'] = editId;
		}
		return result;
	}

	private getRequiredFieldError(table: DataTableDefinition, record: DataRecord): string | null {
		for (const c of table.columns) {
			if (!c.required || c.readOnly) {
				continue;
			}
			const value = record[c.key];
			switch (c.type) {
				case 'number':
					if (typeof value !== 'number' || !Number.isFinite(value)) {
						return `${c.label} is required.`;
					}
					break;
				case 'boolean':
					if (typeof value !== 'boolean') {
						return `${c.label} is required.`;
					}
					break;
				case 'date':
				case 'text':
				default:
					if (typeof value !== 'string' || value.trim() === '') {
						return `${c.label} is required.`;
					}
			}
		}
		return null;
	}
}
