import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="dashboard">
      <!-- Dashboard Header -->
      <header class="dashboard-header">
        <div class="header-content">
          <h1>PS-NEXT-GEN Dashboard</h1>
          <p>Healthcare Management System Overview</p>
          <div class="system-status">
            <span class="status-indicator active"></span>
            <span>System Online</span>
          </div>
        </div>
      </header>

      <!-- Quick links -->
      <div class="quick-actions">
        <h2>Quick links</h2>
        <div class="actions-grid">
          <button class="action-card" type="button" routerLink="/wizards/practitioner-inquiry">
            <div class="action-icon">🔍</div>
            <div class="action-text">
              <h4>Practitioner Inquiry</h4>
              <p>Search and manage practitioners</p>
            </div>
          </button>
          
          <button class="action-card" type="button" routerLink="/administration/data-administrator">
            <div class="action-icon">📋</div>
            <div class="action-text">
              <h4>Data Administration</h4>
              <p>Manage system configuration</p>
            </div>
          </button>
          
          <button class="action-card" type="button" routerLink="/feeds/metrics">
            <div class="action-icon">📈</div>
            <div class="action-text">
              <h4>Feed Performance</h4>
              <p>Monitor data feed metrics</p>
            </div>
          </button>
          
          <button class="action-card" type="button" routerLink="/administration/security-administrator">
            <div class="action-icon">⚙️</div>
            <div class="action-text">
              <h4>System Settings</h4>
              <p>Configure system parameters</p>
            </div>
          </button>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .dashboard {
      min-height: 100vh;
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 25%, #f8fafc 50%, #f1f5f9 100%);
      color: #1e293b;
      font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
      padding: 1.5rem;
    }

    .dashboard-header {
      background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.9));
      border-radius: 16px;
      padding: 2rem;
      margin-bottom: 2rem;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(226, 232, 240, 0.8);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 1rem;
    }

    .header-content h1 {
      margin: 0 0 0.5rem 0;
      font-size: 2rem;
      font-weight: 800;
      background: linear-gradient(135deg, #1e293b 0%, #3b82f6 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-content p {
      margin: 0;
      color: #64748b;
      font-size: 1rem;
      font-weight: 500;
    }

    .system-status {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.25rem;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(5, 150, 105, 0.05));
      border: 1px solid rgba(16, 185, 129, 0.2);
      border-radius: 12px;
      color: #065f46;
      font-weight: 600;
      font-size: 0.875rem;
    }

    .status-indicator {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #10b981;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    .quick-actions {
      margin-bottom: 3rem;
    }

    .quick-actions h2 {
      margin: 0 0 1.5rem 0;
      font-size: 1.5rem;
      font-weight: 700;
      color: #1e293b;
    }

    .actions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
    }

    .action-card {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1.25rem;
      background: linear-gradient(145deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.9));
      border: 1px solid rgba(226, 232, 240, 0.6);
      border-radius: 12px;
      text-align: left;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      backdrop-filter: blur(10px);
    }

    .action-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
      border-color: rgba(59, 130, 246, 0.3);
    }

    .action-icon {
      font-size: 1.5rem;
      padding: 0.75rem;
      border-radius: 10px;
      background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.05));
      border: 1px solid rgba(59, 130, 246, 0.2);
    }

    .action-text h4 {
      margin: 0 0 0.25rem 0;
      font-size: 0.875rem;
      font-weight: 600;
      color: #1e293b;
    }

    .action-text p {
      margin: 0;
      font-size: 0.75rem;
      color: #64748b;
    }

    @media (max-width: 768px) {
      .dashboard {
        padding: 1rem;
      }

      .header-content {
        flex-direction: column;
        align-items: flex-start;
      }

      .actions-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class HomePageComponent {
  constructor() {}
}