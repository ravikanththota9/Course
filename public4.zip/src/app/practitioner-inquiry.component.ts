import { Component, signal, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

interface SearchCriteria {
  firstName: string;
  lastName: string;
  stateLicense: string;
  type1NPI: string;
  taxId: string;
  pin: string;
  porticoId: string;
}

interface DesignationRecord {
  designation: string;
  owner: string;
  managingDept: string;
  effectiveDate: string;
  endDate: string;
  termReason: string;
}

interface TaskRecord {
  taskDescription: string;
  taskReason: string;
  createdDate: string;
  taskStatus: string;
  resolutionCode: string;
  userId: string;
  startDate: string;
  completedDate: string;
  taskNotes: string;
}

interface CredentialingRecord {
  cycleType: string;
  startDate: string;
  endDate: string;
  committeeDate: string;
  credStatus: string;
}

interface CommentRecord {
  commentType: string;
  commentDate: string;
  userId: string;
  text: string;
}

interface PractitionerRecord {
  id: number;
  practitionerName: string;
  pcp: string;
  stateLicense: string;
  type1NPI: string;
  taxId: string;
  status: string;
  porticoId: string;
  pin: string;
  credStatus: string;
  // Demographics fields
  providerType: string;
  degree: string;
  dateOfBirth: string;
  gender: string;
  raceAndEthnicity: string;
  caqhId: string;
  hospitalPracticeType: string;
  // Designations
  designations: DesignationRecord[];
  // Tasks
  tasks: TaskRecord[];
  // Credentialing
  credentialing: CredentialingRecord[];
  // Comments
  comments: CommentRecord[];
}

type DetailTab = 'overview' | 'demographics' | 'designations' | 'tasks' | 'credentialing' | 'comments';

@Component({
  selector: 'app-practitioner-inquiry',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  template: `
    <section class="inquiry-page">
      <header class="inquiry-header">
        <div class="inquiry-header-title">
          <h1>Practitioner Inquiry</h1>
          <p>Wizards → Practitioner Inquiry</p>
        </div>
      </header>

      <!-- Main Content Layout -->
      <div class="main-layout">
        <!-- Search Panel -->
        <div class="search-panel">
          <div class="panel-header">
            <h2>Search Criteria</h2>
            <p>Enter practitioner information to search</p>
          </div>
          
          <form (ngSubmit)="onSearch()" class="search-form">
            <div class="form-fields">
              <div class="field-group">
                <label for="firstName">First Name</label>
                <input
                  type="text"
                  id="firstName"
                  [(ngModel)]="searchCriteria.firstName"
                  name="firstName"
                  class="form-input"
                  placeholder="Enter first name"
                />
              </div>
              
              <div class="field-group">
                <label for="lastName">Last Name</label>
                <input
                  type="text"
                  id="lastName"
                  [(ngModel)]="searchCriteria.lastName"
                  name="lastName"
                  class="form-input"
                  placeholder="Enter last name"
                />
              </div>
              
              <div class="field-group">
                <label for="stateLicense">State License</label>
                <input
                  type="text"
                  id="stateLicense"
                  [(ngModel)]="searchCriteria.stateLicense"
                  name="stateLicense"
                  class="form-input"
                  placeholder="Enter state license"
                />
              </div>
              
              <div class="field-group">
                <label for="type1NPI">Type1 NPI</label>
                <input
                  type="text"
                  id="type1NPI"
                  [(ngModel)]="searchCriteria.type1NPI"
                  name="type1NPI"
                  class="form-input"
                  placeholder="Enter Type1 NPI"
                />
              </div>
              
              <div class="field-group">
                <label for="taxId">Tax ID</label>
                <input
                  type="text"
                  id="taxId"
                  [(ngModel)]="searchCriteria.taxId"
                  name="taxId"
                  class="form-input"
                  placeholder="Enter Tax ID"
                />
              </div>
              
              <div class="field-group">
                <label for="pin">PIN</label>
                <input
                  type="text"
                  id="pin"
                  [(ngModel)]="searchCriteria.pin"
                  name="pin"
                  class="form-input"
                  placeholder="Enter PIN"
                />
              </div>
              
              <div class="field-group">
                <label for="porticoId">Portico ID</label>
                <input
                  type="text"
                  id="porticoId"
                  [(ngModel)]="searchCriteria.porticoId"
                  name="porticoId"
                  class="form-input"
                  placeholder="Enter Portico ID"
                />
              </div>
            </div>
            
            <div class="form-actions">
              <button type="button" class="btn btn-secondary" (click)="onClear()">
                Clear
              </button>
              <button type="submit" class="btn btn-primary">
                Search
              </button>
            </div>
          </form>
        </div>

        <!-- Results Panel -->
        <div class="results-panel" #resultsSection>
          <div class="panel-header">
            <h2>Search Results</h2>
            <span class="results-count" *ngIf="hasSearched() && !isLoading() && !errorMessage()">
              <ng-container *ngIf="searchResults().length; else noResults">
                {{ searchResults().length }} records found
              </ng-container>
              <ng-template #noResults>No practitioners found</ng-template>
            </span>
            <span class="results-placeholder" *ngIf="!hasSearched() && !isLoading()">
              Enter search criteria and click Search to view results
            </span>
            <span class="loading-status" *ngIf="isLoading()">
              Searching...
            </span>
          </div>

          <!-- Error State -->
          <div class="error-state" *ngIf="errorMessage() && !isLoading()">
            <div class="error-icon">⚠️</div>
            <p>{{ errorMessage() }}</p>
            <button class="btn btn-secondary" (click)="errorMessage.set(null)">Dismiss</button>
          </div>

          <!-- Loading State -->
          <div class="loading-state" *ngIf="isLoading()">
            <div class="loading-spinner"></div>
            <p>Searching for practitioners...</p>
          </div>

          <div class="results-content" *ngIf="hasSearched() && !isLoading() && !errorMessage()">
            <div class="results-table-container" *ngIf="searchResults().length">
              <table class="results-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>PCP</th>
                    <th>License</th>
                    <th>NPI</th>
                    <th>Tax ID</th>
                    <th>Status</th>
                    <th>Portico ID</th>
                    <th>PIN</th>
                    <th>Cred Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr 
                    *ngFor="let practitioner of searchResults()" 
                    class="table-row"
                    (click)="onRowClick(practitioner)"
                    tabindex="0"
                    (keydown.enter)="onRowClick(practitioner)"
                    (keydown.space)="onRowClick(practitioner)"
                  >
                    <td class="practitioner-name">{{ practitioner.practitionerName }}</td>
                    <td>{{ practitioner.pcp }}</td>
                    <td>{{ practitioner.stateLicense }}</td>
                    <td>{{ practitioner.type1NPI }}</td>
                    <td>{{ practitioner.taxId }}</td>
                    <td>
                      <span class="status-badge" [class]="'status-' + practitioner.status.toLowerCase()">
                        {{ practitioner.status }}
                      </span>
                    </td>
                    <td>{{ practitioner.porticoId }}</td>
                    <td>{{ practitioner.pin }}</td>
                    <td>{{ practitioner.credStatus }}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div class="no-results" *ngIf="!searchResults().length">
              <div class="no-results-icon">🔍</div>
              <h3>No Practitioners Found</h3>
              <p>Try adjusting your search criteria</p>
            </div>
          </div>

          <div class="empty-state" *ngIf="!hasSearched()">
            <div class="empty-state-icon">👨‍⚕️</div>
            <h3>Ready to Search</h3>
            <p>Enter criteria in the search panel and click Search to find practitioners</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Detail Modal -->
    <div class="detail-modal" *ngIf="selectedPractitioner()" (click)="closeModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <header class="modal-header">
          <h2 class="modal-title">{{ selectedPractitioner()?.practitionerName }}</h2>
          <button class="close-btn" (click)="closeModal()">×</button>
        </header>

        <nav class="detail-tabs">
          <button
            *ngFor="let tab of detailTabs"
            class="tab-btn"
            [class.active]="activeTab() === tab.key"
            (click)="setActiveTab(tab.key)"
          >
            <span>{{ tab.icon }}</span>
            <span>{{ tab.label }}</span>
          </button>
        </nav>

        <div class="detail-content" #detailContent>
          <!-- Overview Tab -->
          <div *ngIf="activeTab() === 'overview'" class="content-grid">
            <div class="info-card">
              <h3>Basic Information</h3>
              <div class="info-field">
                <span class="field-label">Name:</span>
                <span class="field-value">{{ selectedPractitioner()?.practitionerName }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">PCP:</span>
                <span class="field-value">{{ selectedPractitioner()?.pcp }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Status:</span>
                <span class="field-value">
                  <span class="status-badge" [class]="selectedPractitioner()?.status ? 'status-' + selectedPractitioner()!.status.toLowerCase() : ''">
                    {{ selectedPractitioner()?.status }}
                  </span>
                </span>
              </div>
            </div>

            <div class="info-card">
              <h3>Identifiers</h3>
              <div class="info-field">
                <span class="field-label">State License:</span>
                <span class="field-value">{{ selectedPractitioner()?.stateLicense }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Type1 NPI:</span>
                <span class="field-value">{{ selectedPractitioner()?.type1NPI }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Tax ID:</span>
                <span class="field-value">{{ selectedPractitioner()?.taxId }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">PIN:</span>
                <span class="field-value">{{ selectedPractitioner()?.pin }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Portico ID:</span>
                <span class="field-value">{{ selectedPractitioner()?.porticoId }}</span>
              </div>
            </div>
          </div>

          <!-- Demographics Tab -->
          <div *ngIf="activeTab() === 'demographics'" class="content-grid">
            <div class="info-card">
              <h3>Practitioner Information</h3>
              <div class="info-field">
                <span class="field-label">Practitioner Name:</span>
                <span class="field-value">{{ selectedPractitioner()?.practitionerName }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Provider Type:</span>
                <span class="field-value">{{ selectedPractitioner()?.providerType }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Degree:</span>
                <span class="field-value">{{ selectedPractitioner()?.degree }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Date of Birth:</span>
                <span class="field-value">{{ selectedPractitioner()?.dateOfBirth }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Gender:</span>
                <span class="field-value">{{ selectedPractitioner()?.gender }}</span>
              </div>
            </div>

            <div class="info-card">
              <h3>Additional Demographics</h3>
              <div class="info-field">
                <span class="field-label">Race and Ethnicity:</span>
                <span class="field-value">{{ selectedPractitioner()?.raceAndEthnicity }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Portico ID:</span>
                <span class="field-value">{{ selectedPractitioner()?.porticoId }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">CAQH ID:</span>
                <span class="field-value">{{ selectedPractitioner()?.caqhId }}</span>
              </div>
              <div class="info-field">
                <span class="field-label">Hospital Practice Type:</span>
                <span class="field-value">{{ selectedPractitioner()?.hospitalPracticeType }}</span>
              </div>
            </div>
          </div>

          <!-- Designations Tab -->
          <div *ngIf="activeTab() === 'designations'" class="designations-container">
            <div class="designations-table-container">
              <table class="designations-table">
                <thead>
                  <tr>
                    <th>Designation</th>
                    <th>Owner</th>
                    <th>Managing Dept</th>
                    <th>Effective Date</th>
                    <th>End Date</th>
                    <th>Term Reason</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let designation of selectedPractitioner()?.designations" class="designation-row">
                    <td class="designation-name">{{ designation.designation }}</td>
                    <td>{{ designation.owner }}</td>
                    <td>{{ designation.managingDept }}</td>
                    <td>{{ designation.effectiveDate }}</td>
                    <td>{{ designation.endDate }}</td>
                    <td>{{ designation.termReason }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Tasks Tab -->
          <div *ngIf="activeTab() === 'tasks'" class="tasks-container">
            <div class="tasks-table-container">
              <table class="tasks-table">
                <thead>
                  <tr>
                    <th>Task Description</th>
                    <th>Task Reason</th>
                    <th>Created Date</th>
                    <th>Task Status</th>
                    <th>Resolution Code</th>
                    <th>User ID</th>
                    <th>Start Date</th>
                    <th>Completed Date</th>
                    <th>Task Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let task of selectedPractitioner()?.tasks" class="task-row">
                    <td class="task-description">{{ task.taskDescription }}</td>
                    <td>{{ task.taskReason }}</td>
                    <td>{{ task.createdDate }}</td>
                    <td>{{ task.taskStatus }}</td>
                    <td>{{ task.resolutionCode }}</td>
                    <td>{{ task.userId }}</td>
                    <td>{{ task.startDate }}</td>
                    <td>{{ task.completedDate || 'N/A' }}</td>
                    <td class="task-notes">{{ task.taskNotes }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Credentialing Tab -->
          <div *ngIf="activeTab() === 'credentialing'" class="credentialing-container">
            <div class="credentialing-table-container">
              <table class="credentialing-table">
                <thead>
                  <tr>
                    <th>Cycle Type</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Committee Date</th>
                    <th>Cred Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let credential of selectedPractitioner()?.credentialing" class="credentialing-row">
                    <td class="cycle-type">{{ credential.cycleType }}</td>
                    <td>{{ credential.startDate }}</td>
                    <td>{{ credential.endDate }}</td>
                    <td>{{ credential.committeeDate }}</td>
                    <td>{{ credential.credStatus }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Comments Tab -->
          <div *ngIf="activeTab() === 'comments'" class="comments-container">
            <div class="comments-table-container">
              <table class="comments-table">
                <thead>
                  <tr>
                    <th>Comment Type</th>
                    <th>Comment Date</th>
                    <th>User ID</th>
                    <th>Text</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let comment of selectedPractitioner()?.comments" class="comment-row">
                    <td class="comment-type">{{ comment.commentType }}</td>
                    <td>{{ comment.commentDate }}</td>
                    <td>{{ comment.userId }}</td>
                    <td class="comment-text">{{ comment.text }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .inquiry-page {
      display: flex;
      flex-direction: column;
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 25%, #f8fafc 50%, #f1f5f9 100%);
      color: #1e293b;
      font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
      position: relative;
    }

    .inquiry-page::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.08) 0%, transparent 50%), 
                  radial-gradient(circle at 20% 80%, rgba(239, 68, 68, 0.05) 0%, transparent 50%),
                  radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.04) 0%, transparent 50%);
      pointer-events: none;
    }

    .inquiry-header {
      background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.9));
      padding: 0.4rem 1rem;
      border-bottom: 1px solid rgba(226, 232, 240, 0.8);
      backdrop-filter: blur(20px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      flex-shrink: 0;
      position: sticky;
      top: 3.5rem;
      z-index: 100;
    }

    .inquiry-header-title h1 {
      margin: 0;
      font-size: 1rem;
      font-weight: 700;
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      letter-spacing: -0.025em;
    }

    .inquiry-header-title p {
      margin: 0.25rem 0 0 0;
      opacity: 0.7;
      font-size: 0.7rem;
      color: #64748b;
      font-weight: 500;
    }

    .main-layout {
      display: flex;
      flex: 1;
      gap: 0.75rem;
      padding: 0.75rem;
      position: relative;
    }

    /* Search Panel */
    .search-panel {
      width: 320px;
      background: linear-gradient(145deg, rgba(255, 255, 255, 0.98), rgba(248, 250, 252, 0.95));
      border-radius: 12px;
      padding: 0.6rem;
      color: #334155;
      display: flex;
      flex-direction: column;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.08), 
                  0 4px 16px rgba(0, 0, 0, 0.04),
                  inset 0 1px 0 rgba(255, 255, 255, 1);
      border: 1px solid rgba(226, 232, 240, 0.6);
      flex-shrink: 0;
      backdrop-filter: blur(24px);
      min-height: 0;
    }

    .panel-header {
      margin-bottom: 0.6rem;
      padding-bottom: 0.4rem;
      border-bottom: 2px solid #e2e8f0;
      flex-shrink: 0;
    }

    .panel-header h2 {
      margin: 0 0 0.25rem 0;
      font-size: 0.95rem;
      font-weight: 700;
      color: #1e293b;
      letter-spacing: -0.025em;
    }

    .panel-header p {
      margin: 0;
      font-size: 0.75rem;
      color: #64748b;
      font-weight: 500;
    }

    .search-form {
      display: flex;
      flex-direction: column;
    }

    .form-fields {
      display: grid;
      grid-template-columns: 1fr;
      gap: 0.4rem;
      padding-right: 0.5rem;
      margin-right: -0.5rem;
    }

    /* Custom scrollbar for form fields */
    .form-fields::-webkit-scrollbar {
      width: 4px;
    }

    .form-fields::-webkit-scrollbar-track {
      background: rgba(226, 232, 240, 0.3);
      border-radius: 4px;
    }

    .form-fields::-webkit-scrollbar-thumb {
      background: rgba(148, 163, 184, 0.5);
      border-radius: 4px;
    }

    .form-fields::-webkit-scrollbar-thumb:hover {
      background: rgba(148, 163, 184, 0.8);
    }

    .field-group {
      display: flex;
      flex-direction: column;
      position: relative;
      flex-shrink: 0;
    }

    .field-group label {
      font-size: 0.6rem;
      font-weight: 700;
      color: #475569;
      margin-bottom: 0.2rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .form-input {
      padding: 0.4rem 0.6rem;
      border: 2px solid #e2e8f0;
      border-radius: 6px;
      font-size: 0.7rem;
      font-weight: 500;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      background: white;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .form-input:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1), 
                  0 4px 12px rgba(0, 0, 0, 0.08);
      transform: translateY(-1px);
    }

    .form-input::placeholder {
      color: #94a3b8;
      font-weight: 400;
    }

    .form-actions {
      display: flex;
      gap: 0.4rem;
      margin-top: 0.6rem;
      padding-top: 0.6rem;
      border-top: 2px solid #e2e8f0;
      flex-shrink: 0;
    }

    .btn {
      padding: 0.45rem 0.8rem;
      border: none;
      border-radius: 6px;
      font-size: 0.65rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      flex: 1;
      text-transform: uppercase;
      letter-spacing: 0.025em;
      position: relative;
      overflow: hidden;
    }

    .btn-primary {
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      color: white;
      box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    }

    .btn-primary:hover {
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      transform: translateY(-2px);
      box-shadow: 0 6px 24px rgba(59, 130, 246, 0.4);
    }

    .btn-primary:active {
      transform: translateY(0);
    }

    .btn-secondary {
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      color: #475569;
      border: 2px solid #e2e8f0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    }

    .btn-secondary:hover {
      background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%);
      transform: translateY(-1px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    /* Results Panel */
    .results-panel {
      flex: 1;
      background: linear-gradient(145deg, rgba(255, 255, 255, 0.98), rgba(248, 250, 252, 0.95));
      border-radius: 12px;
      padding: 1rem;
      color: #334155;
      display: flex;
      flex-direction: column;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.08), 
                  0 4px 16px rgba(0, 0, 0, 0.04),
                  inset 0 1px 0 rgba(255, 255, 255, 1);
      border: 1px solid rgba(226, 232, 240, 0.6);
      min-height: 0;
      backdrop-filter: blur(24px);
    }

    .results-count {
      font-size: 0.75rem;
      color: #3b82f6;
      font-weight: 700;
      background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(37, 99, 235, 0.05));
      padding: 0.5rem 1rem;
      border-radius: 8px;
      border: 1px solid rgba(59, 130, 246, 0.2);
    }

    .results-placeholder {
      font-size: 0.75rem;
      color: #64748b;
      font-style: italic;
      font-weight: 500;
    }

    .loading-status {
      font-size: 0.75rem;
      color: #3b82f6;
      font-weight: 600;
      animation: pulse 1.5s infinite;
    }

    .loading-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 3rem 2rem;
      text-align: center;
      color: #64748b;
    }

    .loading-spinner {
      width: 48px;
      height: 48px;
      border: 4px solid #e2e8f0;
      border-top: 4px solid #3b82f6;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 1rem;
    }

    .error-state {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 3rem 2rem;
      text-align: center;
      color: #dc2626;
      background: linear-gradient(135deg, rgba(220, 38, 38, 0.05), rgba(239, 68, 68, 0.02));
      border-radius: 12px;
      border: 1px solid rgba(220, 38, 38, 0.1);
      margin-top: 1rem;
    }

    .error-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
    }

    .error-state p {
      font-size: 0.875rem;
      font-weight: 500;
      margin-bottom: 1.5rem;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @keyframes pulse {
      0%, 100% { opacity: 0.6; }
      50% { opacity: 1; }
    }

    .results-content {
      display: block;
    }

    .results-table-container {
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      margin-top: 1rem;
      box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .results-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.75rem;
    }

    .results-table thead {
      background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
    }

    .results-table th {
      padding: 1rem 0.75rem;
      text-align: left;
      font-weight: 700;
      color: #374151;
      border-bottom: 2px solid #cbd5e1;
      font-size: 0.7rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .results-table td {
      padding: 0.875rem 0.75rem;
      border-bottom: 1px solid #e2e8f0;
      font-weight: 500;
    }

    .table-row {
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .table-row:hover {
      background: linear-gradient(135deg, rgba(14, 165, 233, 0.04), rgba(2, 132, 199, 0.02));
      transform: scale(1.001);
    }

    .table-row:focus {
      outline: 2px solid #0ea5e9;
      outline-offset: -2px;
      background: rgba(14, 165, 233, 0.05);
    }

    .practitioner-name {
      font-weight: 700;
      color: #1e293b;
    }

    .status-badge {
      padding: 0.375rem 0.75rem;
      border-radius: 8px;
      font-size: 0.65rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .status-active {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
    }

    .status-inactive {
      background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      color: white;
    }

    /* Empty States */
    .no-results, .empty-state {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: #64748b;
    }

    .no-results-icon, .empty-state-icon {
      font-size: 3rem;
      margin-bottom: 1.5rem;
      opacity: 0.6;
      filter: grayscale(1);
    }

    .no-results h3, .empty-state h3 {
      margin: 0 0 0.75rem 0;
      font-size: 1rem;
      color: #374151;
      font-weight: 700;
    }

    .no-results p, .empty-state p {
      margin: 0;
      font-size: 0.75rem;
      font-weight: 500;
    }

    /* Modal Styles */
    .detail-modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(248, 250, 252, 0.85);
      z-index: 2000;
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(12px);
    }

    .modal-content {
      width: 90%;
      height: 90%;
      max-width: 1200px;
      background: linear-gradient(145deg, rgba(255, 255, 255, 0.98), rgba(248, 250, 252, 0.95));
      border-radius: 20px;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      box-shadow: 0 25px 60px rgba(0, 0, 0, 0.15), 0 8px 24px rgba(0, 0, 0, 0.08);
      border: 1px solid rgba(226, 232, 240, 0.8);
    }

    .modal-header {
      background: linear-gradient(135deg, rgba(248, 250, 252, 0.95), rgba(241, 245, 249, 0.9));
      color: #1e293b;
      padding: 1rem 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-shrink: 0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
      border-bottom: 1px solid rgba(226, 232, 240, 0.8);
    }

    .modal-title {
      font-size: 1rem;
      font-weight: 700;
      margin: 0;
      color: #1e293b;
    }

    .close-btn {
      background: rgba(226, 232, 240, 0.3);
      border: 1px solid rgba(148, 163, 184, 0.2);
      color: #64748b;
      font-size: 1rem;
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 6px;
      transition: all 0.2s ease;
      backdrop-filter: blur(10px);
    }

    .close-btn:hover {
      background: rgba(148, 163, 184, 0.3);
      color: #334155;
      transform: scale(1.05);
    }

    .detail-tabs {
      display: flex;
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      border-bottom: 1px solid #e2e8f0;
      overflow-x: auto;
      flex-shrink: 0;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    }

    .tab-btn {
      flex: 1;
      padding: 1.25rem;
      border: none;
      background: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      font-size: 0.8rem;
      font-weight: 600;
      color: #64748b;
      transition: all 0.3s ease;
      border-bottom: 3px solid transparent;
      white-space: nowrap;
    }

    .tab-btn.active {
      color: #3b82f6;
      background: linear-gradient(135deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.9));
      border-bottom-color: #3b82f6;
      box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
    }

    .tab-btn:hover:not(.active) {
      background: rgba(59, 130, 246, 0.05);
      color: #475569;
    }

    .detail-content {
      flex: 1;
      overflow-y: auto;
      padding: 2rem;
      background: linear-gradient(135deg, rgba(255, 255, 255, 0.98), rgba(248, 250, 252, 0.95));
    }

    .content-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .info-card {
      background: linear-gradient(135deg, rgba(255, 255, 255, 0.9), rgba(248, 250, 252, 0.8));
      border: 2px solid rgba(226, 232, 240, 0.6);
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.04), 0 2px 8px rgba(0, 0, 0, 0.02);
      backdrop-filter: blur(10px);
    }

    .info-card h3 {
      margin: 0 0 1rem 0;
      font-size: 0.95rem;
      font-weight: 700;
      color: #1e293b;
    }

    .info-field {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem 0;
      border-bottom: 1px solid #e2e8f0;
    }

    .info-field:last-child {
      border-bottom: none;
    }

    .field-label {
      font-weight: 600;
      color: #475569;
    }

    .field-value {
      color: #1e293b;
      font-weight: 500;
    }

    /* Table Styles for Detail Tabs */
    .designations-container,
    .tasks-container,
    .credentialing-container,
    .comments-container {
      padding: 0;
    }

    .designations-table-container,
    .tasks-table-container,
    .credentialing-table-container,
    .comments-table-container {
      overflow-x: auto;
      border: 2px solid #e2e8f0;
      border-radius: 12px;
      background: white;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .designations-table,
    .tasks-table,
    .credentialing-table,
    .comments-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.75rem;
      min-width: 800px;
    }

    .tasks-table {
      min-width: 1200px;
    }

    .comments-table {
      min-width: 1000px;
    }

    .designations-table thead,
    .tasks-table thead,
    .credentialing-table thead,
    .comments-table thead {
      background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
      position: sticky;
      top: 0;
    }

    .designations-table th,
    .tasks-table th,
    .credentialing-table th,
    .comments-table th {
      padding: 1rem 0.75rem;
      text-align: left;
      font-weight: 700;
      color: #374151;
      border-bottom: 2px solid #cbd5e1;
      font-size: 0.7rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      white-space: nowrap;
    }

    .designations-table td,
    .tasks-table td,
    .credentialing-table td,
    .comments-table td {
      padding: 0.875rem 0.75rem;
      border-bottom: 1px solid #e2e8f0;
      font-weight: 500;
      vertical-align: top;
    }

    .designation-row,
    .task-row,
    .credentialing-row,
    .comment-row {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .designation-row:hover,
    .task-row:hover,
    .credentialing-row:hover,
    .comment-row:hover {
      background: linear-gradient(135deg, rgba(14, 165, 233, 0.04), rgba(2, 132, 199, 0.02));
    }

    .designation-name,
    .task-description,
    .cycle-type,
    .comment-type {
      font-weight: 700;
      color: #1e293b;
    }

    .task-notes,
    .comment-text {
      font-size: 0.7rem;
      line-height: 1.4;
      max-width: 250px;
      word-wrap: break-word;
    }

    .comment-text {
      max-width: 300px;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .main-layout {
        flex-direction: column;
        padding: 1rem;
      }

      .search-panel {
        width: 100%;
      }

      .form-fields {
        grid-template-columns: repeat(2, 1fr);
        gap: 0.75rem;
      }

      .results-table {
        font-size: 0.75rem;
      }

      .results-table th,
      .results-table td {
        padding: 0.5rem;
      }

      .modal-content {
        width: 95%;
        height: 95%;
      }

      .content-grid {
        grid-template-columns: 1fr;
      }

      .detail-tabs {
        overflow-x: scroll;
      }

      .tab-btn {
        padding: 1rem;
        font-size: 0.8rem;
      }
    }

    @media (max-width: 480px) {
      .form-fields {
        grid-template-columns: 1fr;
      }

      .inquiry-header {
        padding: 1rem;
      }

      .main-layout {
        padding: 0.75rem;
      }
    }
  `]
})
export class PractitionerInquiryComponent {
  @ViewChild('resultsSection') resultsSection!: ElementRef;
  @ViewChild('detailContent') detailContent!: ElementRef;
  
  searchCriteria: SearchCriteria = {
    firstName: '',
    lastName: '',
    stateLicense: '',
    type1NPI: '',
    taxId: '',
    pin: '',
    porticoId: ''
  };

  searchResults = signal<PractitionerRecord[]>([]);
  hasSearched = signal<boolean>(false);
  selectedPractitioner = signal<PractitionerRecord | null>(null);
  activeTab = signal<DetailTab>('overview');
  isLoading = signal<boolean>(false);
  errorMessage = signal<string | null>(null);

  detailTabs = [
    { key: 'overview' as DetailTab, label: 'Overview', icon: '📋' },
    { key: 'demographics' as DetailTab, label: 'Demographics', icon: '👤' },
    { key: 'designations' as DetailTab, label: 'Designations', icon: '🎓' },
    { key: 'tasks' as DetailTab, label: 'Tasks', icon: '📋' },
    { key: 'credentialing' as DetailTab, label: 'Credentialing', icon: '🏆' },
    { key: 'comments' as DetailTab, label: 'Comments', icon: '💬' }
  ];

  constructor(private http: HttpClient) {}

  onSearch(): void {
    // Check if at least one search criteria is provided
    const hasSearchCriteria = Object.values(this.searchCriteria).some(value => value.trim() !== '');
    
    if (!hasSearchCriteria) {
      this.errorMessage.set('Please enter at least one search criteria.');
      return;
    }

    console.log('Search criteria:', this.searchCriteria);
    
    this.isLoading.set(true);
    this.errorMessage.set(null);
    this.hasSearched.set(true);

    // Build query parameters from search criteria
    const params = new URLSearchParams();
    Object.entries(this.searchCriteria).forEach(([key, value]) => {
      if (value.trim()) {
        params.append(key, value.trim());
      }
    });

    // Make API call
    this.http.get<PractitionerRecord[]>(`/api/practitioners?${params.toString()}`)
      .subscribe({
        next: (practitioners) => {
          this.searchResults.set(practitioners);
          this.isLoading.set(false);
          
          // Auto-scroll to results if found
          setTimeout(() => {
            if (this.resultsSection && practitioners.length > 0) {
              this.resultsSection.nativeElement.scrollIntoView({ 
                behavior: 'smooth',
                block: 'start'
              });
            }
          }, 100);
        },
        error: (error) => {
          console.error('API Error:', error);
          this.errorMessage.set('An error occurred while searching. Please try again.');
          this.searchResults.set([]);
          this.isLoading.set(false);
        }
      });
  }

  onClear(): void {
    this.searchCriteria = {
      firstName: '',
      lastName: '',
      stateLicense: '',
      type1NPI: '',
      taxId: '',
      pin: '',
      porticoId: ''
    };
    this.searchResults.set([]);
    this.hasSearched.set(false);
    this.errorMessage.set(null);
    this.isLoading.set(false);
  }

  onRowClick(practitioner: PractitionerRecord): void {
    this.selectedPractitioner.set(practitioner);
    this.activeTab.set('overview');
  }

  closeModal(): void {
    this.selectedPractitioner.set(null);
  }

  setActiveTab(tab: DetailTab): void {
    this.activeTab.set(tab);
    // Scroll to top of content when switching tabs
    setTimeout(() => {
      if (this.detailContent) {
        this.detailContent.nativeElement.scrollTop = 0;
      }
    }, 0);
  }
}