import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-provider-inquiry',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="inquiry-page">
      <header class="inquiry-header">
        <div class="inquiry-header-title">
          <h1>Provider Inquiry</h1>
          <p>Wizards → Provider Inquiry</p>
        </div>
      </header>

      <div class="development-banner">
        <div class="development-content">
          <div class="development-icon">🏥</div>
          <h2>Provider Inquiry Wizard</h2>
          <p>Search and inquire about healthcare provider information, facilities, and services.</p>
          <div class="development-status">
            <div class="status-indicator">⚠️</div>
            <span>Development in Progress</span>
          </div>
          <p class="development-subtitle">This feature is currently under development and will be available soon.</p>
        </div>
      </div>
    </section>
  `,
  styles: [`
    .inquiry-page {
      max-width: 780px;
      margin: 0 auto;
      padding-top: 0.5rem;
      display: flex;
      flex-direction: column;
      gap: 1.25rem;
    }

    .inquiry-header {
      padding: 0.3rem 0.8rem 0.4rem;
      border-radius: 0.45rem;
      background: linear-gradient(90deg, #f0fdf4, #dcfce7);
      border: 1px solid #bbf7d0;
      box-shadow: 0 1px 1px rgba(15, 23, 42, 0.04);
      border-left-width: 3px;
      border-left-color: #16a34a;
    }

    .inquiry-header-title h1 {
      margin: 0;
      font-size: 1.05rem;
      color: #111827;
    }

    .inquiry-header-title p {
      margin: 0.08rem 0 0;
      color: #6b7280;
      font-size: 0.8rem;
    }

    .development-banner {
      padding: 3rem 2rem;
      border-radius: 0.75rem;
      background: linear-gradient(135deg, #f0fdf4, #dcfce7);
      border: 1px solid #22c55e;
      border-left-width: 5px;
      border-left-color: #16a34a;
      text-align: center;
      box-shadow: 0 8px 16px rgba(15, 23, 42, 0.08);
    }

    .development-content {
      max-width: 500px;
      margin: 0 auto;
    }

    .development-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
      opacity: 0.8;
    }

    .development-banner h2 {
      margin: 0 0 0.75rem;
      font-size: 1.5rem;
      color: #14532d;
      font-weight: 600;
    }

    .development-banner p {
      margin: 0.75rem 0;
      color: #166534;
      font-size: 1rem;
      line-height: 1.6;
    }

    .development-status {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.25rem;
      margin: 1.5rem 0 1rem;
      background: linear-gradient(135deg, #fef3c7, #fde68a);
      border: 1px solid #f59e0b;
      border-radius: 0.5rem;
      font-weight: 600;
      color: #92400e;
    }

    .status-indicator {
      font-size: 1.25rem;
    }

    .development-subtitle {
      font-size: 0.9rem !important;
      opacity: 0.8;
      margin-top: 1rem !important;
      font-style: italic;
    }
  `]
})
export class ProviderInquiryComponent {
}