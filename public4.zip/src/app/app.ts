import { Component, signal } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

type TopNavMenu = 'feeds' | 'administration' | 'wizards';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected readonly title = signal('ps-next-gen');

  openSubmenu: TopNavMenu | null = null;

  openMenu(menu: TopNavMenu): void {
    this.openSubmenu = menu;
  }

  closeMenu(menu: TopNavMenu): void {
    if (this.openSubmenu === menu) {
      this.openSubmenu = null;
    }
  }

  closeAllMenus(): void {
    this.openSubmenu = null;
    if (typeof document !== 'undefined') {
      (document.activeElement as HTMLElement | null)?.blur();
    }
  }
}
