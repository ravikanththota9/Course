import { Component, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  EnvironmentKey,
  FeedDefinition,
  FeedPerformancePoint,
  InformationFeedsService,
} from './information-feeds.service';
import { FeedPerformanceChartComponent } from './feed-performance-chart.component';

@Component({
  selector: 'app-metrics-page',
  standalone: true,
  imports: [CommonModule, FormsModule, FeedPerformanceChartComponent],
  template: `
    <section class="info-page" (click)="closeFeedPanel()">
      <header class="info-header">
        <div class="info-header-main">
          <h1>Information Feeds</h1>
          <p>Select an environment and feed to inspect its details.</p>
        </div>
      </header>

      <div class="filters-row">
        <div class="field-group">
          <label for="environmentSelect">Environment</label>
          <select
            id="environmentSelect"
            name="environment"
            class="select"
            [ngModel]="selectedEnvironment"
            (ngModelChange)="onEnvironmentChange($event)"
          >
            <option value="" disabled>Select environment</option>
            <option *ngFor="let env of environments" [ngValue]="env">
              {{ env }}
            </option>
          </select>
        </div>

        <div class="field-group">
          <label for="feedSelect">Feeds</label>
          <div
            class="combo"
            [class.combo--disabled]="!feeds.length && !isLoadingFeeds"
          >
            <button
              type="button"
              class="combo-display"
              id="feedSelect"
              (click)="toggleFeedPanel($event)"
              [disabled]="!feeds.length && !isLoadingFeeds"
            >
              <span class="combo-value" *ngIf="selectedFeed; else feedPlaceholder">
                {{ selectedFeed.name }} (ID: {{ selectedFeed.id }})
              </span>
              <ng-template #feedPlaceholder>
                <span class="combo-placeholder">
                  <span *ngIf="isLoadingFeeds">Loading feeds...</span>
                  <span *ngIf="!isLoadingFeeds && feeds.length">Select a feed</span>
                  <span *ngIf="!isLoadingFeeds && !feeds.length">Select environment first</span>
                </span>
              </ng-template>
              <span
                class="combo-chevron"
                [class.open]="isFeedPanelOpen"
                aria-hidden="true"
              ></span>
            </button>

            <div
              class="combo-panel"
              *ngIf="isFeedPanelOpen"
              (click)="$event.stopPropagation()"
            >
              <input
                type="text"
                class="search-input"
                placeholder="Search feeds by name or ID..."
                [(ngModel)]="feedSearchTerm"
                (ngModelChange)="onFeedSearchChange($event)"
              />

              <div class="combo-options">
                <button
                  type="button"
                  class="combo-option"
                  *ngFor="let feed of filteredFeeds"
                  [class.combo-option--selected]="feed.id === selectedFeedId"
                  (click)="onFeedSelect(feed); $event.stopPropagation()"
                >
						<span class="combo-option-name">{{ feed.name }} (ID: {{ feed.id }})</span>
                </button>

                <div class="combo-empty" *ngIf="!filteredFeeds.length">
                  No feeds match your search.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section class="feed-details" *ngIf="selectedFeed as feed">
        <div class="chart-card" *ngIf="performanceData.length">
          <div class="chart-header">
            <div class="chart-header-main">
              <div class="chart-title-row">
                <h3>{{ feed.name }}</h3>
                <span class="chart-feed-id">ID: {{ feed.id }}</span>
              </div>
              <p class="chart-subtitle">
                Performance (minutes) – duration by day for this feed.
              </p>
            </div>
            <div class="chart-range">
              <label for="rangeSelect">Range</label>
              <select
                id="rangeSelect"
                class="select range-select"
                [(ngModel)]="selectedRange"
                (ngModelChange)="onRangeChange($event)"
              >
                <option *ngFor="let r of availableRanges" [ngValue]="r">
                  Last {{ r }} runs
                </option>
              </select>
            </div>
          </div>

        <div class="chart-body">
          <app-feed-performance-chart
            [data]="performanceData"
            [feedName]="feed.name"
            [rangeDays]="selectedRange"
          ></app-feed-performance-chart>
        </div>
        </div>

        <!-- No data banner -->
        <div class="no-data-banner" *ngIf="!performanceData.length && !isLoadingPerformance">
          <div class="no-data-content">
            <div class="no-data-icon">📊</div>
            <h3>No Feed Runs Found</h3>
            <p>No performance data is available for <strong>{{ feed.name }}</strong> (ID: {{ feed.id }}).</p>
            <p class="no-data-subtitle">This could mean the feed has no recent runs or the data is not accessible.</p>
          </div>
        </div>

        <!-- Loading state for performance data -->
        <div class="loading-performance" *ngIf="isLoadingPerformance">
          <div class="loading-content">
            <div class="loading-spinner"></div>
            <p>Loading feed performance data...</p>
          </div>
        </div>
      </section>
    </section>
  `,
  styles: [
    `
      .info-page {
        max-width: 780px;
        margin: 0 auto;
        padding-top: 0.5rem;
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
      }

    .info-header {
    padding: 0.3rem 0.8rem 0.4rem;
    border-radius: 0.45rem;
    background: linear-gradient(90deg, #eff6ff, #e0f2fe);
    border: 1px solid #dbeafe;
    box-shadow: 0 1px 1px rgba(15, 23, 42, 0.04);
    border-left-width: 3px;
    border-left-color: #2563eb;
  }

    .info-header-main h1 {
    margin: 0;
    font-size: 1.05rem;
    color: #111827;
  }

    .info-header-main p {
    margin: 0.08rem 0 0;
    color: #6b7280;
    font-size: 0.8rem;
  }

      .filters-row {
        display: flex;
        gap: 1rem;
        align-items: flex-end;
        flex-wrap: wrap;
        padding: 0.75rem 0.9rem;
        border-radius: 0.6rem;
        background-color: #ffffff;
        border: 1px solid #e5e7eb;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.06);
      }

      .field-group {
        display: flex;
        flex-direction: column;
        min-width: 210px;
      }

      label {
        font-size: 0.85rem;
        font-weight: 500;
        margin-bottom: 0.25rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #1f2937;
      }

      .select {
        padding: 0.45rem 0.75rem;
        border-radius: 0.375rem;
        border: 1px solid #d1d5db;
        font: inherit;
        background-color: #ffffff;
        min-width: 200px;
        color: #111827;
        box-shadow: 0 1px 1px rgba(15, 23, 42, 0.04);
        transition: border-color 0.16s ease, box-shadow 0.16s ease;
        appearance: none;
        background-image:
          url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath d='M6 8l4 4 4-4' fill='none' stroke='%236b7280' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 0.65rem center;
        background-size: 0.9rem 0.9rem;
        padding-right: 2.1rem;
      }

      .search-input {
        margin-bottom: 0.35rem;
        padding: 0.4rem 0.6rem;
        border-radius: 0.375rem;
        border: 1px solid #d1d5db;
        font: inherit;
        font-size: 0.85rem;
        background-color: #ffffff;
        color: #111827;
      }

      .search-input::placeholder {
        font-size: 0.8rem;
      }

      .search-input:disabled {
        background-color: #f3f4f6;
        color: #9ca3af;
      }

      .select:hover:not(:disabled) {
        border-color: #9ca3af;
      }

      .select:focus-visible {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 1px #2563eb33;
      }

      .select:disabled {
        background-color: #f3f4f6;
        color: #9ca3af;
        cursor: not-allowed;
      }

      .combo {
        position: relative;
        min-width: 240px;
      }

      .combo--disabled {
        opacity: 0.9;
      }

      .combo-display {
        width: 100%;
        padding: 0.45rem 0.75rem;
        border-radius: 0.375rem;
        border: 1px solid #d1d5db;
        background-color: #ffffff;
        color: #111827;
        font: inherit;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
        box-shadow: 0 1px 1px rgba(15, 23, 42, 0.04);
        cursor: pointer;
        transition: border-color 0.16s ease, box-shadow 0.16s ease;
      }

      .combo-display:hover:not(:disabled) {
        border-color: #9ca3af;
      }

      .combo-display:focus-visible {
        outline: none;
        border-color: #2563eb;
        box-shadow: 0 0 0 1px #2563eb33;
      }

      .combo-display:disabled {
        background-color: #f3f4f6;
        color: #9ca3af;
        cursor: not-allowed;
      }

      .combo-value {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .combo-placeholder {
        color: #9ca3af;
      }

      .combo-chevron {
        width: 0;
        height: 0;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 6px solid #6b7280;
        transition: transform 0.16s ease;
      }

      .combo-chevron.open {
        transform: rotate(180deg);
      }

      .combo-panel {
        position: absolute;
        top: calc(100% + 0.25rem);
        left: 0;
        right: 0;
        z-index: 20;
        padding: 0.5rem;
        border-radius: 0.5rem;
        background-color: #ffffff;
        border: 1px solid #e5e7eb;
        border-left-width: 3px;
        border-left-color: #2563eb;
        box-shadow: 0 8px 16px rgba(15, 23, 42, 0.18);
      }

      .combo-options {
        max-height: 220px;
        overflow: auto;
        margin-top: 0.25rem;
      }

      .combo-option {
        width: 100%;
        padding: 0.4rem 0.35rem;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        border-radius: 0.35rem;
      }

      .combo-option:focus-visible {
        outline: none;
        box-shadow: 0 0 0 1px #2563eb33;
      }

      .combo-option:hover {
        background-color: #eff6ff;
      }

      .combo-option--selected {
        background-color: #e0ecff;
        font-weight: 600;
      }

      .combo-option-name {
        font-size: 0.9rem;
        color: #111827;
      }

      .combo-empty {
        padding: 0.4rem 0.35rem;
        font-size: 0.85rem;
        color: #6b7280;
      }

      .feed-details {
        padding: 0.85rem 0.9rem;
        border-radius: 0.6rem;
        background-color: #ffffff;
        border: 1px solid #d1e3ff;
        box-shadow: 0 1px 3px rgba(15, 23, 42, 0.06);
        border-left-width: 4px;
        border-left-color: #2563eb;
      }

      .chart-card {
        margin-top: 0.6rem;
        padding-top: 0;
        border-top: none;
      }

      .chart-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.4rem;
      }

      .chart-header-main {
        display: flex;
        flex-direction: column;
        gap: 0.15rem;
      }

      .chart-header h3 {
        margin: 0;
        font-size: 0.95rem;
        color: #111827;
      }

      .chart-title-row {
        display: inline-flex;
        align-items: baseline;
        gap: 0.5rem;
        flex-wrap: wrap;
      }

      .chart-feed-id {
        font-size: 0.8rem;
        color: #6b7280;
      }

      .chart-subtitle {
        margin: 0.1rem 0 0;
        font-size: 0.8rem;
        color: #6b7280;
      }

      .chart-range {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 0.15rem;
      }

      .chart-range label {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #9ca3af;
      }

      .range-select {
        min-width: 140px;
        font-size: 0.85rem;
        padding-inline: 0.5rem;
      }

    .chart-body {
    margin-top: 0.25rem;
  }

    .no-data-banner {
    padding: 2rem 1.5rem;
    border-radius: 0.6rem;
    background: linear-gradient(135deg, #fef3c7, #fde68a);
    border: 1px solid #f59e0b;
    border-left-width: 4px;
    border-left-color: #d97706;
    text-align: center;
    box-shadow: 0 4px 6px rgba(15, 23, 42, 0.08);
  }

  .no-data-content {
    max-width: 400px;
    margin: 0 auto;
  }

  .no-data-icon {
    font-size: 2.5rem;
    margin-bottom: 0.75rem;
    opacity: 0.8;
  }

  .no-data-banner h3 {
    margin: 0 0 0.5rem;
    font-size: 1.25rem;
    color: #92400e;
    font-weight: 600;
  }

  .no-data-banner p {
    margin: 0.5rem 0 0;
    color: #a16207;
    font-size: 0.9rem;
    line-height: 1.5;
  }

  .no-data-subtitle {
    font-size: 0.85rem !important;
    opacity: 0.85;
    margin-top: 0.75rem !important;
  }

  .loading-performance {
    padding: 2rem 1.5rem;
    border-radius: 0.6rem;
    background: linear-gradient(135deg, #e0f2fe, #bae6fd);
    border: 1px solid #0ea5e9;
    border-left-width: 4px;
    border-left-color: #0284c7;
    text-align: center;
    box-shadow: 0 4px 6px rgba(15, 23, 42, 0.08);
  }

  .loading-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
  }

  .loading-spinner {
    width: 32px;
    height: 32px;
    border: 3px solid #e0f2fe;
    border-top: 3px solid #0284c7;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }

  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }

  .loading-performance p {
    margin: 0;
    color: #0c4a6e;
    font-size: 0.9rem;
    font-weight: 500;
  }
    `,
  ],
})
export class MetricsPageComponent {
  readonly environments: EnvironmentKey[];

  selectedEnvironment: EnvironmentKey | '' = '';
  feeds: FeedDefinition[] = [];
  isLoadingFeeds = false;
  selectedFeedId: number | '' = '';
  feedSearchTerm = '';
  isFeedPanelOpen = false;

  availableRanges: (10 | 30 | 50 | 90)[] = [10, 30, 50, 90];
  selectedRange: 10 | 30 | 50 | 90 = 10;
  performanceData: FeedPerformancePoint[] = [];
  isLoadingPerformance = false;

  constructor(
    private readonly feedsService: InformationFeedsService,
    private readonly cdr: ChangeDetectorRef
  ) {
    this.environments = this.feedsService.getEnvironments();
  }

  get selectedFeed(): FeedDefinition | undefined {
    if (!this.selectedFeedId) {
      return undefined;
    }
    return this.feeds.find((f) => f.id === this.selectedFeedId) ?? undefined;
  }

  get filteredFeeds(): FeedDefinition[] {
    const term = this.feedSearchTerm.trim().toLowerCase();
    if (!term) {
      return this.feeds;
    }
		return this.feeds.filter((feed) => {
			const matchesName = feed.name.toLowerCase().includes(term);
			const matchesId = feed.id.toString().includes(term);
			return matchesName || matchesId;
		});
  }

  onEnvironmentChange(environment: EnvironmentKey | ''): void {
    this.selectedEnvironment = environment;
    this.feedSearchTerm = '';
    this.selectedFeedId = '';
    this.isFeedPanelOpen = false;
    this.performanceData = [];
    this.isLoadingPerformance = false;
    
    if (!environment) {
      this.feeds = [];
      this.isLoadingFeeds = false;
      this.cdr.detectChanges();
      return;
    }
    
    // Set loading state
    this.isLoadingFeeds = true;
    this.feeds = [];
    this.cdr.detectChanges();
    
    // Subscribe to the feeds observable
    this.feedsService.getFeeds(environment).subscribe({
      next: (feeds) => {
        this.feeds = [...feeds]; // Create new array reference
        this.isLoadingFeeds = false;
        this.cdr.detectChanges(); // Trigger change detection
      },
      error: (error) => {
        console.error('Failed to load feeds:', error);
        this.feeds = [];
        this.isLoadingFeeds = false;
        this.cdr.detectChanges(); // Trigger change detection
      }
    });
  }

  onFeedSearchChange(term: string): void {
    this.feedSearchTerm = term;
  }

  toggleFeedPanel(event: MouseEvent): void {
    event.stopPropagation();
    if (!this.feeds.length || this.isLoadingFeeds) {
      return;
    }
    this.isFeedPanelOpen = !this.isFeedPanelOpen;
    if (this.isFeedPanelOpen) {
      this.feedSearchTerm = '';
    }
  }

  onFeedSelect(feed: FeedDefinition): void {
    this.selectedFeedId = feed.id;
    this.isFeedPanelOpen = false;
    this.loadPerformance();
  }

  onRangeChange(range: 10 | 30 | 50 | 90): void {
    this.selectedRange = range;
    this.loadPerformance();
  }

  closeFeedPanel(): void {
    if (this.isFeedPanelOpen) {
      this.isFeedPanelOpen = false;
    }
  }

  private loadPerformance(): void {
    if (!this.selectedFeedId) {
      this.performanceData = [];
      this.isLoadingPerformance = false;
      return;
    }
    
    // Set loading state
    this.isLoadingPerformance = true;
    this.performanceData = [];
    this.cdr.detectChanges();
    
    this.feedsService.getFeedPerformance(
      this.selectedFeedId as number,
      this.selectedRange
    ).subscribe({
      next: (data) => {
        this.performanceData = data;
        this.isLoadingPerformance = false;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Failed to load performance data:', error);
        this.performanceData = [];
        this.isLoadingPerformance = false;
        this.cdr.detectChanges();
      }
    });
  }
}
