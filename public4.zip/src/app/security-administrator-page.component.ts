import { Component } from '@angular/core';

@Component({
	selector: 'app-security-administrator-page',
	standalone: true,
	template: `
		<section class="admin-page">
			<header class="admin-header">
				<h1>Security Administrator</h1>
				<p>Administration → Security Administrator</p>
			</header>

			<div class="development-banner">
				<div class="development-content">
					<div class="development-icon">🔒</div>
					<div class="development-text">
						<h2>Development in progress</h2>
						
					</div>
					<div class="development-animation">
						<div class="progress-dots">
							<span class="dot dot-1"></span>
							<span class="dot dot-2"></span>
							<span class="dot dot-3"></span>
						</div>
					</div>
				</div>
			</div>
		</section>
	`,
	styles: [
		`
			.admin-page {
				max-width: 780px;
				margin: 0 auto;
				padding-top: 0.5rem;
				display: flex;
				flex-direction: column;
				gap: 1rem;
			}

			.admin-header {
				padding: 0.3rem 0.8rem 0.4rem;
				border-radius: 0.45rem;
				background: linear-gradient(90deg, #eff6ff, #e0f2fe);
				border: 1px solid #dbeafe;
				box-shadow: 0 1px 1px rgba(15, 23, 42, 0.04);
				border-left-width: 3px;
				border-left-color: #2563eb;
			}

			.admin-header h1 {
				margin: 0;
				font-size: 1.05rem;
				color: #111827;
			}

			.admin-header p {
				margin: 0.08rem 0 0;
				color: #6b7280;
				font-size: 0.8rem;
			}

			.admin-card {
				padding: 0.75rem 0.9rem;
				border-radius: 0.6rem;
				background-color: #ffffff;
				border: 1px solid #e5e7eb;
				box-shadow: 0 1px 2px rgba(15, 23, 42, 0.06);
			}

			.admin-muted {
				margin: 0;
				color: #6b7280;
				font-size: 0.9rem;
			}

			.development-banner {
				padding: 3rem 2rem;
				border-radius: 1rem;
				background: linear-gradient(135deg, #ddd6fe 0%, #c7d2fe 50%, #e0e7ff 100%);
				border: 2px solid #7c3aed;
				border-left-width: 6px;
				border-left-color: #5b21b6;
				box-shadow: 0 10px 15px rgba(15, 23, 42, 0.1), 0 4px 6px rgba(15, 23, 42, 0.05);
				position: relative;
				overflow: hidden;
			}

			.development-banner::before {
				content: '';
				position: absolute;
				top: -50%;
				right: -20%;
				width: 100px;
				height: 100px;
				background: linear-gradient(45deg, #8b5cf6, #7c3aed);
				border-radius: 50%;
				opacity: 0.2;
				animation: float 6s ease-in-out infinite;
			}

			.development-content {
				display: flex;
				flex-direction: column;
				align-items: center;
				gap: 1.5rem;
				position: relative;
				z-index: 1;
			}

			.development-icon {
				font-size: 4rem;
				animation: bounce 2s infinite;
				filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));
			}

			.development-text {
				text-align: center;
				max-width: 500px;
			}

			.development-text h2 {
				margin: 0 0 1rem;
				font-size: 2rem;
				color: #5b21b6;
				font-weight: 700;
				text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
			}

			.development-text p {
				margin: 0.75rem 0;
				color: #6d28d9;
				font-size: 1.1rem;
				line-height: 1.6;
				font-weight: 500;
			}

			.development-subtitle {
				font-size: 0.95rem !important;
				opacity: 0.9;
				margin-top: 1.25rem !important;
				color: #6d28d9 !important;
			}

			.development-animation {
				display: flex;
				justify-content: center;
				margin-top: 1rem;
			}

			.progress-dots {
				display: flex;
				gap: 0.5rem;
			}

			.dot {
				width: 12px;
				height: 12px;
				border-radius: 50%;
				background-color: #7c3aed;
				animation: pulse 1.5s ease-in-out infinite;
			}

			.dot-1 { animation-delay: 0s; }
			.dot-2 { animation-delay: 0.2s; }
			.dot-3 { animation-delay: 0.4s; }

			@keyframes bounce {
				0%, 20%, 50%, 80%, 100% {
					transform: translateY(0);
				}
				40% {
					transform: translateY(-10px);
				}
				60% {
					transform: translateY(-5px);
				}
			}

			@keyframes pulse {
				0%, 100% {
					opacity: 0.4;
					transform: scale(0.8);
				}
				50% {
					opacity: 1;
					transform: scale(1.2);
				}
			}

			@keyframes float {
				0%, 100% {
					transform: translateY(0) rotate(0deg);
				}
				50% {
					transform: translateY(-20px) rotate(180deg);
				}
			}
		`,
	],
})
export class SecurityAdministratorPageComponent {}
