package com.ps.psnextgen.metadata.service;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sql.DataSource;

import com.ps.psnextgen.metadata.config.MetadataProperties;
import com.ps.psnextgen.metadata.model.ColumnMetadataResponse;
import com.ps.psnextgen.metadata.model.TableMetadataResponse;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class TableMetadataService {
	private static final Pattern ORACLE_DATE_LITERAL = Pattern.compile("(?i)^DATE\\s*'([^']+)'$");
	private static final Pattern ORACLE_TO_DATE = Pattern.compile("(?i)^TO_DATE\\(\\s*'([^']+)'\\s*,.*\\)$");
	private static final Pattern ORACLE_TO_TIMESTAMP = Pattern.compile("(?i)^TO_TIMESTAMP\\(\\s*'([^']+)'\\s*,.*\\)$");

	private static final Set<String> LABEL_ACRONYMS = Set.of("id", "ss", "ds", "exl", "dtry", "ind", "api", "url");

	private final ObjectProvider<DataSource> dataSourceProvider;
	private final DataSource feedsDataSource;
	private final MetadataProperties properties;

	public TableMetadataService(ObjectProvider<DataSource> dataSourceProvider,
								@Qualifier("feedsDataSource") DataSource feedsDataSource,
								MetadataProperties properties) {
		this.dataSourceProvider = dataSourceProvider;
		this.feedsDataSource = feedsDataSource;
		this.properties = properties;
	}

	public List<TableMetadataResponse> getConfiguredTablesMetadata() {
		List<String> configured = properties.getTables().stream()
				.filter(StringUtils::hasText)
				.map(String::trim)
				.filter(StringUtils::hasText)
				.toList();

		if (configured.isEmpty()) {
			return List.of();
		}

		DataSource dataSource = dataSourceProvider.getIfAvailable();
		if (dataSource == null) {
			throw new MetadataDataSourceUnavailableException("No DataSource is configured. Set spring.datasource.* properties and include the correct JDBC driver.");
		}

		try (Connection connection = dataSource.getConnection()) {
			DatabaseMetaData metaData = connection.getMetaData();
			String catalog = connection.getCatalog();
			String defaultSchema = determineSchema(connection, metaData, properties.getSchema());

			List<TableMetadataResponse> results = new ArrayList<>(configured.size());
			for (String configuredEntry : configured) {
				TableRef tableRef = parseTableRef(configuredEntry, defaultSchema);
				results.add(readTable(metaData, catalog, tableRef));
			}
			return results;
		} catch (SQLException ex) {
			throw new MetadataQueryException("Failed querying JDBC metadata.", ex);
		}
	}

	private TableMetadataResponse readTable(DatabaseMetaData metaData, String catalog, TableRef tableRef) throws SQLException {
		String schemaForQuery = normalizeIdentifier(metaData, tableRef.schema());
		String tableForQuery = normalizeIdentifier(metaData, tableRef.table());

		Set<String> pkColumns = readPrimaryKeys(metaData, catalog, schemaForQuery, tableForQuery);
		List<ColumnMetadataResponse> columns = readColumns(metaData, catalog, schemaForQuery, tableForQuery, pkColumns);
		if (columns.isEmpty()) {
			throw new TableNotFoundException(tableRef.original(), tableRef.schema());
		}

		String responseKey = tableRef.table().toLowerCase(Locale.ROOT);
		MetadataProperties.TableOverride overrides = properties.getTable().get(responseKey);

		String name = (overrides != null && StringUtils.hasText(overrides.getName())) ? overrides.getName() : toLabel(responseKey);
		String description = (overrides != null && StringUtils.hasText(overrides.getDescription())) ? overrides.getDescription() : "";

		return new TableMetadataResponse(responseKey, name, description, columns);
	}

	private static Set<String> readPrimaryKeys(DatabaseMetaData metaData, String catalog, String schema, String table) throws SQLException {
		Set<String> pk = new HashSet<>();
		try (ResultSet rs = metaData.getPrimaryKeys(catalog, schema, table)) {
			while (rs.next()) {
				String col = rs.getString("COLUMN_NAME");
				if (StringUtils.hasText(col)) {
					pk.add(col.trim().toLowerCase(Locale.ROOT));
				}
			}
		}
		return pk;
	}

	private static List<ColumnMetadataResponse> readColumns(
			DatabaseMetaData metaData,
			String catalog,
			String schema,
			String table,
			Set<String> pkColumns) throws SQLException {
		Map<Integer, ColumnMetadataResponse> byOrdinal = new LinkedHashMap<>();
		try (ResultSet rs = metaData.getColumns(catalog, schema, table, null)) {
			while (rs.next()) {
				String columnName = rs.getString("COLUMN_NAME");
				if (!StringUtils.hasText(columnName)) {
					continue;
				}
				String key = columnName.trim().toLowerCase(Locale.ROOT);
				String label = toLabel(key);

				int dataType = rs.getInt("DATA_TYPE");
				String typeName = rs.getString("TYPE_NAME");
				int columnSize = rs.getInt("COLUMN_SIZE");
				int decimalDigits = rs.getInt("DECIMAL_DIGITS");
				int nullable = rs.getInt("NULLABLE");
				String defaultValue = normalizeDefaultValue(rs.getString("COLUMN_DEF"));
				int ordinal = rs.getInt("ORDINAL_POSITION");
				String isAutoIncrement = safeTrim(rs.getString("IS_AUTOINCREMENT"));
				String isGenerated = safeTrim(rs.getString("IS_GENERATEDCOLUMN"));

				boolean required = nullable == DatabaseMetaData.columnNoNulls;
				boolean readOnly = pkColumns.contains(key) || "YES".equalsIgnoreCase(isAutoIncrement) || "YES".equalsIgnoreCase(isGenerated);
				String uiType = inferUiType(dataType, typeName, columnSize);

				Integer maxLength = null;
				if ("text".equals(uiType) && isCharacterType(dataType, typeName) && columnSize > 0) {
					maxLength = columnSize;
				}

				String dbType = toDbType(dataType, typeName, columnSize, decimalDigits);

				byOrdinal.put(
						ordinal,
						new ColumnMetadataResponse(
								key,
								label,
								uiType,
								readOnly ? Boolean.TRUE : null,
								required ? Boolean.TRUE : null,
								maxLength,
								defaultValue,
								dbType));
			}
		}

		return byOrdinal.entrySet().stream()
				.sorted(Map.Entry.comparingByKey(Comparator.nullsLast(Integer::compareTo)))
				.map(Map.Entry::getValue)
				.filter(Objects::nonNull)
				.toList();
	}

	private static String determineSchema(Connection connection, DatabaseMetaData metaData, String configuredSchema) throws SQLException {
		if (StringUtils.hasText(configuredSchema)) {
			return configuredSchema.trim();
		}

		String schema = safeTrim(connection.getSchema());
		if (StringUtils.hasText(schema)) {
			return schema;
		}

		String userName = safeTrim(metaData.getUserName());
		if (StringUtils.hasText(userName)) {
			return userName;
		}

		return null;
	}

	private static String normalizeIdentifier(DatabaseMetaData metaData, String identifier) throws SQLException {
		if (!StringUtils.hasText(identifier)) {
			return null;
		}
		String trimmed = identifier.trim();
		if (metaData.storesUpperCaseIdentifiers()) {
			return trimmed.toUpperCase(Locale.ROOT);
		}
		if (metaData.storesLowerCaseIdentifiers()) {
			return trimmed.toLowerCase(Locale.ROOT);
		}
		return trimmed;
	}

	private static boolean isCharacterType(int dataType, String typeName) {
		return dataType == Types.CHAR
				|| dataType == Types.VARCHAR
				|| dataType == Types.NCHAR
				|| dataType == Types.NVARCHAR
				|| dataType == Types.LONGVARCHAR
				|| dataType == Types.LONGNVARCHAR
				|| (typeName != null && typeName.toUpperCase(Locale.ROOT).contains("CHAR"));
	}

	private static String toDbType(int dataType, String typeName, int columnSize, int decimalDigits) {
		String normalizedTypeName = StringUtils.hasText(typeName) ? typeName.trim() : "UNKNOWN";
		String upper = normalizedTypeName.toUpperCase(Locale.ROOT);

		if (isCharacterType(dataType, normalizedTypeName) && columnSize > 0) {
			return normalizedTypeName + "(" + columnSize + ")";
		}

		if (upper.contains("TIMESTAMP") && decimalDigits > 0) {
			return normalizedTypeName + "(" + decimalDigits + ")";
		}

		return normalizedTypeName;
	}

	private static String inferUiType(int dataType, String typeName, int columnSize) {
		if (dataType == Types.BOOLEAN || dataType == Types.BIT) {
			return "boolean";
		}

		if (columnSize == 1 && isCharacterType(dataType, typeName)) {
			return "boolean";
		}

		if (dataType == Types.DATE || dataType == Types.TIME || dataType == Types.TIMESTAMP || dataType == Types.TIMESTAMP_WITH_TIMEZONE
				|| (typeName != null && typeName.toUpperCase(Locale.ROOT).contains("DATE"))) {
			return "date";
		}

		if (dataType == Types.TINYINT || dataType == Types.SMALLINT || dataType == Types.INTEGER || dataType == Types.BIGINT
				|| dataType == Types.FLOAT || dataType == Types.REAL || dataType == Types.DOUBLE
				|| dataType == Types.NUMERIC || dataType == Types.DECIMAL) {
			return "number";
		}

		return "text";
	}

	private static String normalizeDefaultValue(String rawDefault) {
		if (!StringUtils.hasText(rawDefault)) {
			return null;
		}
		String def = rawDefault.trim();

		Matcher m = ORACLE_DATE_LITERAL.matcher(def);
		if (m.matches()) {
			return m.group(1);
		}
		m = ORACLE_TO_DATE.matcher(def);
		if (m.matches()) {
			return m.group(1);
		}
		m = ORACLE_TO_TIMESTAMP.matcher(def);
		if (m.matches()) {
			return m.group(1);
		}

		if (def.length() >= 2 && def.startsWith("'") && def.endsWith("'")) {
			return def.substring(1, def.length() - 1);
		}

		return def;
	}

	private static String toLabel(String key) {
		if (!StringUtils.hasText(key)) {
			return key;
		}

		String[] parts = key.split("_+");
		StringBuilder sb = new StringBuilder();
		for (String part : parts) {
			if (!StringUtils.hasText(part)) {
				continue;
			}

			String p = part.trim();
			String lower = p.toLowerCase(Locale.ROOT);

			String token;
			if (p.length() <= 2) {
				token = p.toUpperCase(Locale.ROOT);
			} else if (LABEL_ACRONYMS.contains(lower)) {
				token = p.toUpperCase(Locale.ROOT);
			} else {
				token = Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
			}

			if (sb.length() > 0) {
				sb.append(' ');
			}
			sb.append(token);
		}

		return sb.toString();
	}

	private static String safeTrim(String value) {
		return value == null ? null : value.trim();
	}

	private void ensureTableConfigured(String requestedTableName) {
		if (!StringUtils.hasText(requestedTableName)) {
			throw new UnknownTableRequestException(requestedTableName);
		}

		String trimmed = requestedTableName.trim();
		// Basic guard against SQL injection via table name.
		if (!trimmed.matches("[A-Za-z0-9_.$]+")) {
			throw new UnknownTableRequestException(requestedTableName);
		}

		final String requestedLower = trimmed.toLowerCase(Locale.ROOT);
		final int dot = requestedLower.indexOf('.');
		final String requestedTableOnly = (dot >= 0 && dot < requestedLower.length() - 1)
				? requestedLower.substring(dot + 1)
				: requestedLower;

		boolean allowed = properties.getTables().stream()
				.filter(StringUtils::hasText)
				.map(String::trim)
				.filter(StringUtils::hasText)
				.map(s -> s.toLowerCase(Locale.ROOT))
				.anyMatch(configured -> {
					String configuredTableOnly = configured;
					int configuredDot = configured.indexOf('.');
					if (configuredDot >= 0 && configuredDot < configured.length() - 1) {
						configuredTableOnly = configured.substring(configuredDot + 1);
					}
					return configured.equals(requestedLower) || configuredTableOnly.equals(requestedTableOnly);
				});

		if (!allowed) {
			throw new UnknownTableRequestException(requestedTableName);
		}
	}

	public List<Map<String, Object>> getTableData(String tableName) {
		ensureTableConfigured(tableName);

		DataSource dataSource = dataSourceProvider.getIfAvailable();
		if (dataSource == null) {
			throw new MetadataDataSourceUnavailableException("No DataSource is configured. Set spring.datasource.* properties and include the correct JDBC driver.");
		}

		try (Connection connection = dataSource.getConnection()) {
			DatabaseMetaData metaData = connection.getMetaData();
			String trimmed = tableName.trim();
			int dot = trimmed.indexOf('.');
			String configuredSchema = properties.getSchema();

			String schemaCandidate = null;
			String tableCandidate;
			if (dot > 0 && dot < trimmed.length() - 1) {
				schemaCandidate = trimmed.substring(0, dot).trim();
				tableCandidate = trimmed.substring(dot + 1).trim();
			} else {
				// Only qualify schema if explicitly configured.
				schemaCandidate = StringUtils.hasText(configuredSchema) ? configuredSchema.trim() : null;
				tableCandidate = trimmed;
			}

			String schemaForQuery = normalizeIdentifier(metaData, schemaCandidate);
			String tableForQuery = normalizeIdentifier(metaData, tableCandidate);
			
			// Construct the SQL query
			String sql;
			if (schemaForQuery != null && !schemaForQuery.isEmpty()) {
				sql = "SELECT * FROM " + schemaForQuery + "." + tableForQuery;
			} else {
				sql = "SELECT * FROM " + tableForQuery;
			}
			
			List<Map<String, Object>> results = new ArrayList<>();
			
			try (PreparedStatement statement = connection.prepareStatement(sql);
				 ResultSet resultSet = statement.executeQuery()) {
				
				ResultSetMetaData rsMetaData = resultSet.getMetaData();
				int columnCount = rsMetaData.getColumnCount();
				
				while (resultSet.next()) {
					Map<String, Object> row = new LinkedHashMap<>();
					
					for (int i = 1; i <= columnCount; i++) {
						String columnName = rsMetaData.getColumnName(i).toLowerCase();
						Object value = resultSet.getObject(i);
						
						// Convert database specific types to more standard types
						if (value != null) {
							if (value instanceof java.sql.Timestamp) {
								value = value.toString();
							} else if (value instanceof java.sql.Date) {
								value = value.toString();
							} else if (value instanceof java.math.BigDecimal) {
								java.math.BigDecimal bd = (java.math.BigDecimal) value;
								if (bd.scale() == 0) {
									value = bd.longValue();
								} else {
									value = bd.doubleValue();
								}
							} else if (value instanceof String) {
								value = ((String) value).trim();
							}
						}
						
						row.put(columnName, value);
					}
					
					results.add(row);
				}
			}
			
			return results;
			
		} catch (SQLException ex) {
			throw new MetadataQueryException("Failed querying table data for: " + tableName, ex);
		}
	}

	public List<Map<String, Object>> getPiFeedsData() {
		DataSource dataSource = dataSourceProvider.getIfAvailable();
		if (dataSource == null) {
			throw new MetadataDataSourceUnavailableException("No DataSource is configured. Set spring.datasource.* properties and include the correct JDBC driver.");
		}

		try (Connection connection = dataSource.getConnection()) {
			DatabaseMetaData metaData = connection.getMetaData();
			String schemaForQuery = normalizeIdentifier(metaData, StringUtils.hasText(properties.getSchema()) ? properties.getSchema() : null);
			String tableForQuery = normalizeIdentifier(metaData, "pi_feeds");
			
			// Construct the specific SQL query for pi_feeds with filter
			String sql;
			if (schemaForQuery != null && !schemaForQuery.isEmpty()) {
				sql = "SELECT ID, NAME, DS FROM " + schemaForQuery + "." + tableForQuery + " WHERE DISABLED = 'N'";
			} else {
				sql = "SELECT ID, NAME, DS FROM " + tableForQuery + " WHERE DISABLED = 'N'";
			}
			
			List<Map<String, Object>> results = new ArrayList<>();
			
			try (PreparedStatement statement = connection.prepareStatement(sql);
				 ResultSet resultSet = statement.executeQuery()) {
				
				while (resultSet.next()) {
					Map<String, Object> row = new LinkedHashMap<>();
					
					Object id = resultSet.getObject("ID");
					Object name = resultSet.getObject("NAME");
					Object ds = resultSet.getObject("DS");
					
					// Convert database specific types to more standard types
					if (id instanceof java.math.BigDecimal) {
						java.math.BigDecimal bd = (java.math.BigDecimal) id;
						id = bd.longValue();
					}
					if (name instanceof String) {
						name = ((String) name).trim();
					}
					if (ds instanceof String) {
						ds = ((String) ds).trim();
					}
					
					row.put("id", id);
					row.put("name", name);
					row.put("ds", ds);
					
					results.add(row);
				}
			}
			
			return results;
			
		} catch (SQLException ex) {
			throw new MetadataQueryException("Failed querying pi_feeds data", ex);
		}
	}

	public List<Map<String, Object>> getPiFeedRuns(Long feedId, Integer limit) {
		DataSource dataSource = dataSourceProvider.getIfAvailable();
		if (dataSource == null) {
			throw new MetadataDataSourceUnavailableException("No DataSource is configured. Set spring.datasource.* properties and include the correct JDBC driver.");
		}

		try (Connection connection = dataSource.getConnection()) {
			DatabaseMetaData metaData = connection.getMetaData();
			String schemaForQuery = normalizeIdentifier(metaData, StringUtils.hasText(properties.getSchema()) ? properties.getSchema() : null);
			String tableForQuery = normalizeIdentifier(metaData, "pi_feedrun");
			
			// Construct the SQL query for pi_feedrun with filter and ordering
			String sql;
			if (schemaForQuery != null && !schemaForQuery.isEmpty()) {
				sql = "SELECT * FROM " + schemaForQuery + "." + tableForQuery + 
					  " WHERE FEED_ID = ? AND STATUS = 'STOPPED' ORDER BY STARTED DESC";
			} else {
				sql = "SELECT * FROM " + tableForQuery + 
					  " WHERE FEED_ID = ? AND STATUS = 'STOPPED' ORDER BY STARTED DESC";
			}
			
			// Add row limit based on database type (Oracle uses ROWNUM)
			if (metaData.getDatabaseProductName().toLowerCase().contains("oracle")) {
				sql = "SELECT * FROM (" + sql + ") WHERE ROWNUM <= ?";
			} else {
				// For other databases like PostgreSQL, MySQL, etc.
				sql += " LIMIT ?";
			}
			
			List<Map<String, Object>> results = new ArrayList<>();
			
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setLong(1, feedId);
				statement.setInt(2, limit);
				
				try (ResultSet resultSet = statement.executeQuery()) {
					ResultSetMetaData rsMetaData = resultSet.getMetaData();
					int columnCount = rsMetaData.getColumnCount();
					
					while (resultSet.next()) {
						Map<String, Object> row = new LinkedHashMap<>();
						
						// Get the started and stopped dates
						java.sql.Date startedDate = resultSet.getDate("STARTED");
						java.sql.Timestamp startedTimestamp = resultSet.getTimestamp("STARTED");
						java.sql.Timestamp stoppedTimestamp = resultSet.getTimestamp("STOPPED");
						
						// Format the date as YYYY-MM-DD
						String dateStr = null;
						if (startedDate != null) {
							dateStr = startedDate.toString(); // This gives YYYY-MM-DD format
						}
						
						// Calculate duration in minutes
						Long duration = null;
						if (startedTimestamp != null && stoppedTimestamp != null) {
							long durationMillis = stoppedTimestamp.getTime() - startedTimestamp.getTime();
							duration = durationMillis / (1000 * 60); // Convert to minutes
						}
						
						row.put("date", dateStr);
						row.put("duration", duration);
						
						results.add(row);
					}
				}
			}
			
			return results;
			
		} catch (SQLException ex) {
			throw new MetadataQueryException("Failed querying pi_feedrun data", ex);
		}
	}

	public List<Map<String, Object>> getFeedsData() {
		if (feedsDataSource == null) {
			throw new MetadataDataSourceUnavailableException("Feeds DataSource is not configured. Set spring.datasource.feeds.* properties.");
		}

		try (Connection connection = feedsDataSource.getConnection()) {
			DatabaseMetaData metaData = connection.getMetaData();
			String schemaForQuery = null;
			String tableForQuery = normalizeIdentifier(metaData, "feeds");
			
			// Construct the specific SQL query for feeds with filter
			String sql;
			if (schemaForQuery != null && !schemaForQuery.isEmpty()) {
				sql = "SELECT FEED_SK, DESCR FROM " + schemaForQuery + "." + tableForQuery + " WHERE ENABLED = 'Y'";
			} else {
				sql = "SELECT FEED_SK, DESCR FROM " + tableForQuery + " WHERE ENABLED = 'Y'";
			}
			
			List<Map<String, Object>> results = new ArrayList<>();
			
			try (PreparedStatement statement = connection.prepareStatement(sql);
				 ResultSet resultSet = statement.executeQuery()) {
				
				while (resultSet.next()) {
					Map<String, Object> row = new LinkedHashMap<>();
					
					Object feedSk = resultSet.getObject("FEED_SK");
					Object descr = resultSet.getObject("DESCR");
					
					// Convert database specific types to more standard types
					if (feedSk instanceof java.math.BigDecimal) {
						java.math.BigDecimal bd = (java.math.BigDecimal) feedSk;
						feedSk = bd.longValue();
					}
					if (descr instanceof String) {
						descr = ((String) descr).trim();
					}
					
					row.put("id", feedSk);
					row.put("name", descr);
					row.put("description", descr);
					
					results.add(row);
				}
			}
			
			return results;
		} catch (SQLException ex) {
			throw new MetadataQueryException("Failed querying feeds data", ex);
		}
}

public List<Map<String, Object>> getFeedruns(Long feedSk, Integer limit) {
	if (feedsDataSource == null) {
		throw new MetadataDataSourceUnavailableException("Feeds DataSource is not configured. Set spring.datasource.feeds.* properties.");
	}

	try (Connection connection = feedsDataSource.getConnection()) {
		DatabaseMetaData metaData = connection.getMetaData();
		String schemaForQuery = null;
		String tableForQuery = normalizeIdentifier(metaData, "feedruns");
			
			// Construct the SQL query for feedruns with filters and ordering
			String sql;
			if (schemaForQuery != null && !schemaForQuery.isEmpty()) {
				sql = "SELECT * FROM " + schemaForQuery + "." + tableForQuery + 
					  " WHERE FEED_SK = ? AND STOPPED IS NOT NULL AND STATUS = 'S' ORDER BY STARTED DESC";
			} else {
				sql = "SELECT * FROM " + tableForQuery + 
					  " WHERE FEED_SK = ? AND STOPPED IS NOT NULL AND STATUS = 'S' ORDER BY STARTED DESC";
			}
			
			// Add row limit based on database type (Oracle uses ROWNUM)
			if (metaData.getDatabaseProductName().toLowerCase().contains("oracle")) {
				sql = "SELECT * FROM (" + sql + ") WHERE ROWNUM <= ?";
			} else {
				// For other databases like PostgreSQL, MySQL, etc.
				sql += " LIMIT ?";
			}
			
			List<Map<String, Object>> results = new ArrayList<>();
			
			try (PreparedStatement statement = connection.prepareStatement(sql)) {
				statement.setLong(1, feedSk);
				statement.setInt(2, limit);
				
				try (ResultSet resultSet = statement.executeQuery()) {
					while (resultSet.next()) {
						Map<String, Object> row = new LinkedHashMap<>();
						
						// Get the started and stopped dates
						java.sql.Date startedDate = resultSet.getDate("STARTED");
						java.sql.Timestamp startedTimestamp = resultSet.getTimestamp("STARTED");
						java.sql.Timestamp stoppedTimestamp = resultSet.getTimestamp("STOPPED");
						
						// Format the date as YYYY-MM-DD
						String dateStr = null;
						if (startedDate != null) {
							dateStr = startedDate.toString(); // This gives YYYY-MM-DD format
						}
						
						// Calculate duration in minutes
						Long duration = null;
						if (startedTimestamp != null && stoppedTimestamp != null) {
							long durationMillis = stoppedTimestamp.getTime() - startedTimestamp.getTime();
							duration = durationMillis / (1000 * 60); // Convert to minutes
						}
						
						row.put("date", dateStr);
						row.put("duration", duration);
						
						results.add(row);
					}
				}
			}
			
		return results;
	} catch (SQLException ex) {
		throw new MetadataQueryException("Failed querying feedruns data", ex);
	}
}

	private record TableRef(String original, String schema, String table) {
	}

	private static TableRef parseTableRef(String configured, String defaultSchema) {
		String trimmed = configured.trim();
		int dot = trimmed.indexOf('.');
		if (dot > 0 && dot < trimmed.length() - 1) {
			String schema = trimmed.substring(0, dot).trim();
			String table = trimmed.substring(dot + 1).trim();
			return new TableRef(trimmed, schema, table);
		}
		return new TableRef(trimmed, defaultSchema, trimmed);
	}
}
