package com.ps.psnextgen.metadata.model;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ColumnMetadataResponse(
		String key,
		String label,
		String type,
		Boolean readOnly,
		Boolean required,
		Integer maxLength,
		String defaultValue,
		String dbType) {
}
