package com.ps.psnextgen.metadata.web;

import com.ps.psnextgen.metadata.service.MetadataDataSourceUnavailableException;
import com.ps.psnextgen.metadata.service.MetadataQueryException;
import com.ps.psnextgen.metadata.service.TableNotFoundException;
import com.ps.psnextgen.metadata.service.UnknownTableRequestException;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.MissingServletRequestParameterException;

import java.net.URI;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

@RestControllerAdvice
public class MetadataExceptionHandler {
	private static final Logger log = LoggerFactory.getLogger(MetadataExceptionHandler.class);

	@ExceptionHandler(MetadataDataSourceUnavailableException.class)
	public ResponseEntity<ProblemDetail> handleDataSourceUnavailable(
			MetadataDataSourceUnavailableException ex,
			HttpServletRequest request
	) {
		ProblemDetail problem = buildProblem(HttpStatus.SERVICE_UNAVAILABLE, "Database not configured", ex.getMessage(), request);
		return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(problem);
	}

	@ExceptionHandler(TableNotFoundException.class)
	public ResponseEntity<ProblemDetail> handleTableNotFound(
			TableNotFoundException ex,
			HttpServletRequest request
	) {
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Configured table not found", ex.getMessage(), request);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(problem);
	}

	@ExceptionHandler(MetadataQueryException.class)
	public ResponseEntity<ProblemDetail> handleQueryFailed(
			MetadataQueryException ex,
			HttpServletRequest request
	) {
		log.warn("Metadata query failed on {} {}", request.getMethod(), request.getRequestURI(), ex);
		ProblemDetail problem = buildProblem(HttpStatus.INTERNAL_SERVER_ERROR, "Metadata query failed", ex.getMessage(), request);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(problem);
	}

	@ExceptionHandler(UnknownTableRequestException.class)
	public ResponseEntity<ProblemDetail> handleUnknownTable(
			UnknownTableRequestException ex,
			HttpServletRequest request
	) {
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Unknown table", ex.getMessage(), request);
		problem.setProperty("table", ex.getTableName());
		return ResponseEntity.badRequest().body(problem);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ProblemDetail> handleTypeMismatch(MethodArgumentTypeMismatchException ex, HttpServletRequest request) {
		String name = ex.getName();
		String detail = "Invalid value for parameter '%s'.".formatted(name);
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Invalid request parameter", detail, request);
		problem.setProperty("parameter", name);
		problem.setProperty("value", ex.getValue());
		return ResponseEntity.badRequest().body(problem);
	}

	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseEntity<ProblemDetail> handleMissingRequestParameter(
			MissingServletRequestParameterException ex,
			HttpServletRequest request
	) {
		String detail = "Missing required request parameter '%s'.".formatted(ex.getParameterName());
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Missing request parameter", detail, request);
		problem.setProperty("parameter", ex.getParameterName());
		return ResponseEntity.badRequest().body(problem);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ProblemDetail> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest request) {
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Validation failed", "One or more fields are invalid.", request);
		List<Map<String, String>> errors = ex.getBindingResult().getFieldErrors().stream()
				.map(err -> Map.of(
						"field", err.getField(),
						"message", err.getDefaultMessage() == null ? "Invalid value" : err.getDefaultMessage()
				))
				.toList();
		problem.setProperty("errors", errors);
		return ResponseEntity.badRequest().body(problem);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<ProblemDetail> handleNotReadable(HttpMessageNotReadableException ex, HttpServletRequest request) {
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Malformed request", "Request body is not readable or is invalid.", request);
		return ResponseEntity.badRequest().body(problem);
	}

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<ProblemDetail> handleMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpServletRequest request) {
		ProblemDetail problem = buildProblem(HttpStatus.METHOD_NOT_ALLOWED, "Method not allowed", ex.getMessage(), request);
		return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(problem);
	}

	@ExceptionHandler({HttpMediaTypeNotSupportedException.class, HttpMediaTypeNotAcceptableException.class})
	public ResponseEntity<ProblemDetail> handleMediaType(Exception ex, HttpServletRequest request) {
		HttpStatus status = ex instanceof HttpMediaTypeNotSupportedException ? HttpStatus.UNSUPPORTED_MEDIA_TYPE : HttpStatus.NOT_ACCEPTABLE;
		ProblemDetail problem = buildProblem(status, "Unsupported media type", ex.getMessage(), request);
		return ResponseEntity.status(status).body(problem);
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<ProblemDetail> handleIllegalArgument(IllegalArgumentException ex, HttpServletRequest request) {
		ProblemDetail problem = buildProblem(HttpStatus.BAD_REQUEST, "Invalid request", ex.getMessage(), request);
		return ResponseEntity.badRequest().body(problem);
	}

	@ExceptionHandler(DataAccessException.class)
	public ResponseEntity<ProblemDetail> handleDataAccess(DataAccessException ex, HttpServletRequest request) {
		log.warn("Database access error on {} {}", request.getMethod(), request.getRequestURI(), ex);
		ProblemDetail problem = buildProblem(HttpStatus.SERVICE_UNAVAILABLE, "Database error", "Database operation failed.", request);
		return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(problem);
	}

	@ExceptionHandler(ResponseStatusException.class)
	public ResponseEntity<ProblemDetail> handleResponseStatus(ResponseStatusException ex, HttpServletRequest request) {
		HttpStatus status = HttpStatus.resolve(ex.getStatusCode().value());
		HttpStatus resolved = status == null ? HttpStatus.INTERNAL_SERVER_ERROR : status;
		String detail = ex.getReason() == null ? ex.getMessage() : ex.getReason();
		ProblemDetail problem = buildProblem(resolved, "Request failed", detail, request);
		return ResponseEntity.status(resolved).body(problem);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ProblemDetail> handleUnexpected(Exception ex, HttpServletRequest request) {
		log.error("Unhandled error on {} {}", request.getMethod(), request.getRequestURI(), ex);
		ProblemDetail problem = buildProblem(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error", "Unexpected error occurred.", request);
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(problem);
	}

	private static ProblemDetail buildProblem(HttpStatus status, String title, String detail, HttpServletRequest request) {
		ProblemDetail problem = ProblemDetail.forStatus(status);
		problem.setTitle(title);
		problem.setDetail(detail);
		if (request != null) {
			problem.setInstance(URI.create(request.getRequestURI()));
			problem.setProperty("path", request.getRequestURI());
			problem.setProperty("method", request.getMethod());
		}
		problem.setProperty("timestamp", OffsetDateTime.now().toString());
		return problem;
	}
}
