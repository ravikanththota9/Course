package com.ps.psnextgen.metadata.service;

public class TableNotFoundException extends RuntimeException {
	private final String tableName;
	private final String schema;

	public TableNotFoundException(String tableName, String schema) {
		super(buildMessage(tableName, schema));
		this.tableName = tableName;
		this.schema = schema;
	}

	public String getTableName() {
		return tableName;
	}

	public String getSchema() {
		return schema;
	}

	private static String buildMessage(String tableName, String schema) {
		if (schema == null || schema.isBlank()) {
			return "Configured table '" + tableName + "' was not found (or not accessible).";
		}
		return "Configured table '" + tableName + "' was not found (or not accessible) in schema '" + schema + "'.";
	}
}
