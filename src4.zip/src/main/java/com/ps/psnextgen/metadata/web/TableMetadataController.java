package com.ps.psnextgen.metadata.web;

import java.util.List;
import java.util.Map;

import com.ps.psnextgen.metadata.model.TableMetadataResponse;
import com.ps.psnextgen.metadata.service.TableMetadataService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/metadata")
@CrossOrigin(origins = "*", maxAge = 3600)
public class TableMetadataController {
	private final TableMetadataService service;

	public TableMetadataController(TableMetadataService service) {
		this.service = service;
	}

	@GetMapping("/tables")
	public List<TableMetadataResponse> getTablesMetadata() {
		return service.getConfiguredTablesMetadata();
	}

	@GetMapping("/data/{tableName}")
	public List<Map<String, Object>> getTableData(@PathVariable String tableName) {
		return service.getTableData(tableName);
	}

	@GetMapping("/pi-feeds")
	public List<Map<String, Object>> getPiFeedsData() {
		return service.getPiFeedsData();
	}

	@GetMapping("/pi-feedruns/{feedId}")
	public List<Map<String, Object>> getPiFeedRuns(
			@PathVariable Long feedId,
			@RequestParam(defaultValue = "10") Integer limit) {
		return service.getPiFeedRuns(feedId, limit);
	}

	@GetMapping("/feeds")
	public List<Map<String, Object>> getFeedsData() {
		return service.getFeedsData();
	}

	@GetMapping("/feedruns/{feedSk}")
	public List<Map<String, Object>> getFeedruns(
			@PathVariable Long feedSk,
			@RequestParam(defaultValue = "10") Integer limit) {
		return service.getFeedruns(feedSk, limit);
	}
}
