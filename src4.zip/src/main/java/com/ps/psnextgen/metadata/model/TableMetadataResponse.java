package com.ps.psnextgen.metadata.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record TableMetadataResponse(
		String key,
		String name,
		String description,
		List<ColumnMetadataResponse> columns) {
}
