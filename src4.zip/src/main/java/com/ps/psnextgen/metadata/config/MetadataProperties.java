package com.ps.psnextgen.metadata.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app.metadata")
public class MetadataProperties {
	private List<String> tables = new ArrayList<>();
	private String schema;
	private Map<String, TableOverride> table = new HashMap<>();

	public List<String> getTables() {
		return tables;
	}

	public void setTables(List<String> tables) {
		this.tables = tables;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public Map<String, TableOverride> getTable() {
		return table;
	}

	public void setTable(Map<String, TableOverride> table) {
		this.table = table;
	}

	public static class TableOverride {
		private String name;
		private String description;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}
	}
}
