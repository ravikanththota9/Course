package com.ps.psnextgen.metadata.service;

public class UnknownTableRequestException extends RuntimeException {
	private final String tableName;

	public UnknownTableRequestException(String tableName) {
		super("Table is not configured: " + tableName);
		this.tableName = tableName;
	}

	public String getTableName() {
		return tableName;
	}
}
