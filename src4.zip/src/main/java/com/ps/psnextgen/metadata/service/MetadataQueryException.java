package com.ps.psnextgen.metadata.service;

public class MetadataQueryException extends RuntimeException {
	public MetadataQueryException(String message, Throwable cause) {
		super(message, cause);
	}
}
