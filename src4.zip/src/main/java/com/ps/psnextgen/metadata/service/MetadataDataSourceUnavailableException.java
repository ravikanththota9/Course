package com.ps.psnextgen.metadata.service;

public class MetadataDataSourceUnavailableException extends RuntimeException {
	public MetadataDataSourceUnavailableException(String message) {
		super(message);
	}
}
