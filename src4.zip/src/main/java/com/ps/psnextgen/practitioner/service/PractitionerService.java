package com.ps.psnextgen.practitioner.service;

import java.util.List;

import com.ps.psnextgen.practitioner.model.PractitionerDetailsResponse;
import org.springframework.stereotype.Service;

@Service
public class PractitionerService {
	public List<PractitionerDetailsResponse> getPractitioners() {
		return List.of(
				new PractitionerDetailsResponse(
						1,
						"Dr. Mike Johnson",
						"Yes",
						"0908978978",
						"1234567890",
						"XX-98937289",
						"Active",
						"1109873890816",
						"0986738",
						"Failed-Credentialing",
						"Physician",
						"MD",
						"March 15, 1985",
						"Female",
						"White, Non-Hispanic",
						"CAQH12345678",
						"Inpatient",
						List.of(
								new PractitionerDetailsResponse.Designation(
										"BCBA certified",
										"PEDM Provider enrollment and Data Management",
										"PEDM",
										"01/01/2025",
										"01/01/4000",
										"NA"
								),
								new PractitionerDetailsResponse.Designation(
										"Board Certified Internal Medicine",
										"Medical Affairs",
										"Quality Assurance",
										"06/15/2020",
										"06/15/2030",
										"NA"
								)
						),
						List.of(
								new PractitionerDetailsResponse.Task(
										"License Renewal Application",
										"State medical license renewal required",
										"02/15/2026",
										"In Progress",
										"PENDING",
										"admin001",
										"02/15/2026",
										"",
										"Application submitted to state board, awaiting approval"
								),
								new PractitionerDetailsResponse.Task(
										"Credentialing Documentation Update",
										"Annual credentialing review",
										"01/10/2026",
										"Completed",
										"RESOLVED",
										"cred_team",
										"01/10/2026",
										"02/01/2026",
										"All documentation reviewed and approved"
								),
								new PractitionerDetailsResponse.Task(
										"Background Check Verification",
										"Regulatory compliance requirement",
										"03/01/2026",
										"Pending",
										"OPEN",
										"hr_dept",
										"03/05/2026",
										"",
										"Waiting for third-party verification response"
								)
						),
						List.of(
								new PractitionerDetailsResponse.CredentialingCycle(
										"Initial Credentialing",
										"01/15/2020",
										"03/30/2020",
										"04/15/2020",
										"Approved"
								),
								new PractitionerDetailsResponse.CredentialingCycle(
										"Re-Credentialing",
										"01/01/2023",
										"03/15/2023",
										"04/01/2023",
										"Approved"
								),
								new PractitionerDetailsResponse.CredentialingCycle(
										"Re-Credentialing",
										"01/01/2026",
										"03/31/2026",
										"04/15/2026",
										"In Progress"
								)
						),
						List.of(
								new PractitionerDetailsResponse.Comment(
										"License Renewal",
										"March 10, 2026 - 2:30 PM",
										"john_admin",
										"License renewal documentation has been submitted to the state board. Waiting for approval."
								),
								new PractitionerDetailsResponse.Comment(
										"Contact Update",
										"March 8, 2026 - 10:15 AM",
										"sarah_wilson",
										"Updated contact information and verified current mailing address."
								),
								new PractitionerDetailsResponse.Comment(
										"Credentialing Review",
										"February 25, 2026 - 3:45 PM",
										"cred_specialist",
										"Annual credentialing review completed. All documents are up to date."
								)
						)
				),
				new PractitionerDetailsResponse(
						2,
						"Dr. Michael Chen",
						"No",
						"NY987654",
						"0987654321",
						"98-7654321",
						"Active",
						"P005678",
						"1234",
						"Pending",
						"Nurse Practitioner",
						"NP",
						"June 22, 1978",
						"Male",
						"Asian, Non-Hispanic",
						"CAQH87654321",
						"Outpatient",
						List.of(
								new PractitionerDetailsResponse.Designation(
										"Cardiology Specialist",
										"Specialty Care Division",
										"Cardiology",
										"03/10/2022",
										"03/10/2032",
										"NA"
								),
								new PractitionerDetailsResponse.Designation(
										"Advanced Practice Nurse",
										"Nursing Administration",
										"Nursing",
										"08/01/2021",
										"08/01/2031",
										"NA"
								)
						),
						List.of(
								new PractitionerDetailsResponse.Task(
										"Malpractice Insurance Update",
										"Insurance policy renewal",
										"02/20/2026",
										"Completed",
										"RESOLVED",
										"insurance_team",
										"02/20/2026",
										"03/10/2026",
										"New policy documents received and filed"
								),
								new PractitionerDetailsResponse.Task(
										"CME Credits Verification",
										"Continuing education requirement",
										"01/15/2026",
										"In Review",
										"PENDING",
										"education_dept",
										"01/15/2026",
										"",
										"Reviewing submitted CME certificates"
								)
						),
						List.of(
								new PractitionerDetailsResponse.CredentialingCycle(
										"Initial Credentialing",
										"06/10/2018",
										"08/25/2018",
										"09/10/2018",
										"Approved"
								),
								new PractitionerDetailsResponse.CredentialingCycle(
										"Re-Credentialing",
										"06/01/2021",
										"08/30/2021",
										"09/15/2021",
										"Approved"
								),
								new PractitionerDetailsResponse.CredentialingCycle(
										"Re-Credentialing",
										"02/01/2026",
										"04/30/2026",
										"05/15/2026",
										"Pending Committee Review"
								)
						),
						List.of(
								new PractitionerDetailsResponse.Comment(
										"Insurance Update",
										"March 12, 2026 - 1:20 PM",
										"insurance_admin",
										"Malpractice insurance policy has been renewed successfully. New documents filed."
								),
								new PractitionerDetailsResponse.Comment(
										"CME Verification",
										"March 5, 2026 - 4:15 PM",
										"education_coord",
										"Continuing Medical Education credits verified and recorded in system."
								),
								new PractitionerDetailsResponse.Comment(
										"Quality Review",
										"February 28, 2026 - 11:30 AM",
										"quality_mgr",
										"Quality assurance review completed with satisfactory results."
								)
						)
				),
				new PractitionerDetailsResponse(
						3,
						"Dr. Emily Rodriguez",
						"Yes",
						"TX456789",
						"4567890123",
						"45-6789012",
						"Inactive",
						"P009012",
						"9876",
						"In Progress",
						"Physician Assistant",
						"PA-C",
						"November 8, 1990",
						"Female",
						"Hispanic or Latino",
						"CAQH45678901",
						"Both Inpatient & Outpatient",
						List.of(
								new PractitionerDetailsResponse.Designation(
										"Emergency Medicine PA",
										"Emergency Services",
										"Emergency Medicine",
										"02/15/2023",
										"02/15/2033",
										"NA"
								)
						),
						List.of(
								new PractitionerDetailsResponse.Task(
										"PA License Verification",
										"State licensing board verification",
										"03/15/2026",
										"In Progress",
										"OPEN",
										"licensing_team",
										"03/15/2026",
										"",
										"Awaiting response from Texas Medical Board"
								),
								new PractitionerDetailsResponse.Task(
										"Emergency Department Orientation",
										"New department assignment",
										"02/28/2026",
										"Scheduled",
										"SCHEDULED",
										"ed_coordinator",
										"03/25/2026",
										"",
										"Training scheduled for next week"
								),
								new PractitionerDetailsResponse.Task(
										"DEA Registration Renewal",
										"Federal drug enforcement registration",
										"03/01/2026",
										"Pending",
										"PENDING",
										"compliance_team",
										"03/01/2026",
										"",
										"DEA renewal application submitted"
								)
						),
						List.of(
								new PractitionerDetailsResponse.CredentialingCycle(
										"Initial Credentialing",
										"09/01/2019",
										"11/15/2019",
										"12/01/2019",
										"Approved"
								),
								new PractitionerDetailsResponse.CredentialingCycle(
										"Re-Credentialing",
										"09/01/2022",
										"11/30/2022",
										"12/15/2022",
										"Approved"
								),
								new PractitionerDetailsResponse.CredentialingCycle(
										"Interim Review",
										"01/15/2026",
										"03/15/2026",
										"04/01/2026",
										"Under Review"
								)
						),
						List.of(
								new PractitionerDetailsResponse.Comment(
										"License Verification",
										"March 15, 2026 - 9:45 AM",
										"licensing_team",
										"PA license verification request submitted to Texas Medical Board. Awaiting response."
								),
								new PractitionerDetailsResponse.Comment(
										"Department Assignment",
										"March 2, 2026 - 2:10 PM",
										"hr_coordinator",
										"Emergency Department assignment confirmed. Orientation scheduled for upcoming week."
								),
								new PractitionerDetailsResponse.Comment(
										"DEA Registration",
										"March 1, 2026 - 8:30 AM",
										"compliance_officer",
										"DEA registration renewal application submitted to federal authorities."
								),
								new PractitionerDetailsResponse.Comment(
										"Orientation Schedule",
										"February 29, 2026 - 5:00 PM",
										"ed_supervisor",
										"Emergency Department orientation training scheduled for March 25th."
								)
						)
				)
		);
	}
}
