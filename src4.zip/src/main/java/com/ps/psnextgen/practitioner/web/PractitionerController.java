package com.ps.psnextgen.practitioner.web;

import java.util.List;

import com.ps.psnextgen.practitioner.model.PractitionerDetailsResponse;
import com.ps.psnextgen.practitioner.service.PractitionerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/practitioners")
public class PractitionerController {
	private final PractitionerService practitionerService;

	public PractitionerController(PractitionerService practitionerService) {
		this.practitionerService = practitionerService;
	}

	@GetMapping
	public List<PractitionerDetailsResponse> getPractitioners() {
		return practitionerService.getPractitioners();
	}
}
