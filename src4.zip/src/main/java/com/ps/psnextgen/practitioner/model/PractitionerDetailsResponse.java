package com.ps.psnextgen.practitioner.model;

import java.util.List;

public record PractitionerDetailsResponse(
		Integer id,
		String practitionerName,
		String pcp,
		String stateLicense,
		String type1NPI,
		String taxId,
		String status,
		String porticoId,
		String pin,
		String credStatus,
		String providerType,
		String degree,
		String dateOfBirth,
		String gender,
		String raceAndEthnicity,
		String caqhId,
		String hospitalPracticeType,
		List<Designation> designations,
		List<Task> tasks,
		List<CredentialingCycle> credentialing,
		List<Comment> comments
) {
	public record Designation(
			String designation,
			String owner,
			String managingDept,
			String effectiveDate,
			String endDate,
			String termReason
	) {}

	public record Task(
			String taskDescription,
			String taskReason,
			String createdDate,
			String taskStatus,
			String resolutionCode,
			String userId,
			String startDate,
			String completedDate,
			String taskNotes
	) {}

	public record CredentialingCycle(
			String cycleType,
			String startDate,
			String endDate,
			String committeeDate,
			String credStatus
	) {}

	public record Comment(
			String commentType,
			String commentDate,
			String userId,
			String text
	) {}
}
