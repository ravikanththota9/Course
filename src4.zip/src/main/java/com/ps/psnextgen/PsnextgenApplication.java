package com.ps.psnextgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PsnextgenApplication {

	public static void main(String[] args) {
		SpringApplication.run(PsnextgenApplication.class, args);
	}

}
