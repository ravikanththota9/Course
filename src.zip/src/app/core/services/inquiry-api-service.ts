import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export interface PractitionerCriteria {
  firstName: string;
  lastName: string;
  stateLicense: string;
  type1Npi: string;
  taxId: string;
  pin: string;
  porticoId: string;
}

export interface SearchResultRow {
  practitionerName: string;
  pcp: string;
  stateLicense: string;
  type1Npi: string;
  taxId: string;
  status: string;
  porticoId: string;
  pin: string;
  credStatus: string;
}

interface PractitionerDetailsResponse {
  id: number;
  practitionerName: string;
  pcp: string;
  stateLicense: string;
  type1NPI: string;
  taxId: string;
  status: string;
  porticoId: string;
  pin: string;
  credStatus: string;
}

@Injectable({ providedIn: 'root' })
export class InquiryApiService {
  private readonly practitionerSearchApi = 'http://localhost:8080/api/practitioners/search';

  constructor(private readonly http: HttpClient) {}

  searchPractitioners(criteria: PractitionerCriteria): Observable<SearchResultRow[]> {
    let params = new HttpParams();
    params = this.appendParam(params, 'pracfname', criteria.firstName);
    params = this.appendParam(params, 'praclname', criteria.lastName);
    params = this.appendParam(params, 'statelicense', criteria.stateLicense);
    params = this.appendParam(params, 'type1npi', criteria.type1Npi);
    params = this.appendParam(params, 'pinTF', criteria.pin);
    params = this.appendParam(params, 'pracsrchporticoID', criteria.porticoId);
    params = this.appendParam(params, 'taxid', criteria.taxId);

    return this.http
      .get<PractitionerDetailsResponse[]>(this.practitionerSearchApi, { params })
      .pipe(map((results) => (results ?? []).map((item) => this.mapToSearchResult(item))));
  }

  private appendParam(params: HttpParams, key: string, value: string): HttpParams {
    const trimmedValue = value.trim();
    if (!trimmedValue) {
      return params;
    }
    return params.set(key, trimmedValue);
  }

  private mapToSearchResult(item: PractitionerDetailsResponse): SearchResultRow {
    return {
      practitionerName: item.practitionerName,
      pcp: item.pcp,
      stateLicense: item.stateLicense,
      type1Npi: item.type1NPI,
      taxId: item.taxId,
      status: item.status,
      porticoId: item.porticoId,
      pin: item.pin,
      credStatus: item.credStatus
    };
  }
}
