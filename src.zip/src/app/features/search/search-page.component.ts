import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs/operators';
import { InquiryApiService, PractitionerCriteria, SearchResultRow } from '../../core/services/inquiry-api-service';

interface ProviderCriteria {
  providerName: string;
  stateLicense: string;
  type2Npi: string;
  taxId: string;
  pinFacilityCodeMedSuppCode: string;
  porticoId: string;
  medicareNumber: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="search-page" aria-label="Inquiry Search">
      <header class="page-header">
        <h1>Inquiry - Search</h1>
        <a class="help-link" href="javascript:void(0)">Help</a>
      </header>

      <div class="criteria-grid">
        <form class="criteria-card" (ngSubmit)="onPractitionerSearch()">
          <h2>Practitioner Search Criteria</h2>

          <label>
            <span>First Name:</span>
            <input type="text" name="firstName" [(ngModel)]="practitionerCriteria.firstName" />
          </label>

          <label>
            <span>Last Name:</span>
            <input type="text" name="lastName" [(ngModel)]="practitionerCriteria.lastName" />
          </label>

          <label>
            <span>State License #:</span>
            <input type="text" name="stateLicense" [(ngModel)]="practitionerCriteria.stateLicense" />
          </label>

          <label>
            <span>Type 1 NPI:</span>
            <input type="text" name="type1Npi" [(ngModel)]="practitionerCriteria.type1Npi" />
          </label>

          <label>
            <span>Tax ID #:</span>
            <input type="text" name="taxId" [(ngModel)]="practitionerCriteria.taxId" />
          </label>

          <label>
            <span>PIN:</span>
            <input type="text" name="pin" [(ngModel)]="practitionerCriteria.pin" />
          </label>

          <label>
            <span>Portico ID:</span>
            <input type="text" name="porticoId" [(ngModel)]="practitionerCriteria.porticoId" />
          </label>

          <div class="actions-row">
            <button type="button" class="legacy-button" [disabled]="isLoading()" (click)="clearPractitioner()">CLEAR SEARCH</button>
            <button type="submit" class="legacy-button" [disabled]="isLoading()">{{ isLoading() ? 'SEARCHING...' : 'SEARCH' }}</button>
          </div>
        </form>

        <form class="criteria-card" (ngSubmit)="onProviderSearch()">
          <h2>Provider Search Criteria</h2>

          <label>
            <span>Provider Name:</span>
            <input type="text" name="providerName" [(ngModel)]="providerCriteria.providerName" />
          </label>

          <label>
            <span>State License #:</span>
            <input type="text" name="providerStateLicense" [(ngModel)]="providerCriteria.stateLicense" />
          </label>

          <label>
            <span>Type 2 NPI:</span>
            <input type="text" name="type2Npi" [(ngModel)]="providerCriteria.type2Npi" />
          </label>

          <label>
            <span>Tax ID #:</span>
            <input type="text" name="providerTaxId" [(ngModel)]="providerCriteria.taxId" />
          </label>

          <label>
            <span>PIN/Facility Code/Med Supp Code:</span>
            <input
              type="text"
              name="pinFacilityCodeMedSuppCode"
              [(ngModel)]="providerCriteria.pinFacilityCodeMedSuppCode"
            />
          </label>

          <label>
            <span>Portico ID:</span>
            <input type="text" name="providerPorticoId" [(ngModel)]="providerCriteria.porticoId" />
          </label>

          <label>
            <span>Medicare Number:</span>
            <input type="text" name="medicareNumber" [(ngModel)]="providerCriteria.medicareNumber" />
          </label>

          <div class="actions-row">
            <button type="button" class="legacy-button" [disabled]="isLoading()" (click)="clearProvider()">CLEAR SEARCH</button>
            <button type="submit" class="legacy-button" [disabled]="isLoading()">SEARCH</button>
          </div>
        </form>
      </div>

      <div class="wizard-action-row">
        <button class="legacy-button center-action" type="button">BLUE CARD OUT OF STATE INQUIRY WIZARD</button>
      </div>

      <section class="results-area" aria-label="Search results">
        <table class="results-table">
          <thead>
            <tr>
              <th>Practitioner Name</th>
              <th>PCP</th>
              <th>State License #</th>
              <th>Type 1 NPI</th>
              <th>Tax ID #</th>
              <th>Status</th>
              <th>Portico ID</th>
              <th>PIN</th>
              <th>Cred Status</th>
            </tr>
          </thead>
          <tbody>
            @if (isLoading()) {
              <tr>
                <td colspan="9" class="empty-message">Searching practitioners...</td>
              </tr>
            } @else if (errorMessage()) {
              <tr>
                <td colspan="9" class="error-message">{{ errorMessage() }}</td>
              </tr>
            } @else if (searchResults().length) {
              @for (row of searchResults(); track row.porticoId + row.taxId) {
                <tr>
                  <td>{{ row.practitionerName }}</td>
                  <td>{{ row.pcp }}</td>
                  <td>{{ row.stateLicense }}</td>
                  <td>{{ row.type1Npi }}</td>
                  <td>{{ row.taxId }}</td>
                  <td>{{ row.status }}</td>
                  <td>{{ row.porticoId }}</td>
                  <td>{{ row.pin }}</td>
                  <td>{{ row.credStatus }}</td>
                </tr>
              }
            } @else {
              <tr>
                <td colspan="9" class="empty-message">Nothing to show</td>
              </tr>
            }
          </tbody>
        </table>
      </section>
    </section>
  `,
  styles: [`
    .search-page {
      min-height: calc(100vh - 6.5rem);
      padding: 0.65rem 0.6rem 1rem;
      background: #ececec;
      border: 1px solid #cfcfcf;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.7);
      color: #111;
      font-family: Arial, Helvetica, sans-serif;
    }

    .page-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: linear-gradient(#f7f0db, #e9d7ad);
      border: 1px solid #d3c19b;
      padding: 0.25rem 0.5rem;
      margin-bottom: 1.1rem;
    }

    .page-header h1 {
      margin: 0;
      font-size: 0.95rem;
      font-weight: 700;
    }

    .help-link {
      color: #103f77;
      font-size: 0.78rem;
      text-decoration: underline;
    }

    .criteria-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 3.5rem;
      align-items: start;
      padding: 0.35rem 0.6rem;
    }

    .criteria-card h2 {
      margin: 0 0 0.6rem;
      text-align: center;
      background: linear-gradient(#f5f5f5, #d6d6d6);
      border: 1px solid #c7c7c7;
      color: #001a70;
      font-size: 0.95rem;
      padding: 0.18rem 0.45rem;
    }

    .criteria-card {
      width: 100%;
      max-width: 460px;
    }

    .criteria-card label {
      display: grid;
      grid-template-columns: 1fr 1fr;
      align-items: center;
      gap: 0.6rem;
      margin-bottom: 0.45rem;
      font-size: 0.9rem;
    }

    .criteria-card input {
      width: 100%;
      box-sizing: border-box;
      height: 1.25rem;
      border: 1px solid #a6a6a6;
      background: #f8f8f8;
      padding: 0 0.2rem;
      font-size: 0.82rem;
    }

    .actions-row {
      display: flex;
      gap: 0.8rem;
      margin-top: 0.5rem;
    }

    .legacy-button {
      border: 1px solid #5b6d78;
      border-radius: 3px;
      background: linear-gradient(#5b7280, #304754);
      color: #fff;
      font-size: 0.78rem;
      font-weight: 700;
      letter-spacing: 0.02em;
      padding: 0.22rem 0.5rem;
      cursor: pointer;
      text-transform: uppercase;
    }

    .legacy-button:hover {
      filter: brightness(1.06);
    }

    .legacy-button:disabled {
      opacity: 0.65;
      cursor: not-allowed;
      filter: none;
    }

    .wizard-action-row {
      display: flex;
      justify-content: center;
      margin: 1.8rem 0 1.25rem;
    }

    .center-action {
      font-size: 0.85rem;
      padding-left: 0.65rem;
      padding-right: 0.65rem;
    }

    .results-area {
      border: 1px solid #b7b7b7;
      background: #f4f4f4;
      padding: 0;
      overflow-x: auto;
    }

    .results-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.83rem;
      min-width: 940px;
    }

    .results-table th {
      border: 1px solid #c2c2c2;
      background: linear-gradient(#f7f7f7, #d0d0d0);
      text-align: center;
      color: #111;
      font-weight: 700;
      padding: 0.22rem 0.28rem;
      white-space: nowrap;
    }

    .results-table td {
      border: 1px solid #d7d7d7;
      background: #fff;
      padding: 0.2rem 0.3rem;
      text-align: center;
    }

    .empty-message {
      text-align: center;
      color: #222;
      font-size: 0.84rem;
    }

    .error-message {
      text-align: center;
      color: #9f1239;
      font-size: 0.84rem;
      background: #ffe4e6 !important;
    }

    @media (max-width: 1100px) {
      .criteria-grid {
        grid-template-columns: 1fr;
        gap: 1.25rem;
      }
    }
  `]
})
export class SearchPageComponent {
  private readonly inquiryApiService = inject(InquiryApiService);

  practitionerCriteria: PractitionerCriteria = this.createDefaultPractitionerCriteria();
  providerCriteria: ProviderCriteria = this.createDefaultProviderCriteria();

  readonly searchResults = signal<SearchResultRow[]>([]);
  readonly isLoading = signal(false);
  readonly errorMessage = signal<string | null>(null);

  onPractitionerSearch(): void {
    const hasCriteria = Object.values(this.practitionerCriteria).some((value) => value.trim().length > 0);

    if (!hasCriteria) {
      this.searchResults.set([]);
      this.errorMessage.set('Please enter at least one practitioner search criteria.');
      return;
    }

    this.errorMessage.set(null);
    this.isLoading.set(true);

    this.inquiryApiService
      .searchPractitioners(this.practitionerCriteria)
      .pipe(finalize(() => this.isLoading.set(false)))
      .subscribe({
        next: (results) => this.searchResults.set(results),
        error: (error: HttpErrorResponse) => {
          this.searchResults.set([]);
          this.errorMessage.set(error.error?.message || 'Unable to load practitioner search results.');
        }
      });
  }

  onProviderSearch(): void {
    this.searchResults.set([]);
    this.errorMessage.set('Provider search is not integrated yet. Please use Practitioner Search Criteria.');
  }

  clearPractitioner(): void {
    this.practitionerCriteria = this.createDefaultPractitionerCriteria();
    this.searchResults.set([]);
    this.errorMessage.set(null);
  }

  clearProvider(): void {
    this.providerCriteria = this.createDefaultProviderCriteria();
    this.searchResults.set([]);
    this.errorMessage.set(null);
  }

  private createDefaultPractitionerCriteria(): PractitionerCriteria {
    return {
      firstName: '',
      lastName: '',
      stateLicense: '',
      type1Npi: '',
      taxId: '',
      pin: '',
      porticoId: ''
    };
  }

  private createDefaultProviderCriteria(): ProviderCriteria {
    return {
      providerName: '',
      stateLicense: '',
      type2Npi: '',
      taxId: '',
      pinFacilityCodeMedSuppCode: '',
      porticoId: '',
      medicareNumber: ''
    };
  }
}
