import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { SearchPageComponent } from './app/features/search/search-page.component';

bootstrapApplication(SearchPageComponent, {
  providers: [provideHttpClient()]
})
  .catch((err) => console.error(err));
