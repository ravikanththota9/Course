import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { finalize } from 'rxjs/operators';

import { UserSessionService } from './user-session.service';

@Component({
  selector: 'app-login-page',
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="login-page" aria-label="Login">
      <div class="login-card">
        <header class="login-header">
          <div class="brand">
            <div class="logo" aria-hidden="true">PS</div>
            <div>
              <h1>Provider Systems</h1>
            </div>
          </div>
        </header>

        <form class="login-form" (submit)="onProceed($event)">
          <label class="field">
            <span class="label">Enter you name</span>
            <input
              class="input"
              type="text"
              [formControl]="nameControl"
              [disabled]="isSubmitting()"
              autocomplete="name"
              inputmode="text"
              spellcheck="false"
              placeholder="Type your name"
              autofocus
            />
          </label>

          @if (submitError()) {
            <div class="error" role="alert" aria-live="polite">{{ submitError() }}</div>
          }

          <button class="proceed" type="submit" [disabled]="nameControl.invalid || isSubmitting()">
            {{ isSubmitting() ? 'Proceeding…' : 'Proceed' }}
          </button>
        </form>
      </div>
    </section>
  `,
  styles: [`
    .login-page {
      min-height: calc(100vh - 3.5rem);
      display: grid;
      place-items: center;
      padding: 1.5rem;
      background:
        radial-gradient(900px 500px at 20% 10%, rgba(250, 204, 21, 0.18), transparent 60%),
        radial-gradient(700px 420px at 80% 30%, rgba(59, 130, 246, 0.14), transparent 55%),
        linear-gradient(135deg, #001f3f 0%, #003f7f 55%, #001f3f 100%);
      color: #0b1120;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    }

    .login-card {
      width: min(520px, 100%);
      background: rgba(255, 255, 255, 0.96);
      border: 1px solid rgba(15, 23, 42, 0.12);
      border-radius: 18px;
      padding: 2rem;
      box-shadow: 0 16px 40px rgba(15, 23, 42, 0.25);
    }

    .brand {
      display: flex;
      gap: 1rem;
      align-items: center;
      margin-bottom: 1.5rem;
    }

    .logo {
      width: 44px;
      height: 44px;
      border-radius: 12px;
      display: grid;
      place-items: center;
      font-weight: 800;
      color: #0b1120;
      background: radial-gradient(circle at 30% 30%, #facc15, #f97316);
      border: 1px solid rgba(15, 23, 42, 0.18);
      box-shadow: 0 0 0 3px rgba(15, 23, 42, 0.08);
    }

    .login-header h1 {
      margin: 0;
      font-size: 1.35rem;
      font-weight: 800;
      letter-spacing: 0.01em;
    }

    .login-header p {
      margin: 0.25rem 0 0;
      color: rgba(15, 23, 42, 0.72);
      font-weight: 700;
      font-size: 0.92rem;
    }

    .login-form {
      display: grid;
      gap: 0.9rem;
    }

    .field {
      display: grid;
      gap: 0.4rem;
    }

    .label {
      font-weight: 700;
      font-size: 0.95rem;
      color: rgba(15, 23, 42, 0.92);
    }

    .input {
      width: 100%;
      box-sizing: border-box;
      border-radius: 12px;
      border: 1px solid rgba(15, 23, 42, 0.18);
      padding: 0.85rem 0.95rem;
      font-size: 1rem;
      outline: none;
      background: rgba(255, 255, 255, 1);
      transition: border-color 150ms ease, box-shadow 150ms ease, transform 150ms ease;
    }

    .input:focus-visible {
      border-color: rgba(0, 63, 127, 0.75);
      box-shadow: 0 0 0 4px rgba(250, 204, 21, 0.25);
    }

    .input:disabled {
      opacity: 0.75;
      background: rgba(248, 250, 252, 1);
    }

    .proceed {
      width: 100%;
      border: 0;
      border-radius: 12px;
      padding: 0.85rem 1rem;
      font-weight: 800;
      cursor: pointer;
      background: linear-gradient(90deg, #001f3f, #003f7f);
      color: white;
      transition: transform 150ms ease, filter 150ms ease, box-shadow 150ms ease;
      box-shadow: 0 10px 20px rgba(15, 23, 42, 0.18);
    }

    .proceed:hover:enabled {
      filter: brightness(1.03);
      transform: translateY(-1px);
    }

    .proceed:focus-visible {
      outline: none;
      box-shadow: 0 0 0 4px rgba(250, 204, 21, 0.35), 0 10px 20px rgba(15, 23, 42, 0.18);
    }

    .proceed:disabled {
      cursor: not-allowed;
      filter: grayscale(0.2);
      opacity: 0.6;
      transform: none;
    }

    .error {
      padding: 0.75rem 0.9rem;
      border-radius: 12px;
      border: 1px solid rgba(239, 68, 68, 0.25);
      background: rgba(239, 68, 68, 0.08);
      color: #991b1b;
      font-weight: 600;
      font-size: 0.9rem;
    }

    @media (max-width: 420px) {
      .login-card {
        padding: 1.5rem;
      }
    }
  `]
})
export class LoginPageComponent {
  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly session = inject(UserSessionService);

  readonly isSubmitting = signal(false);
  readonly submitError = signal<string | null>(null);

  readonly nameControl = new FormControl<string>('', {
    nonNullable: true,
    validators: [Validators.required, Validators.pattern(/\S+/)]
  });

  onProceed(event?: SubmitEvent): void {
    event?.preventDefault();

    const name = this.nameControl.value.trim();
    if (!name) {
      return;
    }

    this.isSubmitting.set(true);
    this.submitError.set(null);

    const params = new HttpParams().set('name', name);
    this.http
      .get('/api/login', { params, responseType: 'text' })
      .pipe(finalize(() => this.isSubmitting.set(false)))
      .subscribe({
        next: (responseText) => {
          const responseName = (responseText ?? '').trim();
          this.session.setUserName(responseName || name);
          this.router.navigateByUrl('/home');
        },
        error: () => {
          this.submitError.set('Login failed. Please try again.');
        }
      });
  }
}
