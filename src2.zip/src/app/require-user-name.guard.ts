import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { UserSessionService } from './user-session.service';

export const requireUserNameGuard: CanActivateFn = () => {
  const session = inject(UserSessionService);
  const router = inject(Router);

  return session.userName() ? true : router.parseUrl('/login');
};
