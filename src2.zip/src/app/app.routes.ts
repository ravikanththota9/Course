import { Routes } from '@angular/router';
import { LoginPageComponent } from './login-page.component';
import { requireUserNameGuard } from './require-user-name.guard';
import { HomePageComponent } from './home-page.component';
import { MetricsPageComponent } from './metrics-page.component';
import { DataAdministratorPageComponent } from './data-administrator-page.component';
import { BusinessAdministratorPageComponent } from './business-administrator-page.component';
import { SecurityAdministratorPageComponent } from './security-administrator-page.component';
import { PractitionerInquiryComponent } from './practitioner-inquiry.component';
import { ProviderInquiryComponent } from './provider-inquiry.component';

export const routes: Routes = [
	{ path: '', redirectTo: 'login', pathMatch: 'full' },
	{ path: 'login', component: LoginPageComponent },
	{ path: 'home', component: HomePageComponent, canActivate: [requireUserNameGuard] },
	{ path: 'feeds/metrics', component: MetricsPageComponent, canActivate: [requireUserNameGuard] },
	{ path: 'administration/data-administrator', component: DataAdministratorPageComponent, canActivate: [requireUserNameGuard] },
	{ path: 'administration/business-administrator', component: BusinessAdministratorPageComponent, canActivate: [requireUserNameGuard] },
	{ path: 'administration/security-administrator', component: SecurityAdministratorPageComponent, canActivate: [requireUserNameGuard] },
	{ path: 'wizards/practitioner-inquiry', component: PractitionerInquiryComponent, canActivate: [requireUserNameGuard] },
	{ path: 'wizards/provider-inquiry', component: ProviderInquiryComponent, canActivate: [requireUserNameGuard] },
	{ path: '**', redirectTo: 'login' }
];
