import { Component, computed, inject, signal } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

import { UserSessionService } from './user-session.service';

type TopNavMenu = 'feeds' | 'administration' | 'wizards';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLink],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  private readonly session = inject(UserSessionService);

  protected readonly title = signal('ps-next-gen');

  readonly userName = computed(() => this.session.userName());

  openSubmenu: TopNavMenu | null = null;

  openMenu(menu: TopNavMenu): void {
    this.openSubmenu = menu;
  }

  closeMenu(menu: TopNavMenu): void {
    if (this.openSubmenu === menu) {
      this.openSubmenu = null;
    }
  }

  closeAllMenus(): void {
    this.openSubmenu = null;
    if (typeof document !== 'undefined') {
      (document.activeElement as HTMLElement | null)?.blur();
    }
  }
}
