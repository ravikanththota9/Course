import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class UserSessionService {
  private readonly storageKey = 'ps-next-gen.userName';

  readonly userName = signal<string | null>(this.readStoredName());

  setUserName(name: string): void {
    const trimmed = name.trim();

    if (!trimmed) {
      this.clear();
      return;
    }

    this.userName.set(trimmed);
    this.writeStoredName(trimmed);
  }

  clear(): void {
    this.userName.set(null);
    this.removeStoredName();
  }

  private readStoredName(): string | null {
    try {
      if (typeof window === 'undefined') {
        return null;
      }
      const value = window.localStorage.getItem(this.storageKey);
      return value && value.trim() ? value.trim() : null;
    } catch {
      return null;
    }
  }

  private writeStoredName(name: string): void {
    try {
      if (typeof window === 'undefined') {
        return;
      }
      window.localStorage.setItem(this.storageKey, name);
    } catch {
      // ignore storage failures
    }
  }

  private removeStoredName(): void {
    try {
      if (typeof window === 'undefined') {
        return;
      }
      window.localStorage.removeItem(this.storageKey);
    } catch {
      // ignore storage failures
    }
  }
}
